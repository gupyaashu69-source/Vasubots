import os, sys, json, time, asyncio, traceback


def _compat():
    # The pip-installed typing_extensions on the phone is too old for the newer aiohttp/aiosignal.
    # Use the modern copy bundled with the app instead, before anything imports it.
    import sys
    import typing_ext_modern
    sys.modules["typing_extensions"] = typing_ext_modern


def run(workdir, room_id, token, owner):
    os.chdir(workdir)
    log = open("bot.log", "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log
    try:
        print("Starting bot ...")
        _compat()
        cfg = {}
        if os.path.exists("config.json"):
            with open("config.json", encoding="utf-8-sig") as f:
                cfg = json.load(f)
        cfg.update(ROOM_ID=room_id, room_id=room_id, API_TOKEN=token, OWNERS=[owner], PERMANENT_OWNERS=[owner])
        with open("config.json", "w") as f:
            json.dump(cfg, f, indent=2)
        sys.argv = ["main", room_id, token]
        from highrise.__main__ import bot_runner
        import main
        while True:
            try:
                asyncio.run(bot_runner(main.MusicBot(), room_id, token))
            except Exception:
                traceback.print_exc()
            print("Disconnected - reconnecting in 5 seconds ...")
            time.sleep(5)
    except Exception:
        traceback.print_exc()
