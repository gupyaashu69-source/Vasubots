import os, sys, json, time, asyncio, traceback


def _compat():
    # The phone build ended up with an old typing_extensions that lacks names newer aiohttp/aiosignal import
    # (e.g. TypeVarTuple). Python 3.11's own typing module has them, so copy any that are missing.
    import typing
    import typing_extensions
    for n in dir(typing):
        if not n.startswith("_") and not hasattr(typing_extensions, n):
            setattr(typing_extensions, n, getattr(typing, n))


def run(workdir, room_id, token, owner):
    os.chdir(workdir)
    log = open("bot.log", "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log
    try:
        print("Starting bot ...")
        _compat()
        cfg = {}
        if os.path.exists("config.json"):
            with open("config.json", encoding="utf-8-sig") as f:
                cfg = json.load(f)
        cfg.update(ROOM_ID=room_id, room_id=room_id, API_TOKEN=token, OWNERS=[owner], PERMANENT_OWNERS=[owner])
        with open("config.json", "w") as f:
            json.dump(cfg, f, indent=2)
        sys.argv = ["main", room_id, token]
        from highrise.__main__ import bot_runner
        import main
        while True:
            try:
                asyncio.run(bot_runner(main.MusicBot(), room_id, token))
            except Exception:
                traceback.print_exc()
            print("Disconnected - reconnecting in 5 seconds ...")
            time.sleep(5)
    except Exception:
        traceback.print_exc()
