import os, sys, json, time, asyncio, traceback

def run(workdir, room_id, token, owner):
    os.chdir(workdir)
    log = open("bot.log", "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log
    try:
        cfg = {}
        if os.path.exists("config.json"):
            cfg = json.load(open("config.json", encoding="utf-8-sig"))
        cfg.update(ROOM_ID=room_id, room_id=room_id, API_TOKEN=token, OWNERS=[owner], PERMANENT_OWNERS=[owner])
        json.dump(cfg, open("config.json", "w"), indent=2)
        sys.argv = ["main", room_id, token]
        from highrise.__main__ import bot_runner
        import main
        while True:
            try:
                asyncio.run(bot_runner(main.MusicBot(), room_id, token))
            except Exception:
                traceback.print_exc()
            print("Disconnected - reconnecting in 5 seconds ...")
            time.sleep(5)
    except Exception:
        traceback.print_exc()
