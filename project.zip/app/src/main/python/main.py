import asyncio
import os
import sys
import json
import re
import sqlite3
import traceback
import urllib.parse
import aiohttp
import random
import time
import logging
import html
import shutil
import subprocess

# Fix UnicodeEncodeError on Windows: only set environment variables
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"
    os.environ["LANG"] = "en_US.UTF-8"
    os.environ["LC_ALL"] = "en_US.UTF-8"
from dotenv import load_dotenv

# Suppress internal connection logs from highrise SDK
logging.basicConfig(level=logging.WARNING)
logging.getLogger("highrise").setLevel(logging.WARNING)
from highrise import BaseBot
from highrise.models import SessionMetadata, ChatEvent, User, Position, AnchorPosition, Error, RoomPermissions, UserMovedEvent, Item, CurrencyItem

# Load environment variables (optional if using config.json)
load_dotenv()

_GLOBAL_MUSIC_TASK = None

class MusicBot(BaseBot):
    def start_music_worker(self):
        global _GLOBAL_MUSIC_TASK
        if _GLOBAL_MUSIC_TASK is not None and not _GLOBAL_MUSIC_TASK.done():
            return
        import time
        cur = getattr(self, 'current_song', None)
        if cur:
            st = cur.get('start_time', 0)
            dur = cur.get('duration', 0) or 0
            max_allowed = max(dur + 120, 300)
            if st and (time.time() - st) > max_allowed:
                self.current_song = None
                if getattr(self, 'current_stream_process', None):
                    try:
                        self.current_stream_process.terminate()
                    except Exception:
                        pass
                    self.current_stream_process = None
        _GLOBAL_MUSIC_TASK = asyncio.create_task(self.music_worker())

    def stop_music_worker(self):
        global _GLOBAL_MUSIC_TASK
        if _GLOBAL_MUSIC_TASK is not None and not _GLOBAL_MUSIC_TASK.done():
            _GLOBAL_MUSIC_TASK.cancel()
            _GLOBAL_MUSIC_TASK = None

    def __init__(self):
        super().__init__()
        self.cmd_room_id = None
        self.cmd_api_token = None
        for arg in sys.argv:
            arg_clean = arg.strip()
            if len(arg_clean) == 24 and all(c in "0123456789abcdefABCDEF" for c in arg_clean):
                self.cmd_room_id = arg_clean
            elif len(arg_clean) == 64 and all(c in "0123456789abcdefABCDEF" for c in arg_clean):
                self.cmd_api_token = arg_clean

        if self.cmd_room_id:
            if not os.path.exists("settings"):
                try:
                    os.makedirs("settings")
                except:
                    pass
            self.config_path = os.path.join("settings", f"settings_{self.cmd_room_id}.json")
            if not os.path.exists(self.config_path):
                if os.path.exists("config.json"):
                    try:
                        shutil.copy("config.json", self.config_path)
                        print(f"Seeded room config from config.json to {self.config_path}")
                    except Exception as e:
                        print(f"Error seeding config for room {self.cmd_room_id}: {e}")
        else:
            self.config_path = "config.json"

        self.custom_welcome_message = None
        self.custom_goodbye_message = None
        self.promos = {}
        self.promo_tasks = {}
        self.load_config()
        self.load_balances()

        if self.cmd_room_id:
            self.config["ROOM_ID"] = self.cmd_room_id
            self.config["room_id"] = self.cmd_room_id
            self.room_id = self.cmd_room_id
        if self.cmd_api_token:
            self.config["API_TOKEN"] = self.cmd_api_token
        self.is_locked = False
        self.is_looping = True
        self.is_running = True
        self.pending_bot_token = None
        self.floss_emotes = ["dance-floss"]
        self.flash_users = set()
        self.user_loops = {} # Track active loops for users
        self.all_emotes = {} # Full emote list
        self.id_cache = {} # Cache for username -> user_id to speed up invites
        self.original_outfit = None # Store bot's starting outfit
        self.session = None # aiohttp session for Web API
        self.emote_loop_task = None # Handle for emote loop task
        self.heartbeat_task = None # Handle for heartbeat loop task
        self.venomx_conversation_id = None
        try:
            conv_file = os.path.join("settings", "venomx_conv.json")
            if os.path.exists(conv_file):
                with open(conv_file, "r") as f:
                    conv_data = json.load(f)
                    self.venomx_conversation_id = conv_data.get("conversation_id")
        except:
            pass
        self.frozen_users = {} # {user_id: position}
        self.line_positions = getattr(self, "line_positions", []) # loaded by load_config, must not be reset here
        self.line_users = [None] * len(self.line_positions)
        self.line_active = False # when True, new joiners auto-fill the next open line spot
        self.notify_users = getattr(self, "notify_users", []) # loaded by load_config, must not be reset here
        self.banned_users = {} # {username: user_id}
        self.following_user_id = None
        self.user_stats = {}
        self.trivia_active = False
        self.trivia_scores = {}
        self.trivia_current_question = None
        self.trivia_current_answer = None
        self.trivia_task = None
        self.autodj = getattr(self, "autodj", False)
        self.paid_mode = getattr(self, "paid_mode", True)
        self.song_price = getattr(self, "song_price", 10)
        self.last_upnext_ad_song = None
        self.autodj_recent_failed = {}
        self.current_stream_process = None
        self.song_queue = []
        self.current_song = None
        self._autodj_song_pick_retries = 0
        self.autodj_playlist = [
            "Kendrick Lamar - Not Like Us", "Drake - Red Button", "Travis Scott - FE!N",
            "J. Cole - 7 Minute Drill", "Eminem - Houdini", "Future - Like That",
            "21 Savage - redrum", "SZA - Snooze", "Jack Harlow - First Class",
            "Lil Uzi Vert - Just Wanna Rock", "Gunna - fukumean", "Gunna - One Call",
            "Polo G - RAPSTAR", "Rod Wave - Fight The Feeling", "Rod Wave - Come See Me",
            "Lil Baby - Go Hard", "Lil Durk - All My Life", "Lil Durk - Pissed Me Off",
            "NBA YoungBoy - Black Ball", "Moneybagg Yo - Quickie", "Moneybagg Yo - Rock Out",
            "GloRilla - Yeah Glo!", "GloRilla - Lick or Sum", "Sexyy Red - Get It Sexyy",
            "Ice Spice - Think U The Shit", "Ice Spice - Deli", "Central Cee - Band4Band",
            "Central Cee - Doja", "Dave - Sprinter", "Baby Keem - Family Ties",
            "Don Toliver - No Idea", "Don Toliver - Too Many Nights", "Quavo - Honey Bun",
            "Offset - Jealousy", "Takeoff - Hotel Lobby", "Migos - Straightenin",
            "Coi Leray - Players", "Coi Leray - No More Parties", "Rae Sremmurd - Not So Bad",
            "A Boogie Wit da Hoodie - Me and My Guitar", "A Boogie Wit da Hoodie - Look Back At It",
            "YNW Melly - 772 Love Pt. 2", "Trippie Redd - Miss The Rage",
            "Trippie Redd - Trip At Knight", "NLE Choppa - Shotta Flow 7",
            "NLE Choppa - Slut Me Out", "DaBaby - SHAKE SUMN", "DaBaby - ROCKSTAR",
            "Lil Tjay - Beat The Odds Pt. 2", "Lil Tjay - Calling My Phone",
            "Lil Tecca - NEVER LEFT", "Lil Tecca - Ransom", "Kay Flock - Shake It",
            "Dougie B - Brotherly Love", "B-Lovee - My Everything", "Kodak Black - Super Gremlin",
            "Kodak Black - Walk", "Finesse2tymes - Black Visa", "Finesse2tymes - Gucci Flow"
        ]
        if "AUTODJ_PLAYLIST" in getattr(self, "config", {}) and isinstance(self.config.get("AUTODJ_PLAYLIST"), list) and len(self.config["AUTODJ_PLAYLIST"]) > 0:
            self.autodj_playlist = self.config["AUTODJ_PLAYLIST"]
        self.welcome_messages = [
            "Welcome to the room @{user}! 🌟",
            "Hey @{user}, glad you could make it! 👋",
            "Yo @{user}! Grab a seat and enjoy. 🍿",
            "Welcome home @{user}! 🏠✨",
            "Look who it is! Welcome @{user}! 🌈",
            "Ayyy @{user} is in the house! 🥳",
            "Welcome @{user}! Stay a while. ☕",
            "Nice to see you @{user}! 😊",
            "Welcome @{user}! Let's vibe! 🎶",
            "Glad you're here @{user}! ✨",
            "Welcome @{user}! Hope you're having a great day! ☀️",
            "Hello @{user}! Welcome to our little corner. 🍃",
            "Welcome @{user}! Make yourself at home. 🛋️",
            "Hey @{user}! Great to see a new face! 👋",
            "Welcome @{user}! The party's just starting! 🎊",
            "Yo @{user}! Ready to hang out? 😎",
            "Welcome @{user}! Don't be shy, say hi! 👋",
            "Hi @{user}! Welcome to the squad. 💎",
            "Welcome @{user}! You've joined the coolest room. 😎",
            "Hey @{user}! Let's make some memories. ✨",
            "Welcome @{user}! Stay awesome. 🌟",
            "Yo @{user}! Welcome to the vibe zone. 🌀",
            "Welcome @{user}! Feel the rhythm. 🎵",
            "Welcome @{user}! Join the fun! 🎈",
            "Hey @{user}! Glad you're part of the team today. 🤝",
            "Welcome @{user}! Enjoy the music and the mood. 🎷",
            "Yo @{user}! Welcome to the top tier. 🏆",
            "Welcome @{user}! Let's get this party rolling. 🚗",
            "Hey @{user}! Welcome to the family. ❤️",
            "Welcome @{user}! Check out the view. 🏔️",
            "Yo @{user}! Welcome to the chill spot. ❄️",
            "Welcome @{user}! The energy just went up! ⚡",
            "Hey @{user}! Welcome to the spotlight. 🔦",
            "Welcome @{user}! Let's create something cool. 🎨",
            "Yo @{user}! Welcome to the adventure. 🗺️",
            "Welcome @{user}! Glad you found us. 🔍",
            "Hey @{user}! Welcome to the future. 🚀",
            "Welcome @{user}! Let's stay positive. ✨",
            "Yo @{user}! Welcome to the dream world. 💭",
            "Welcome @{user}! You're just in time. ⏳",
            "Hey @{user}! Welcome to the magic. 🪄",
            "Welcome @{user}! Let's spark some joy. ✨",
            "Yo @{user}! Welcome to the harmony. 🎹",
            "Welcome @{user}! Let's make it legendary. ⚔️",
            "Hey @{user}! Welcome to the oasis. 🌴",
            "Welcome @{user}! Let's ride the wave. 🌊",
            "Yo @{user}! Welcome to the summit. ⛰️",
            "Welcome @{user}! Let's shine together. ✨",
            "Hey @{user}! Welcome to the galaxy. 🌌",
            "Welcome @{user}! You're the missing piece. 🧩"
        ]
        self.vip_welcome_messages = [
            "👑 MASSIVE WELCOME BACK TO OUR VIP @{user}! 👑",
            "✨ A true legend has entered! Welcome @{user}! ✨",
            "🌟 Make way for our VIP member, @{user}! 🌟",
            "💎 The high roller @{user} is here! Welcome! 💎",
            "🔥 THE MVP IS HERE! Welcome back @{user}! 🔥",
            "🌈 Our favorite VIP @{user} just joined the party! 🌈",
            "🏆 A champion enters the room! Welcome @{user}! 🏆",
            "⚡ The room just got 10x brighter! Welcome VIP @{user}! ⚡",
            "🛸 Welcome back to your kingdom, @{user}! 👾",
            "🌹 Sending extra love to our VIP @{user}! Welcome! 🌹",
            "🚀 To the moon! Our VIP @{user} has arrived! 🚀",
            "🎊 Celebration time! VIP @{user} is here! 🎊",
            "💥 BOOM! The one and only @{user} has joined! 💥",
            "🎸 Rock star @{user} in the building! Welcome! 🎸",
            "🥂 Cheers to our amazing VIP, @{user}! 🥂",
            "🛡️ The elite @{user} has entered the chat! 🛡️",
            "🎭 Welcome to the show, VIP @{user}! 🎭",
            "🏰 Welcome back to your castle, @{user}! 🏰",
            "💫 Shine bright like a diamond, @{user}! Welcome VIP! 💫",
            "🌋 THE GOAT @{user} HAS ARRIVED! 🌋"
        ]
        self.owner_welcome_messages = [
            "👑 ALL HAIL THE CREATOR @{user}! 👑",
            "⚡ THE LEGENDARY OWNER @{user} IS HERE! ⚡",
            "🏰 Welcome back to your throne, @{user}! 🏰",
            "🔥 THE BOSS @{user} HAS ARRIVED! 🔥",
            "✨ The room is now complete! Welcome Owner @{user}! ✨",
            "🌟 A god among men! Welcome @{user}! 🌟",
            "🛡️ The guardian of this world, @{user}! 🛡️",
            "🚀 The captain @{user} is on deck! 🚀",
            "💎 The highest rank has entered: @{user}! 💎",
            "🌋 THE ULTIMATE POWER @{user} IS HERE! 🌋"
        ]
        self.mod_welcome_messages = [
            "👮 MODERATOR ON DUTY: Welcome @{user}! 👮",
            "⚔️ The enforcer @{user} has joined! ⚔️",
            "🛡️ Welcome back, Protector @{user}! 🛡️",
            "⚡ Safety first! Welcome Mod @{user}! ⚡",
            "🔥 RESPECT! Our Moderator @{user} is here! 🔥",
            "⚖️ The scales of justice arrive: @{user}! ⚖️",
            "📢 Attention! Mod @{user} has entered! 📢",
            "💎 Our trusted Moderator @{user} is online! 💎",
            "🚀 Clear the way for Mod @{user}! 🚀",
            "✨ Glad to have you here, Mod @{user}! ✨"
        ]
        self.goodbye_messages = [
            "✌️ Until next time @{user}! Keep shining! 🎉",
            "✌️ See you later @{user} Wishing you the best! 🌟",
            "Bye @{user}! Take it easy! 🏠",
            "✌️ Until next time @{user}! Wishing you the best! 🌟",
            "⏳ Farewell @{user} Come back anytime! 🌺",
            "Take care @{user}! Wishing you the best! 🌟",
            "💫 Adios @{user}! Stay safe! 🌊",
            "Until next time @{user}! Come back anytime! 🌙",
            "🎈 Catch you later, @{user}! Stay awesome!",
            "Goodbye @{user}! Stay awesome! 🌈",
            "🌈 Bye @{user} Have a great day! ✌️",
            "🌟 Goodbye @{user}! See you soon! 🌈",
            "⏳ Take care @{user}! See you soon! ☕",
            "See you later @{user}! Stay awesome! 🌺",
            "🌟 Catch you later @{user}! Wishing you the best! 💫",
            "🌈 Goodbye @{user}! Stay safe! 🎈",
            "Peace out @{user}! Don't be a stranger! 🏠",
            "🌊 See ya @{user} See you soon! 🏠",
            "✌️ See ya, @{user}! Have a great day!",
            "Farewell @{user}! Take it easy! ✨",
            "Catch you later @{user}! Have a great day! 🎈",
            "✨ Until next time @{user} It was fun having you! 🌙",
            "🍂 Take care, @{user}! It was fun having you!",
            "🌙 Take care @{user} Wishing you the best! 🌊",
            "🏠 Catch you later @{user} Don't be a stranger! 🌟",
            "🌙 Peace out @{user}! Wishing you the best! 🍂",
            "✨ Goodbye @{user}! Come back anytime! 🍂",
            "🌙 Farewell, @{user}! Stay awesome!",
            "☕ Until next time @{user}! Have a great day! 🌊",
            "Until next time @{user}! Keep shining! 🌊",
            "✌️ Farewell @{user} Don't be a stranger! ⏳",
            "✨ Until next time @{user} Keep shining! 🎉",
            "🍂 Catch you later @{user} Come back anytime! 🌊",
            "🌟 Take care @{user} Keep shining! 💫",
            "Until next time @{user}! Don't be a stranger! 🌺",
            "🌈 Catch you later @{user}! Stay awesome! ☕",
            "👋 Bye @{user}! Stay safe! 🎉",
            "🌊 Farewell, @{user}! Stay safe!",
            "🌟 Adios @{user}! Have a great day! 🌙",
            "✨ Take care, @{user}! Stay safe!",
            "🎈 See ya @{user} Stay awesome! 🌈",
            "👋 Take care @{user}! Stay awesome! 🌺",
            "🌈 Catch you later @{user}! Come back anytime! 🌟",
            "🎈 Peace out @{user}! Don't be a stranger! 🎈",
            "👋 See ya @{user}! See you soon! 💫",
            "🎈 Goodbye, @{user}! Don't be a stranger!",
            "🌺 Take care, @{user}! Come back anytime!",
            "Catch you later @{user}! Keep shining! 👋",
            "🍂 Take care, @{user}! Keep shining!",
            "💫 Catch you later @{user}! Keep shining! 🏠"
        ]
        self.vip_goodbye_messages = [
            "👑 Goodbye @{user}! You rock! 🏆",
            "Our VIP is departing! @{user}! The room won't be the same without you! 🔥",
            "Goodbye @{user}! You rock! 🏆",
            "👑 Sending love to our departing VIP @{user}! Stay legendary! 🥇",
            "💎 Goodbye @{user} The room just got dimmer! 🍾",
            "💎 To the moon and back,, @{user}! Come back soon!",
            "🍾 So long VIP @{user}! Goodbye! ⚡",
            "⚡ Farewell champion @{user} See you later! 🚀",
            "🏆 Goodbye @{user} Stay legendary! 🥂",
            "🥂 Our VIP is departing!, @{user}! Always a pleasure!",
            "Farewell to our amazing VIP @{user}! Stay legendary! 🥂",
            "Goodbye @{user}! Always a pleasure! 🌈",
            "Goodbye @{user}! You rock! 👑",
            "👑 Goodbye MVP, @{user}! Always a pleasure!",
            "👑 Our VIP is departing!, @{user}! The room won't be the same without you!",
            "💎 Goodbye MVP @{user} See you later! 🥇",
            "🏆 To the moon and back, @{user} Always a pleasure! 🥂",
            "🌟 Farewell champion @{user} We'll miss you! ✨",
            "🌹 Farewell to our amazing VIP, @{user}! We'll miss you!",
            "Goodbye @{user}! The room just got dimmer! 🌟",
            "💎 Farewell champion, @{user}! Come back soon!",
            "Farewell champion @{user}! Come back soon! 🚀",
            "VIP is leaving! @{user}! Stay legendary! 💫",
            "🔥 Farewell champion @{user} Goodbye! 🔥",
            "🌈 Goodbye MVP @{user} See you later! 🥂",
            "🚀 Catch you later VIP, @{user}! Come back soon!",
            "🥇 Farewell to our amazing VIP @{user} Stay awesome! 🍾",
            "To the moon and back, @{user}! Stay awesome! 🥇",
            "💫 Catch you later VIP @{user}! The room just got dimmer! 🍾",
            "🚀 Catch you later VIP, @{user}! See you later!",
            "So long VIP @{user}! See you later! 👑",
            "🥂 Farewell champion, @{user}! Always a pleasure!",
            "🍾 Goodbye @{user} Stay legendary! 🥂",
            "👑 So long VIP, @{user}! We'll miss you!",
            "🚀 Goodbye @{user} Goodbye! 🥂",
            "Our VIP is departing! @{user}! Always a pleasure! 🍾",
            "🏆 Farewell champion @{user}! You rock! 💫",
            "Farewell champion @{user}! Always a pleasure! 🌈",
            "🥇 Farewell to our amazing VIP @{user}! Goodbye! 💫",
            "🔥 Farewell to our amazing VIP @{user} Come back soon! 🏆",
            "Farewell champion @{user}! Come back soon! 👑",
            "🥇 Sending love to our departing VIP, @{user}! Come back soon!",
            "🌹 Sending love to our departing VIP, @{user}! The room won't be the same without you!",
            "💖 Sending love to our departing VIP @{user} The room just got dimmer! 🍾",
            "✨ Our VIP is departing!, @{user}! Always a pleasure!",
            "💖 Goodbye @{user} Stay awesome! 🌹",
            "Sending love to our departing VIP @{user}! Always a pleasure! 🍾",
            "⚡ Sending love to our departing VIP @{user} Stay awesome! ⚡",
            "Farewell to our amazing VIP @{user}! Come back soon! 💫",
            "🏆 Our VIP is departing!, @{user}! Stay legendary!"
        ]
        self.owner_goodbye_messages = [
            "⚡ THE ULTIMATE POWER @{user} IS LEAVING! 🔱",
            "Goodbye guardian @{user}! The room feels empty without you! 🌋",
            "Goodbye @{user}! IS LEAVING! All hail! 🏰",
            "🌋 THE CREATOR @{user}! See you soon Creator! 👑",
            "Goodbye @{user}! Your throne awaits your return! 🌟",
            "THE CREATOR @{user}! IS LEAVING! All hail! 👁️",
            "🌌 Highest rank departing: @{user}! IS LEAVING! 👑",
            "🏰 Goodbye @{user}! The room feels empty without you! 🌋",
            "👑 Goodbye @{user} IS DEPARTING! 🚀",
            "🌟 Captain, @{user}! The room feels empty without you!",
            "👁️ Captain, @{user}! We await your return!",
            "Goodbye guardian @{user}! The room feels empty without you! 🛡️",
            "Goodbye Owner @{user}! IS LEAVING! All hail! ✨",
            "🌟 Goodbye Owner @{user}! IS LEAVING! All hail! 👑",
            "🔱 Farewell to the legendary owner, @{user}! The room feels empty without you!",
            "Goodbye Owner @{user}! IS LEAVING! 👑",
            "Farewell to the legendary owner @{user}! See you soon Creator! 💎",
            "👁️ Captain @{user} Your throne awaits your return! 👁️",
            "👑 Farewell to the legendary owner @{user} IS LEAVING! 🌟",
            "🔥 Goodbye @{user}! IS DEPARTING! 🐉",
            "🌟 THE CREATOR, @{user}! The room feels empty without you!",
            "🚀 Farewell to the legendary owner @{user} Your throne awaits your return! 🔱",
            "🌌 THE BOSS @{user} IS LEAVING! All hail! 👑",
            "🔥 Farewell god among men @{user}! Master of the realm! 🛡️",
            "Highest rank departing: @{user}! is signing off! 💎",
            "👑 THE ULTIMATE POWER, @{user}! IS DEPARTING!",
            "✨ THE CREATOR @{user}! IS DEPARTING! 🐉",
            "THE ULTIMATE POWER @{user}! See you soon Creator! 🌟",
            "Farewell to the legendary owner @{user}! is signing off! 🚀",
            "🏰 Captain @{user}! Take care Boss! 🔱",
            "Goodbye Owner @{user}! Take care Boss! 🐉",
            "👁️ THE CREATOR, @{user}! Your throne awaits your return!",
            "🏰 Highest rank departing:, @{user}! IS LEAVING!",
            "🛡️ THE ULTIMATE POWER @{user} IS LEAVING! 👑",
            "🌌 Farewell god among men, @{user}! IS DEPARTING!",
            "👑 Goodbye, @{user}! is signing off!",
            "🔥 THE CREATOR @{user}! Master of the realm! ✨",
            "🏰 Goodbye guardian @{user} IS LEAVING! All hail! 💎",
            "🌌 Goodbye, @{user}! We await your return!",
            "🐉 THE ULTIMATE POWER, @{user}! is signing off!",
            "THE CREATOR @{user}! IS LEAVING! All hail! 🔥",
            "👁️ Goodbye @{user} IS LEAVING! All hail! 🛡️",
            "🚀 THE CREATOR @{user}! is signing off! ✨",
            "👑 THE CREATOR, @{user}! We await your return!",
            "🔥 Highest rank departing: @{user}! See you soon Creator! 🚀",
            "🏰 Goodbye guardian, @{user}! Take care Boss!",
            "Goodbye Owner @{user}! See you soon Creator! 🛡️",
            "THE ULTIMATE POWER @{user}! Master of the realm! ⚡",
            "⚡ Goodbye Owner, @{user}! Take care Boss!",
            "THE BOSS @{user}! We await your return! ✨"
        ]
        self.mod_goodbye_messages = [
            "🔥 The scales of justice depart: @{user}! has left! 👁️‍🗨️",
            "🛑 Clear the way for Mod, @{user}! See you soon Mod!",
            "MODERATOR @{user}! Thank you for your service! 🛑",
            "Farewell enforcer @{user}! Stay safe! ⚖️",
            "🛡️ The scales of justice depart: @{user} Thank you for your service! 💎",
            "🛑 MODERATOR @{user}! See you soon Mod! ✨",
            "💎 Attention! Mod, @{user}! has left!",
            "Attention! Mod @{user}! IS SIGNING OFF! ⚖️",
            "⚔️ Farewell enforcer, @{user}! IS SIGNING OFF!",
            "📢 Goodbye Protector, @{user}! IS SIGNING OFF!",
            "🔨 Goodbye Protector @{user} has left! 👮",
            "🔨 MODERATOR @{user} We'll miss you! 👁️‍🗨️",
            "🚀 Glad to have you here, Mod @{user} is offline! 👮",
            "Clear the way for Mod @{user}! Keep the peace! ⚔️",
            "💎 Mod, @{user}! We'll miss you!",
            "🔨 Attention! Mod @{user}! See you soon Mod! 🛡️",
            "✨ Glad to have you here, Mod @{user}! Keep the peace! ✨",
            "🚔 Goodbye Protector @{user}! Thank you for your service! ⚔️",
            "🚀 Clear the way for Mod @{user} Logging off! ⚖️",
            "👮 Farewell enforcer @{user}! IS SIGNING OFF! 🔥",
            "Farewell enforcer @{user}! IS SIGNING OFF! 🚀",
            "Glad to have you here, Mod @{user}! Stay safe! 💎",
            "🚀 The scales of justice depart:, @{user}! Over and out!",
            "🚔 MODERATOR @{user} Over and out! 🔨",
            "🚔 MODERATOR, @{user}! Keep the peace!",
            "The scales of justice depart: @{user}! has left! 💎",
            "🔥 Attention! Mod @{user} Over and out! 🛡️",
            "🛑 MODERATOR @{user}! is offline! 📢",
            "🛑 Mod, @{user}! has left!",
            "👮 Goodbye Protector @{user}! Over and out! ✨",
            "👁️‍🗨️ Clear the way for Mod @{user} Keep the peace! 👮",
            "💎 MODERATOR @{user} is offline! ✨",
            "🔥 Goodbye Protector @{user} Stay safe! 🚀",
            "👁️‍🗨️ The scales of justice depart: @{user}! Over and out! 🛑",
            "Farewell enforcer @{user}! IS SIGNING OFF! ✨",
            "MODERATOR @{user}! Over and out! 🔨",
            "🛑 Attention! Mod @{user}! Logging off! ✨",
            "🛡️ Mod @{user} IS SIGNING OFF! ⚖️",
            "🛡️ Clear the way for Mod @{user}! See you soon Mod! 🛡️",
            "👮 MODERATOR @{user}! Thank you for your service! ⚡",
            "👁️‍🗨️ The scales of justice depart:, @{user}! Over and out!",
            "🛡️ Attention! Mod @{user} Thank you for your service! ✨",
            "💎 Mod @{user}! Over and out! 🛡️",
            "🛡️ Mod @{user} IS SIGNING OFF! 👁️‍🗨️",
            "Farewell enforcer @{user}! Keep the peace! 👁️‍🗨️",
            "💎 RESPECT! Farewell Moderator @{user} Stay safe! 👁️‍🗨️",
            "Attention! Mod @{user}! Logging off! ⚡",
            "Attention! Mod @{user}! Stay safe! ⚡",
            "💎 Farewell enforcer, @{user}! Thank you for your service!",
            "💎 Our trusted Moderator, @{user}! See you soon Mod!"
        ]
        self.load_floss_emotes()
        self.load_all_emotes_json()

    def load_floss_emotes(self):
        try:
            with open("emote_list_backup.json", "r") as f:
                emotes_data = json.load(f)
                # Filter for any emote that has "floss" in its key or value (id)
                for key, data in emotes_data.items():
                    if isinstance(data, dict) and "id" in data:
                        if "floss" in key.lower() or "floss" in data["id"].lower():
                            if data["id"] not in self.floss_emotes:
                                self.floss_emotes.append(data["id"])
            print(f"Loaded floss emotes: {self.floss_emotes}")
        except Exception as e:
            print(f"Error loading floss emotes from JSON: {e}")

    def load_all_emotes_json(self):
        try:
            with open("emote_list_backup.json", "r") as f:
                self.all_emotes = json.load(f)
            print(f"Loaded {len(self.all_emotes)} emotes.")
        except Exception as e:
            print(f"Error loading all emotes from JSON: {e}")

    def is_valid_room_id(self, room_id: str) -> bool:
        if not room_id:
            return False
        return len(room_id) == 24 and all(c in "0123456789abcdefABCDEF" for c in room_id)

    def extract_hex_ids_from_text(self, text: str):
        return re.findall(r"[0-9a-fA-F]{24}", text or "")

    def parse_room_id(self, room_input: str) -> str:
        if not room_input:
            return None
        raw = room_input.strip().strip("`").strip("'").strip('"')

        # 1. Quick pass: if the whole input is already a valid 24-char hex ID, return immediately
        if self.is_valid_room_id(raw):
            return raw

        # 2. Extract all 24-char hex IDs from the entire input (covers query params, fragments, paths)
        all_hex_ids = self.extract_hex_ids_from_text(raw)
        if not all_hex_ids:
            return None

        # 3. Parse URL query params for intelligent priority ordering
        room_priority_params = ["ownedRoomId", "owned_room_id", "roomId", "room_id", "roomID",
                                "room", "targetRoomId", "target_room_id", "destRoomId", "destinationRoomId"]
        invite_priority_params = ["invite_id", "inviteId", "inviteID", "invite"]

        param_values = {}
        try:
            if "?" in raw or "&" in raw:
                query_part = raw
                if "?" in raw:
                    query_part = raw.split("?", 1)[1]
                # Handle fragments too
                if "#" in query_part:
                    query_part = query_part.split("#", 1)[0]
                for kv in query_part.split("&"):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        param_values[k.strip()] = urllib.parse.unquote(v.strip())
        except Exception:
            pass

        # Also inspect path segments for the standard room id after "room/"
        path_segment_id = None
        for marker in ["/room/", "/r/"]:
            if marker in raw:
                tail = raw.split(marker, 1)[1]
                for sep in ["?", "&", "/", "#"]:
                    if sep in tail:
                        tail = tail.split(sep, 1)[0]
                if self.is_valid_room_id(tail):
                    path_segment_id = tail
                    break

        # Rank every extracted hex ID by how strongly its context suggests it's a room id
        scored = []  # list of (score, id) — higher score = higher priority
        for hid in all_hex_ids:
            score = 0
            # Path match after room/ is best
            if hid == path_segment_id:
                score += 1000
            # Find which param keys hold this value, add score based on param name priority
            for pk, pv in param_values.items():
                if hid in pv:
                    pk_l = pk.lower()
                    if any(rp.lower() == pk_l for rp in room_priority_params):
                        score += 500
                    elif "room" in pk_l:
                        score += 200
                    elif any(ip.lower() == pk_l for ip in invite_priority_params):
                        score -= 50  # invite ids are LEAST likely to be room ids
                    elif pk_l == "id" and "world" in raw.lower():
                        score += 10  # plain id on world page = world id, low priority
            scored.append((score, hid))

        # Deduplicate by id, keeping best score per id
        best_per_id = {}
        for s, hid in scored:
            if hid not in best_per_id or s > best_per_id[hid]:
                best_per_id[hid] = s
        sorted_ids = sorted(best_per_id.items(), key=lambda x: x[1], reverse=True)
        if not sorted_ids:
            return None
        return sorted_ids[0][0]

    def parse_room_id_candidates(self, room_input: str):
        if not room_input:
            return []
        raw = room_input.strip().strip("`").strip("'").strip('"')
        if self.is_valid_room_id(raw):
            return [raw]
        all_hex_ids = list(dict.fromkeys(self.extract_hex_ids_from_text(raw)))
        if not all_hex_ids:
            return []
        param_values = {}
        try:
            if "?" in raw or "&" in raw:
                query_part = raw.split("?", 1)[1] if "?" in raw else raw
                if "#" in query_part:
                    query_part = query_part.split("#", 1)[0]
                for kv in query_part.split("&"):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        param_values[k.strip()] = urllib.parse.unquote(v.strip())
        except Exception:
            pass

        def score_id(hid):
            s = 0
            for pk, pv in param_values.items():
                if hid in pv:
                    pk_l = pk.lower()
                    if "ownedroom" in pk_l or pk_l in ("roomid", "room_id", "room"):
                        s += 500
                    elif "room" in pk_l:
                        s += 200
                    elif "invite" in pk_l:
                        s -= 100
            return s

        all_hex_ids.sort(key=lambda hid: score_id(hid), reverse=True)
        return all_hex_ids

    async def verify_room_exists(self, room_id: str) -> bool:
        if not self.is_valid_room_id(room_id):
            return False
        try:
            session = await self._get_session()
            user_agents = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
                "Highrise/3.16.0 (iPhone; iOS 17.1; Scale/3.00)",
            ]
            for ua in user_agents:
                headers = {"User-Agent": ua, "Accept": "application/json"}
                for url in [
                    f"https://webapi.highrise.game/v1/rooms/{room_id}",
                    f"https://webapi.highrise.game/rooms/{room_id}",
                ]:
                    try:
                        async with session.get(url, headers=headers, timeout=8) as resp:
                            if resp.status == 200:
                                return True
                            elif resp.status == 404:
                                continue
                    except:
                        continue
        except Exception as e:
            print(f"Room verify error: {e}")
        return True

    async def safe_move_user_to_room(self, user_id: str, room_id: str, username: str = "unknown") -> tuple[bool, str]:
        if not self.is_valid_room_id(room_id):
            return False, "Invalid room ID format"
        if not user_id:
            return False, "Missing user ID"
        max_retries = 3
        last_error = "Unknown error"
        for attempt in range(1, max_retries + 1):
            try:
                result = await self.highrise.move_user_to_room(user_id, room_id)
                if isinstance(result, Error):
                    last_error = getattr(result, "message", str(result)) or str(result)
                    if attempt < max_retries and ("server" in last_error.lower() or "timeout" in last_error.lower() or "rate" in last_error.lower()):
                        await asyncio.sleep(0.5 * attempt)
                        continue
                    return False, last_error
                return True, "Success"
            except Exception as e:
                last_error = str(e)
                emsg = last_error.lower()
                if attempt < max_retries and any(k in emsg for k in ["server", "timeout", "rate", "temporarily", "connection"]):
                    await asyncio.sleep(0.5 * attempt)
                    continue
                if any(k in emsg for k in ["not in room", "cannot write to closing transport", "closing", "transport"]):
                    return False, "User connection issue"
                if "permission" in emsg or "not allowed" in emsg or "moderator" in emsg:
                    return False, "Insufficient permissions"
                return False, last_error
        return False, last_error

    def load_config(self):
        try:
            with open(self.config_path, "r") as f:
                self.config = json.load(f)
                # Support both old OWNER (string) and new OWNERS (list)
                if "OWNER" in self.config and "OWNERS" not in self.config:
                    self.owners = [self.config["OWNER"]]
                else:
                    self.owners = self.config.get("OWNERS", ["_inferno__"])
                
                # Load permanent owners directly from config.json to ensure it always respects the main file
                try:
                    with open("config.json", "r") as main_f:
                        main_cfg = json.load(main_f)
                        self.permanent_owners = main_cfg.get("PERMANENT_OWNERS", [])
                except:
                    self.permanent_owners = []
                
                # Fallback if empty
                if not self.permanent_owners:
                    self.permanent_owners = self.config.get("PERMANENT_OWNERS", [self.owners[0] if self.owners else "ElPhantom"])
                
                # Ensure all permanent owners are in the general owners list
                for po in self.permanent_owners:
                    if po.lower() not in [o.lower() for o in self.owners]:
                        self.owners.append(po)
                
                self.saved_pos = self.config.get("SAVED_POSITION")
                self.spawn_pos = self.config.get("SPAWN_POSITION")
                self.subscribers = self.config.get("SUBSCRIBERS", [])
                self.autodj = self.config.get("AUTODJ_ENABLED", False)
                self.paid_mode = self.config.get("PAID_MODE", True)
                self.song_price = self.config.get("SONG_PRICE", 10)
                self.vips = self.config.get("VIPS", [])
                self.mods = self.config.get("MODERATORS", [])
                self.room_id = self.config.get("ROOM_ID")
                self.tele_locations = self.config.get("TELEPORT_LOCATIONS", {})
                self.custom_welcome_message = self.config.get("CUSTOM_WELCOME_MESSAGE", None)
                self.custom_goodbye_message = self.config.get("CUSTOM_GOODBYE_MESSAGE", None)
                self.bot_language = self.config.get("LANGUAGE", "en")
                self.persistent_bot_emote = self.config.get("PERSISTENT_BOT_EMOTE", None)
                self.personal_welcomes = self.config.get("PERSONAL_WELCOMES", {})
                self.promos = self.config.get("PROMOS", {})
                self.autotip_on = self.config.get("AUTOTIP_ON", False)
                self.autotip_time = self.config.get("AUTOTIP_TIME", 30)
                self.autotip_amount = self.config.get("AUTOTIP_AMOUNT", 5)
                self.df_pos1 = self.config.get("DF_POS1", None)
                self.df_pos2 = self.config.get("DF_POS2", None)
                self.autodf_on = self.config.get("AUTODF_ON", False)
                self.autotele_on = self.config.get("AUTOTELE_ON", False)
                self.jail_pos = self.config.get("jail", None)
                self.jailed_users = self.config.get("jailed_users", {})
                self.bail_pos = self.config.get("bail_pos", None)
                self.vip_prices = self.config.get("VIP_PRICES", {"3": "0", "6": "0", "12": "0"})
                self.vip_expirations = self.config.get("VIP_EXPIRATIONS", {})
                self.protected_users = self.config.get("PROTECTED_USERS", [])
                self.line_positions = self.config.get("LINE_POSITIONS", [])
                self.notify_users = self.config.get("NOTIFY_USERS", [])
        except:
            self.config = {}
            self.owners = ["V4SU__"]
            self.permanent_owners = ["Elphantom"]
            self.saved_pos = None
            self.spawn_pos = None
            self.subscribers = []
            self.vips = []
            self.mods = []
            self.room_id = None
            self.tele_locations = {}
            self.custom_welcome_message = None
            self.custom_goodbye_message = None
            self.bot_language = "en"
            self.line_positions = []
            self.notify_users = []
            self.persistent_bot_emote = None
            self.personal_welcomes = {}
            self.promos = {}
            self.autotip_on = False
            self.autotip_time = 30
            self.autotip_amount = 5
            self.df_pos1 = None
            self.df_pos2 = None
            self.autodf_on = False
            self.autotele_on = False
            self.jail_pos = None
            self.jailed_users = {}
            self.bail_pos = None
            self.vip_expirations = {}
            self.protected_users = []
            
        self.load_ratings()
        self.load_radio()
        self.load_user_data()

    def save_config(self):
        try:
            self.config["OWNERS"] = self.owners
            self.config["SUBSCRIBERS"] = self.subscribers
            self.config["VIPS"] = self.vips
            self.config["MODERATORS"] = self.mods
            self.config["TELEPORT_LOCATIONS"] = self.tele_locations
            self.config["PERSONAL_WELCOMES"] = getattr(self, "personal_welcomes", {})
            self.config["AUTODJ_ENABLED"] = getattr(self, "autodj", False)
            self.config["PAID_MODE"] = getattr(self, "paid_mode", True)
            self.config["SONG_PRICE"] = getattr(self, "song_price", 10)
            self.config["LANGUAGE"] = getattr(self, "bot_language", "en")
            if getattr(self, "persistent_bot_emote", None):
                self.config["PERSISTENT_BOT_EMOTE"] = self.persistent_bot_emote
            elif "PERSISTENT_BOT_EMOTE" in self.config:
                del self.config["PERSISTENT_BOT_EMOTE"]
            if self.custom_welcome_message is not None:
                self.config["CUSTOM_WELCOME_MESSAGE"] = self.custom_welcome_message
            elif "CUSTOM_WELCOME_MESSAGE" in self.config:
                del self.config["CUSTOM_WELCOME_MESSAGE"]
            
            if getattr(self, "custom_goodbye_message", None) is not None:
                self.config["CUSTOM_GOODBYE_MESSAGE"] = self.custom_goodbye_message
            elif "CUSTOM_GOODBYE_MESSAGE" in self.config:
                del self.config["CUSTOM_GOODBYE_MESSAGE"]
            self.config["PROMOS"] = self.promos
            self.config["AUTOTIP_ON"] = self.autotip_on
            self.config["AUTOTIP_TIME"] = self.autotip_time
            self.config["AUTOTIP_AMOUNT"] = self.autotip_amount
            self.config["DF_POS1"] = self.df_pos1
            self.config["DF_POS2"] = self.df_pos2
            self.config["AUTODF_ON"] = self.autodf_on
            self.config["AUTOTELE_ON"] = getattr(self, "autotele_on", False)
            self.config["jail"] = getattr(self, "jail_pos", None)
            self.config["jailed_users"] = getattr(self, "jailed_users", {})
            self.config["bail_pos"] = getattr(self, "bail_pos", None)
            self.config["VIP_PRICES"] = getattr(self, "vip_prices", {"3": "0", "6": "0", "12": "0"})
            self.config["VIP_EXPIRATIONS"] = getattr(self, "vip_expirations", {})
            self.config["AUTODJ_PLAYLIST"] = getattr(self, "autodj_playlist", [])
            self.config["PROTECTED_USERS"] = getattr(self, "protected_users", [])
            self.config["LINE_POSITIONS"] = getattr(self, "line_positions", [])
            self.config["NOTIFY_USERS"] = getattr(self, "notify_users", [])
            
            # Save to the active config path
            with open(self.config_path, "w") as f:
                json.dump(self.config, f, indent=4)
                
            # If we are using a room-specific config path, also sync it to the master config.json
            if self.config_path != "config.json":
                try:
                    if os.path.exists("config.json"):
                        with open("config.json", "r") as f:
                            main_config = json.load(f)
                    else:
                        main_config = {}
                    
                    # Update all relevant keys in config.json
                    for key in ["OWNERS", "SUBSCRIBERS", "VIPS", "MODERATORS", "TELEPORT_LOCATIONS", "CUSTOM_WELCOME_MESSAGE", "CUSTOM_GOODBYE_MESSAGE", "LANGUAGE", "PERSISTENT_BOT_EMOTE", "PROMOS", "jail", "jailed_users", "bail_pos", "AUTOTELE_ON", "VIP_PRICES", "AUTODJ_ENABLED", "NOTIFY_USERS"]:
                        if key in self.config:
                            main_config[key] = self.config[key]
                        elif key == "CUSTOM_WELCOME_MESSAGE" and "CUSTOM_WELCOME_MESSAGE" in main_config:
                            del main_config["CUSTOM_WELCOME_MESSAGE"]
                        elif key == "CUSTOM_GOODBYE_MESSAGE" and "CUSTOM_GOODBYE_MESSAGE" in main_config:
                            del main_config["CUSTOM_GOODBYE_MESSAGE"]
                            
                    with open("config.json", "w") as f:
                        json.dump(main_config, f, indent=4)
                    print("Successfully synced configuration changes to config.json.")
                except Exception as e:
                    print(f"Error syncing configuration to config.json: {e}")
        except Exception as e:
            print(f"Error saving config: {e}")

    def load_ratings(self):
        if not hasattr(self, "song_ratings"):
            self.song_ratings = {}
        import os, json
        try:
            if os.path.exists("ratings.json"):
                with open("ratings.json", "r") as f:
                    self.song_ratings = json.load(f)
        except Exception as e:
            print(f"Error loading ratings: {e}")

    def save_ratings(self):
        import json
        try:
            with open("ratings.json", "w") as f:
                json.dump(getattr(self, "song_ratings", {}), f, indent=4)
        except Exception as e:
            print(f"Error saving ratings: {e}")

    def load_balances(self):
        try:
            with open("balance.json", "r") as f:
                self.balances = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.balances = {}
            self.save_balances()

    def save_balances(self):
        try:
            with open("balance.json", "w") as f:
                json.dump(self.balances, f, indent=4)
        except Exception as e:
            print(f"Error saving balances: {e}")

    def load_radio(self):
        if not hasattr(self, "icecast_url"):
            self.icecast_url = ""
        import os, json
        
        radio_file = f"radio_{self.room_id}.json" if hasattr(self, "room_id") and self.room_id else "radio.json"
        
        try:
            if os.path.exists(radio_file):
                with open(radio_file, "r") as f:
                    content = f.read().strip()
                    if not content:
                        return
                    data = json.loads(content)
                    self.icecast_url = data.get("icecast_url", "")
        except json.JSONDecodeError:
            print(f"Error: {radio_file} is corrupted or empty. Could not load icecast_url.")
        except Exception as e:
            print(f"Error loading radio config: {e}")

    def save_radio(self):
        import json
        
        radio_file = f"radio_{self.room_id}.json" if hasattr(self, "room_id") and self.room_id else "radio.json"
        
        try:
            with open(radio_file, "w") as f:
                json.dump({"icecast_url": getattr(self, "icecast_url", "")}, f, indent=4)
        except Exception as e:
            print(f"Error saving radio config: {e}")

    def load_user_data(self):
        self.user_data = {}
        import os, json
        try:
            if os.path.exists("user_data.json"):
                with open("user_data.json", "r") as f:
                    self.user_data = json.load(f)
        except Exception as e:
            print(f"Error loading user_data: {e}")

    def save_user_data(self):
        import json
        try:
            with open("user_data.json", "w") as f:
                json.dump(getattr(self, "user_data", {}), f, indent=4)
        except Exception as e:
            print(f"Error saving user_data: {e}")

    def get_user_profile(self, user_id, username):
        uid = str(user_id)
        if not hasattr(self, "user_data"):
            self.user_data = {}
        if uid not in self.user_data:
            self.user_data[uid] = {"username": username, "favorites": []}
        else:
            self.user_data[uid]["username"] = username
        return self.user_data[uid]

    def is_vip(self, username):
        if username.lower() not in [v.lower() for v in getattr(self, "vips", [])]:
            return False
            
        vip_expirations = getattr(self, "vip_expirations", {})
        if username.lower() in vip_expirations:
            exp_time = vip_expirations[username.lower()]
            if time.time() > exp_time:
                # Expired, remove from lists
                self.vips = [v for v in getattr(self, "vips", []) if v.lower() != username.lower()]
                del vip_expirations[username.lower()]
                self.vip_expirations = vip_expirations
                self.save_config()
                return False
        return True

    def is_owner(self, username):
        return username.lower() in [o.lower() for o in self.owners]

    def is_mod(self, username):
        return username.lower() in [m.lower() for m in self.mods]

    def is_protected(self, username):
        if not username:
            return False
        clean = str(username).replace("@", "").strip().lower()
        return clean in [p.lower() for p in getattr(self, "protected_users", [])]

    def is_subscribed(self, username):
        u_lower = username.lower()
        if self.is_owner(u_lower) or self.is_mod(u_lower) or self.is_vip(u_lower):
            return True
        return u_lower in {s.lower() for s in self.subscribers}

    async def is_mod_or_owner(self, user_id, username):
        if self.is_owner(username):
            return True
        if username.lower() in [m.lower() for m in self.mods]:
            return True
        try:
            privs = await self.highrise.get_room_privilege(user_id)
            if not isinstance(privs, Error):
                return privs.moderator is True
        except Exception as e:
            print(f"Error checking privileges: {e}")
        return False

    async def run_emote_loop(self):
        """Continuously loop the floss emotes."""
        # Give the bot a few seconds to fully join the room/spawn
        await asyncio.sleep(5)
        while self.is_running:
            try:
                if self.is_looping:
                    for emote_id in self.floss_emotes:
                        if not self.is_looping:
                            break
                        try:
                            await self.highrise.send_emote(emote_id)
                        except Exception as e:
                            # Handle 'not in room' and 'transport' errors locally to prevent spam/restart loops
                            emsg = str(e).lower()
                            if any(k in emsg for k in ["not in room", "closing", "transport", "connection"]):
                                # Error is suppressed/logged simply to avoid spam
                                await asyncio.sleep(10)
                                break # Break the for loop and retry while loop
                            # Let on_error handler decide if this remains
                            await self.on_error(e)
                        # Wait for the emote to finish or a reasonable interval
                        await asyncio.sleep(15) 
                else:
                    await asyncio.sleep(5)  # Wait while loop is paused
            except Exception as e:
                # If we're not running, just exit
                if not self.is_running:
                    break
                # Handle error via on_error
                await self.on_error(e)
                await asyncio.sleep(5)

    async def run_heartbeat_loop(self):
        """Periodically update the bot's online status in a shared registry."""
        await asyncio.sleep(5) # Allow some time for startup
        while self.is_running:
            try:
                # 1. Ensure settings directory exists
                if not os.path.exists("settings"):
                    try: os.makedirs("settings")
                    except: pass
                
                # 2. Get username (check cache or fetch)
                bot_username = None
                for name, uid in self.id_cache.items():
                    if uid == self.my_id:
                        bot_username = name
                        break
                
                if not bot_username:
                    bot_username = await self.get_username_from_id(self.my_id)
                
                if not bot_username:
                    bot_username = "RentABot"
                
                # 3. Read existing registry
                status_file = os.path.join("settings", "bot_status.json")
                status_data = {}
                if os.path.exists(status_file):
                    try:
                        with open(status_file, "r") as f:
                            status_data = json.load(f) or {}
                    except:
                        status_data = {}
                
                # 4. Update own entry
                status_data[self.my_id] = {
                    "username": bot_username,
                    "room_id": self.room_id,
                    "last_seen": time.time()
                }
                
                # 5. Write back
                with open(status_file, "w") as f:
                    json.dump(status_data, f, indent=4)
                    
            except Exception as e:
                print(f"Error in heartbeat loop: {e}")
                
            await asyncio.sleep(15)

    async def run_keep_alive(self):
        """Periodically perform a keep-alive action to maintain the room connection."""
        await asyncio.sleep(10)  # Wait a bit after startup
        while self.is_running:
            try:
                # Simple keep-alive action: fetch room users to keep connection active
                await self.highrise.get_room_users()
                print("[Keep-Alive] Connection check successful")
            except Exception as e:
                error_msg = str(e)
                if "Cannot write to closing transport" in error_msg:
                    pass # Ignore error during shutdown/disconnect
                else:
                    print(f"[Keep-Alive] Error during connection check: {e}")
            await asyncio.sleep(60)  # Check every 60 seconds

    def get_gold_bar_id(self, amount: str):
        mapping = {
            "1": "gold_bar_1",
            "5": "gold_bar_5",
            "10": "gold_bar_10",
            "50": "gold_bar_50",
            "100": "gold_bar_100",
            "500": "gold_bar_500",
            "1k": "gold_bar_1k",
            "1000": "gold_bar_1k",
            "5k": "gold_bar_5000",
            "5000": "gold_bar_5000",
            "10k": "gold_bar_10k",
            "10000": "gold_bar_10k",
        }
        return mapping.get(amount.lower())

    async def get_bot_gold(self):
        try:
            wallet = await self.highrise.get_wallet()
            if isinstance(wallet, Error):
                return 0
            for item in wallet.content:
                if item.type == "gold":
                    return item.amount
            return 0
        except Exception as e:
            print(f"Error fetching gold: {e}")
            return 0

    async def _get_session(self):
        """Unified internal method to manage the aiohttp session with double-check lock."""
        if not hasattr(self, "_session_lock"):
            self._session_lock = asyncio.Lock()
            
        async with self._session_lock:
            if self.session is None or self.session.closed:
                self.session = aiohttp.ClientSession()
        return self.session

    async def get_id_from_name(self, username):

        try:
            room_users = await self.highrise.get_room_users()
            if isinstance(room_users, Error):
                return None
            for user, pos in room_users.content:
                if user.username.lower() == username.lower():
                    return user.id
            
            # If not in room, try Highrise Web API
            return await self.get_user_id_webapi(username)
        except Exception as e:
            print(f"Error getting ID from name: {e}")
            return None

    async def get_user_id_webapi(self, username):
        """Ultra-robust user ID lookup with multi-strategy resolution."""
        clean_name = str(username).replace("@", "").strip()
        name_lower = clean_name.lower()
        
        if name_lower in self.id_cache:
            return self.id_cache[name_lower]

        try:
            session = await self._get_session()
            
            user_agents = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
                "Highrise/3.16.0 (iPhone; iOS 17.1; Scale/3.00)",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1"
            ]

            quoted_name = urllib.parse.quote(clean_name)
            
            # Strategy 1: Direct Profile Fetch (Try multiple API versions)
            for ua in user_agents:
                headers = {"User-Agent": ua, "Accept": "application/json"}
                for url in [
                    f"https://webapi.highrise.game/v1/users/{quoted_name}",
                    f"https://webapi.highrise.game/users/{quoted_name}"
                ]:
                    async with session.get(url, headers=headers, timeout=10) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            uid = data.get("user", {}).get("user_id") or data.get("user_id")
                            if uid:
                                self.id_cache[name_lower] = uid
                                print(f"DEBUG: Resolved ID for {clean_name} via Direct Profile ({url}): {uid}")
                                return uid
                        elif resp.status == 404: continue # Try next URL

            # Strategy 2: Search API
            for ua in user_agents:
                headers = {"User-Agent": ua, "Accept": "application/json"}
                for search_url in [
                    f"https://webapi.highrise.game/v1/users?username={quoted_name}&limit=5",
                    f"https://webapi.highrise.game/users?username={quoted_name}&limit=5"
                ]:
                    async with session.get(search_url, headers=headers, timeout=10) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if isinstance(data, dict) and data.get("users"):
                                for u in data["users"]:
                                    if u.get("username", "").lower() == name_lower:
                                        uid = u.get("user_id")
                                        self.id_cache[name_lower] = uid
                                        print(f"DEBUG: Found ID for {clean_name} via Search ({search_url}): {uid}")
                                        return uid

            return None
        except Exception as e:
            print(f"CRITICAL Search Failure for {clean_name}: {e}")
            return None


    async def process_subscriber_invites(self, requester: User):
        """Ultra-robust invitation process with caching and error reporting."""
        try:
            if not self.subscribers:
                await self.highrise.chat("Subscription list is empty! Add users with -sub @username first.")
                return

            target_usernames = list(set([s.lower() for s in self.subscribers]))
            total_targets = len(target_usernames)
            
            await self.highrise.chat(f"📢 Invite Broadcast: Sending invitations to ALL {total_targets} subscribers... ⏳")

            # 1. Quick Refresh ID Map from current room
            room_users_res = await self.highrise.get_room_users()
            in_room_map = {}
            if not isinstance(room_users_res, Error):
                for u, pos in room_users_res.content:
                    in_room_map[u.username.lower()] = u.id
                    self.id_cache[u.username.lower()] = u.id # Update cache while we're at it

            # 2. Sequential ID Retrieval (Prioritizing Cache)
            user_ids = []
            failed_usernames = []
            
            for username in target_usernames:
                uid = in_room_map.get(username) or self.id_cache.get(username)
                
                if not uid:
                    # Still not found, hit the Web API
                    uid = await self.get_user_id_webapi(username)
                    if uid:
                        await asyncio.sleep(0.15) # Safety throttle
                
                if uid:
                    user_ids.append(uid)
                else:
                    failed_usernames.append(username)

            if not user_ids:
                await self.highrise.chat("❌ Critical: Could not find ANY valid IDs from the subscriber list!")
                return

            # 3. Batch Sending (Max 100 per call)
            sent_count = 0
            for i in range(0, len(user_ids), 100):
                batch = user_ids[i:i+100]
                await self.highrise.send_message_bulk(batch, f"Our room is live! Join the party now! ✨🔊", message_type="invite", room_id=self.room_id)
                sent_count += len(batch)
                if i + 100 < len(user_ids):
                    await asyncio.sleep(1.0) 

            # 4. Final Advanced Summary
            success_msg = f"✅ Broadcast Complete! ({sent_count}/{total_targets} sent)"
            if failed_usernames:
                success_msg += f"\n⚠️ Missing IDs for: {', '.join(failed_usernames[:5])}"
                if len(failed_usernames) > 5:
                    success_msg += " ..."
            
            await self.highrise.chat(success_msg)
                                     
        except Exception as e:
            print(f"Error in process_subscriber_invites: {e}")
            await self.highrise.chat(f"❌ Broadcast process failed: {type(e).__name__}")

    async def get_user_outfit_webapi(self, target):
        """Ultra-robust, multi-strategy fix for global outfit retrieval."""
        if not target: return None
        target_clean = str(target).replace("@", "").strip()
        
        try:
            session = await self._get_session()
            
            # Diverse User-Agents to bypass restrictions
            user_agents = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
                "Highrise/3.16.0 (iPhone; iOS 17.1; Scale/3.00)",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1"
            ]
            
            async def fetch_json(url, ua):
                try:
                    headers = {"User-Agent": ua, "Accept": "application/json", "Accept-Language": "en-US,en;q=0.9"}
                    async with session.get(url, headers=headers, timeout=10) as resp:
                        if resp.status == 200:
                            return await resp.json()
                        elif resp.status == 404: return "NOT_FOUND"
                except: return None
                return None

            def parse_items(data):
                if not data: return None
                outfit = None
                if isinstance(data, list): outfit = data
                elif isinstance(data, dict):
                    # Multi-layer extraction to handle all known API response formats
                    outfit = (data.get("outfit") or 
                             data.get("user", {}).get("outfit") or 
                             data.get("content", {}).get("outfit") or
                             data.get("data", {}).get("outfit"))
                    
                    # If it's still a dict, it might be the "category: item" format
                    if isinstance(outfit, dict):
                        # Some endpoints return { "category": { "id": "...", "amount": 1 } }
                        extracted_list = []
                        for key, val in outfit.items():
                            if isinstance(val, dict) and "id" in val:
                                extracted_list.append(val)
                            elif isinstance(val, str):
                                extracted_list.append({"id": val, "amount": 1})
                        outfit = extracted_list if extracted_list else None
                
                if outfit and isinstance(outfit, list):
                    items = []
                    for i in outfit:
                        if isinstance(i, dict) and "id" in i:
                            items.append(Item(type='clothing', id=i["id"], amount=i.get("amount", 1)))
                        elif isinstance(i, str): # Handle simple ID lists if they exist
                            items.append(Item(type='clothing', id=i, amount=1))
                    return items if items else None
                return None

            # Strategy 1: Immediate Direct Name-to-Outfit Fetch
            quoted_name = urllib.parse.quote(target_clean)
            for ua in user_agents:
                for url in [
                    f"https://webapi.highrise.game/v1/users/{quoted_name}/outfit",
                    f"https://webapi.highrise.game/users/{quoted_name}/outfit"
                ]:
                    data = await fetch_json(url, ua)
                    if data == "NOT_FOUND": continue
                    items = parse_items(data)
                    if items: return items

            # Strategy 2: ID Resolution via Search (if not a hex ID)
            resolved_id = None
            is_hex_id = len(target_clean) == 24 and all(c in "0123456789abcdef" for c in target_clean.lower())
            
            if not is_hex_id:
                resolved_id = await self.get_user_id_webapi(target_clean)
            
            id_to_use = resolved_id or target_clean
            
            # Strategy 3: Exhaustive endpoint search with the best ID found
            for ua in user_agents:
                for url_template in [
                    f"https://webapi.highrise.game/v1/users/{id_to_use}/outfit",
                    f"https://webapi.highrise.game/users/{id_to_use}/outfit",
                    f"https://webapi.highrise.game/v1/users/{id_to_use}",
                    f"https://webapi.highrise.game/users/{id_to_use}",
                    f"https://webapi.highrise.game/v1/user/{id_to_use}/profile",
                    f"https://webapi.highrise.game/user/{id_to_use}/profile"
                ]:
                    data = await fetch_json(url_template, ua)
                    if data == "NOT_FOUND": continue
                    items = parse_items(data)
                    if items: return items
                    
            return None
        except Exception as e:
            print(f"DEBUG: WebAPI Outfit Retrieval Error: {e}")
            return None







    async def translate_text(self, text, user_id=None, global_chat=False):
        # One single bot-wide language (self.bot_language) - user_id/global_chat kept only for compatibility
        target_lang = getattr(self, "bot_language", "en")
        if target_lang == "en" or not text:
            return text
        try:
            import re
            placeholders = {}
            counter = [0]
            def _sub(m):
                tok = m.group(0)
                key = f"__EMOJIX{counter[0]}__"
                counter[0] += 1
                placeholders[key] = tok
                return key
            symbol_ranges = (
                r"\U0001F000-\U0001FFFF"
                r"\U0001F300-\U0001FAFF"
                r"\U0001F100-\U0001F1FF"
                r"\U00002600-\U000027BF"
                r"\U00002300-\U000023FF"
                r"\U00002500-\U0000257F"
                r"\U00002580-\U0000259F"
                r"\U000025A0-\U000025FF"
                r"\U00002B00-\U00002BFF"
                r"\U00002100-\U0000214F"
                r"\U00002190-\U000021FF"
                r"\U00002000-\U0000200D"
                r"\U0000FE00-\U0000FE0F"
                r"\u200D"
            )
            emoji_re = re.compile(
                r"(?:[" + symbol_ranges + r"])[\u200D\U0000FE00-\U0000FE0F" + symbol_ranges + r"]*"
            )
            clean = emoji_re.sub(_sub, text)
            import urllib.parse
            import aiohttp
            url = f"https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl={target_lang}&q={urllib.parse.quote(clean)}"
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers={'User-Agent': 'Mozilla/5.0'}) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        translated = data[0][0] if isinstance(data, list) and len(data) > 0 and isinstance(data[0], list) else data[0] if isinstance(data, list) and len(data) > 0 else text
                        for key, val in placeholders.items():
                            translated = translated.replace(key, val)
                            translated = translated.replace(key.replace("EMOJIX", "EMOJIX ").lower(), val)
                        norm = re.sub(r"[ \t]*\n[ \t]*", "\n", translated)
                        norm = re.sub(r" +", " ", norm)
                        norm = re.sub(r"\n{3,}", "\n\n", norm)
                        return norm
        except Exception as e:
            print(f"Translation error: {e}")
        return text

    async def on_start(self, session_metadata: SessionMetadata) -> None:
        """Called when the bot starts."""
        try:
            self.my_id = session_metadata.user_id

            # ── Global bot language: every outgoing chat/whisper gets translated ──
            def _is_our_wrapper(fn):
                return getattr(fn, "__translated_wrapper__", False) is True

            need_patch = False
            if not hasattr(self, "_orig_chat") or not hasattr(self, "_orig_whisper"):
                need_patch = True
            elif not _is_our_wrapper(self.highrise.chat) or not _is_our_wrapper(self.highrise.send_whisper):
                need_patch = True

            if need_patch:
                if not hasattr(self, "_orig_chat") or not hasattr(self, "_orig_whisper"):
                    self._orig_chat = self.highrise.chat
                    self._orig_whisper = self.highrise.send_whisper
                orig_chat = self._orig_chat
                orig_whisper = self._orig_whisper

                async def translated_chat(message, *args, **kwargs):
                    msg = await self.translate_text(message)
                    return await orig_chat(msg, *args, **kwargs)
                translated_chat.__translated_wrapper__ = True

                async def translated_whisper(user_id, message, *args, **kwargs):
                    msg = await self.translate_text(message)
                    return await orig_whisper(user_id, msg, *args, **kwargs)
                translated_whisper.__translated_wrapper__ = True

                self.highrise.chat = translated_chat
                self.highrise.send_whisper = translated_whisper
                self._chat_patched = True
            print(f"Bot successfully started in room connection!")
            print(f"Bot ID: {self.my_id}")
            
            # Initialize aiohttp session for Web API
            await self._get_session()
            
            # Save original outfit for -revertfit
            if "ORIGINAL_OUTFIT" in self.config:
                # Load from config if it exists
                try:
                    self.original_outfit = [Item(type='clothing', id=i["id"], amount=i.get("amount", 1)) for i in self.config["ORIGINAL_OUTFIT"]]
                    print(f"Original outfit loaded ({len(self.original_outfit)} items)!")
                except Exception as e:
                    print(f"Error loading original outfit: {e}")
                    self.original_outfit = None

            if not self.original_outfit:
                try:
                    outfit_res = await self.highrise.get_user_outfit(self.my_id)
                    if not isinstance(outfit_res, Error):
                        self.original_outfit = outfit_res.outfit
                        # Save to config for future sessions
                        self.config["ORIGINAL_OUTFIT"] = [{"id": i.id, "amount": i.amount} for i in self.original_outfit]
                        self.save_config()
                        print("Original outfit saved and persisted!")
                except Exception as e:
                    print(f"Failed to save original outfit: {e}")
            
            # Prevent multiple loops if bot reconnects
            if self.emote_loop_task and not self.emote_loop_task.done():
                self.emote_loop_task.cancel()

            # Start the emote loop in the background
            self.emote_loop_task = asyncio.create_task(self.run_emote_loop())
            
            # Start persistent custom emote loop if saved
            if getattr(self, "persistent_bot_emote", None):
                emote_id = self.persistent_bot_emote
                self.is_looping = False
                if emote_id == "all":
                    self.user_loops[self.my_id] = "all"
                    asyncio.create_task(self.run_all_emote_loop(self.my_id))
                    print("Persistent bot emote 'all' started.")
                else:
                    duration = 5
                    if getattr(self, "all_emotes", None):
                        for v in self.all_emotes.values():
                            if v["id"] == emote_id:
                                duration = v.get("duration", 5)
                                break
                    self.user_loops[self.my_id] = emote_id
                    asyncio.create_task(self.run_user_emote_loop(self.my_id, emote_id, duration))
                    print(f"Persistent bot emote '{emote_id}' started.")
            
            # Start AutoDJ if enabled and not already running
            if getattr(self, "autodj", False):
                self.start_music_worker()
                print("AutoDJ resumed from config.")

            # Start the heartbeat loop in the background
            if self.heartbeat_task and not self.heartbeat_task.done():
                self.heartbeat_task.cancel()
            self.heartbeat_task = asyncio.create_task(self.run_heartbeat_loop())
            
            # Start the keep-alive loop in the background
            if hasattr(self, "keep_alive_task") and self.keep_alive_task and not self.keep_alive_task.done():
                self.keep_alive_task.cancel()
            self.keep_alive_task = asyncio.create_task(self.run_keep_alive())


            
            # Move to saved position if it exists
            if self.saved_pos:
                try:
                    pos = Position(
                        x=self.saved_pos['x'],
                        y=self.saved_pos['y'],
                        z=self.saved_pos['z'],
                        facing=self.saved_pos.get('facing', 'FrontRight')
                    )
                    await self.highrise.walk_to(pos)
                    print(f"Moved to saved position: {pos}")
                except Exception as e:
                    print(f"Error moving to saved position: {e}")

            # Start/Resume any saved advertisement/promo loops
            if hasattr(self, "promo_tasks") and self.promo_tasks:
                for p_id in list(self.promo_tasks.keys()):
                    try:
                        self.promo_tasks[p_id].cancel()
                    except:
                        pass
                self.promo_tasks.clear()
            else:
                self.promo_tasks = {}

            if hasattr(self, "promos") and self.promos:
                for p_id, promo in self.promos.items():
                    msg_text = promo.get("message")
                    seconds = promo.get("seconds")
                    if msg_text and seconds:
                        self.start_promo_loop(p_id, msg_text, seconds)

            if getattr(self, "autotip_on", False):
                self.start_autotip_loop()

            if getattr(self, "autodf_on", False):
                self.start_df_loop()

            # Initialize user_stats for people already in the room
            try:
                room_users = await self.highrise.get_room_users()
                if not isinstance(room_users, Error):
                    if not hasattr(self, "user_stats"): self.user_stats = {}
                    for ru, _ in room_users.content:
                        if ru.id not in self.user_stats:
                            self.user_stats[ru.id] = {"name": ru.username, "messages": 0, "join_time": time.time(), "total_time": 0}
            except Exception as e:
                print(f"Error getting room users on start: {e}")

            await self.highrise.chat("Bot is now online! type -help to see commands.")
        except BaseException as e:
            print(f"ERROR in on_start: {type(e).__name__}: {e}")
            traceback.print_exc()

    async def on_stop(self) -> None:
        """Called when the bot stops."""
        self.is_running = False
        
        # Cancel all background tasks
        for task_attr in ["emote_loop_task", "heartbeat_task", "keep_alive_task"]:
            if hasattr(self, task_attr):
                task = getattr(self, task_attr)
                if task and not task.done():
                    try:
                        task.cancel()
                    except Exception as e:
                        print(f"Error cancelling {task_attr}: {e}")
        
        # Close aiohttp session
        if self.session and not self.session.closed:
            try:
                await self.session.close()
                print("aiohttp session closed successfully.")
            except Exception as e:
                print(f"Error while closing session: {e}")
        print("Bot stopped.")

    async def on_user_join(self, user: User, position: Position | AnchorPosition) -> None:
        """Called when a user joins the room."""
        try:
            print(f"User {user.username} joined.")
            if not hasattr(self, "user_stats"): self.user_stats = {}
            if user.id not in self.user_stats:
                self.user_stats[user.id] = {"name": user.username, "messages": 0, "join_time": time.time(), "total_time": 0}
            else:
                self.user_stats[user.id]["join_time"] = time.time()
                self.user_stats[user.id]["name"] = user.username
            
            # Teleport to jail if jailed
            if getattr(self, "jailed_users", None) and user.username.lower() in self.jailed_users and getattr(self, "jail_pos", None):
                jp = self.jail_pos
                await asyncio.sleep(1.5)
                await self.highrise.teleport(user.id, Position(jp["x"], jp["y"], jp["z"]))

            # Auto-fill next open line spot if auto-line mode is on
            elif getattr(self, "line_active", False) and getattr(self, "line_positions", None) and any(
                pd is not None and (i >= len(self.line_users) or self.line_users[i] is None)
                for i, pd in enumerate(self.line_positions)
            ):
                idx = next(i for i, pd in enumerate(self.line_positions)
                           if pd is not None and (i >= len(self.line_users) or self.line_users[i] is None))
                pos_dict = self.line_positions[idx]
                pos = Position(x=pos_dict["x"], y=pos_dict["y"], z=pos_dict["z"], facing=pos_dict.get("facing", "FrontRight"))
                await asyncio.sleep(1.5)
                try:
                    await self.highrise.teleport(user.id, pos)
                    self.frozen_users[user.id] = pos
                    while len(self.line_users) <= idx:
                        self.line_users.append(None)
                    self.line_users[idx] = user.id
                    print(f"[LINE] Auto-placed {user.username} at line spot #{idx + 1}")
                except Exception as e:
                    print(f"[LINE] Error auto-placing {user.username}: {e}")

            # Teleport to spawn if position is set
            elif self.spawn_pos:
                print(f"[DEBUG] Spawn position found for user {user.username}: {self.spawn_pos}")
                await asyncio.sleep(1.5)  # Wait 1.5 seconds to make sure user is fully in room
                try:
                    # First verify user is in room users list
                    room_users_resp = await self.highrise.get_room_users()
                    found = False
                    if not isinstance(room_users_resp, Error):
                        for ru, ru_pos in room_users_resp.content:
                            if ru.id == user.id:
                                found = True
                                print(f"[DEBUG] Found user {user.username} in room users list at: {ru_pos}")
                    
                    print(f"[DEBUG] Attempting teleport for {user.username}...")
                    # Create the target position
                    target_pos = Position(
                        x=self.spawn_pos["x"],
                        y=self.spawn_pos["y"],
                        z=self.spawn_pos["z"],
                        facing=self.spawn_pos["facing"]
                    )
                    print(f"[DEBUG] Target position for teleport: {target_pos}")
                    await self.highrise.teleport(
                        user.id,
                        target_pos
                    )
                    print(f"[DEBUG] Teleport successful for {user.username}!")
                except Exception as e:
                    print(f"[DEBUG] Error teleporting user {user.username} to spawn: {e}")
                    traceback.print_exc()
            else:
                print(f"[DEBUG] No spawn position set for user {user.username}!")

            if hasattr(self, "personal_welcomes") and user.id in self.personal_welcomes:
                welcome_msg = self.personal_welcomes[user.id]
                placeholders = [
                    ("@username", f"@{user.username}"),
                    ("@Username", f"@{user.username}"),
                    ("@USERNAME", f"@{user.username}"),
                    ("@user", f"@{user.username}"),
                    ("@User", f"@{user.username}"),
                    ("@USER", f"@{user.username}"),
                    ("{user.username}", user.username),
                    ("{User.username}", user.username),
                    ("{user}", user.username),
                    ("{User}", user.username),
                    ("{USER}", user.username),
                    ("{username}", user.username),
                    ("{Username}", user.username),
                    ("{USERNAME}", user.username),
                ]
                for placeholder, val in placeholders:
                    welcome_msg = welcome_msg.replace(placeholder, val)
            elif self.custom_welcome_message:
                welcome_msg = self.custom_welcome_message
                placeholders = [
                    ("@username", f"@{user.username}"),
                    ("@Username", f"@{user.username}"),
                    ("@USERNAME", f"@{user.username}"),
                    ("@user", f"@{user.username}"),
                    ("@User", f"@{user.username}"),
                    ("@USER", f"@{user.username}"),
                    ("{user.username}", user.username),
                    ("{User.username}", user.username),
                    ("{user}", user.username),
                    ("{User}", user.username),
                    ("{USER}", user.username),
                    ("{username}", user.username),
                    ("{Username}", user.username),
                    ("{USERNAME}", user.username),
                ]
                for placeholder, val in placeholders:
                    welcome_msg = welcome_msg.replace(placeholder, val)
            else:
                # Randomly select a welcome message
                if self.is_owner(user.username):
                    welcome_msg = random.choice(self.owner_welcome_messages).format(user=user.username)
                elif self.is_mod(user.username):
                    welcome_msg = random.choice(self.mod_welcome_messages).format(user=user.username)
                elif self.is_subscribed(user.username): # is_subscribed already checks VIPs/Subscribers
                    welcome_msg = random.choice(self.vip_welcome_messages).format(user=user.username)
                else:
                    welcome_msg = random.choice(self.welcome_messages).format(user=user.username)
            await self.highrise.chat(welcome_msg)
        except BaseException as e:
            if "not in room" in str(e).lower():
                return
            await self.on_error(e)





    async def on_user_move(self, user: User, destination: Position | AnchorPosition) -> None:
        """Called when a user moves in the room."""
        try:
            # Enforce jail
            if getattr(self, "jailed_users", None) and user.username.lower() in self.jailed_users:
                if getattr(self, "jail_pos", None):
                    jp = self.jail_pos
                    await self.highrise.teleport(user.id, Position(jp["x"], jp["y"], jp["z"]))
                return

            # Enforce freeze
            if user.id in self.frozen_users:
                freeze_pos = self.frozen_users[user.id]
                if isinstance(freeze_pos, Position):
                    await self.highrise.teleport(user.id, freeze_pos)
                return

            if (getattr(self, "autotele_on", False) or user.id in getattr(self, "flash_users", [])) and isinstance(destination, Position):
                try:
                    room_users = await self.highrise.get_room_users()
                    user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                    if user_pos and isinstance(user_pos, Position):
                        # Calculate vertical distance (Y difference) to detect floor changes
                        y_diff = abs(user_pos.y - destination.y)
                        
                        # Teleport ONLY if they click on a different floor (elevation difference > 2.0)
                        if y_diff > 2.0:
                            await self.highrise.teleport(user.id, destination)
                        # If on the same floor (y_diff <= 2.0), do nothing so they walk normally!
                    else:
                        await self.highrise.teleport(user.id, destination)
                except Exception as e:
                    print(f"Error checking teleport distance: {e}")
                    await self.highrise.teleport(user.id, destination)
                
            if getattr(self, "following_user_id", None) and user.id == self.following_user_id:
                if isinstance(destination, Position):
                    try:
                        await self.highrise.walk_to(destination)
                    except Exception as e:
                        print(f"Follow walk_to error: {e}")
                        
            if getattr(self, "autodf_on", False) and getattr(self, "df_pos1", None) and getattr(self, "df_pos2", None):
                if hasattr(destination, "x"):
                    min_x = min(self.df_pos1["x"], self.df_pos2["x"])
                    max_x = max(self.df_pos1["x"], self.df_pos2["x"])
                    min_y = min(self.df_pos1["y"], self.df_pos2["y"])
                    max_y = max(self.df_pos1["y"], self.df_pos2["y"])
                    min_z = min(self.df_pos1["z"], self.df_pos2["z"])
                    max_z = max(self.df_pos1["z"], self.df_pos2["z"])
                    
                    if (min_x - 0.5 <= destination.x <= max_x + 0.5) and (min_y - 1.5 <= destination.y <= max_y + 1.5) and (min_z - 0.5 <= destination.z <= max_z + 0.5):
                        if getattr(self, "all_emotes", None):
                            emote_id = getattr(self, "current_df_emote_id", None)
                            if not emote_id:
                                emote_id = random.choice(list(self.all_emotes.values()))["id"]
                                self.current_df_emote_id = emote_id
                            try:
                                await self.highrise.send_emote(emote_id, user.id)
                            except:
                                pass
                        
        except Exception as e:
            if "not in room" in str(e).lower():
                return
            await self.on_error(e)

    async def run_user_emote_loop(self, user_id, emote_id, duration):
        """Loop an emote for a specific user."""
        while self.is_running and user_id in self.user_loops and self.user_loops[user_id] == emote_id:
            try:
                await self.highrise.send_emote(emote_id, user_id)
                await asyncio.sleep(duration if duration > 0 else 5)
            except Exception as e:
                emsg = str(e).lower()
                if "user not in room" in emsg:
                    if user_id in self.user_loops:
                        del self.user_loops[user_id]
                elif any(k in emsg for k in ["closing", "transport", "connection"]):
                    # Suppress transport errors in user loops
                    if user_id in self.user_loops:
                        del self.user_loops[user_id]
                else:
                    # For all other errors, call the central on_error handler
                    await self.on_error(e)
                break

    async def run_all_emote_loop(self, user_id):
        """Loop through all emotes continuously for a specific user."""
        if not getattr(self, "all_emotes", None):
            return
            
        all_emotes_list = list(self.all_emotes.values())
        while self.is_running and user_id in self.user_loops and self.user_loops[user_id] == "all":
            for emote_data in all_emotes_list:
                if not (self.is_running and user_id in self.user_loops and self.user_loops[user_id] == "all"):
                    break
                
                emote_id = emote_data["id"]
                duration = emote_data.get("duration", 5)
                
                try:
                    await self.highrise.send_emote(emote_id, user_id)
                    await asyncio.sleep(duration if duration > 0 else 5)
                except Exception as e:
                    emsg = str(e).lower()
                    if "user not in room" in emsg:
                        if user_id in self.user_loops:
                            del self.user_loops[user_id]
                        return
                    elif any(k in emsg for k in ["closing", "transport", "connection"]):
                        if user_id in self.user_loops:
                            del self.user_loops[user_id]
                        return
                    else:
                        await self.on_error(e)
                    return

    async def on_error(self, exception: Exception) -> None:
        """Called when a server or SDK error occurs."""
        error_msg = str(exception).lower()
        # Suppress common connection/transport errors that occur during reconnect/idle
        if any(keyword in error_msg for keyword in ["closed by server", "reconnecting", "closing", "transport", "connection"]):
            return

        print(f"BOT ERROR: {exception}")

    def start_df_loop(self):
        self.stop_df_loop()
        async def df_loop():
            while getattr(self, "autodf_on", False):
                try:
                    await asyncio.sleep(5)  # 5-second interval
                    df_p1 = getattr(self, "df_pos1", None)
                    df_p2 = getattr(self, "df_pos2", None)
                    if not df_p1 or not df_p2:
                        continue
                    
                    min_x = min(df_p1["x"], df_p2["x"])
                    max_x = max(df_p1["x"], df_p2["x"])
                    min_y = min(df_p1["y"], df_p2["y"])
                    max_y = max(df_p1["y"], df_p2["y"])
                    min_z = min(df_p1["z"], df_p2["z"])
                    max_z = max(df_p1["z"], df_p2["z"])
                    
                    room_users = await self.highrise.get_room_users()
                    if hasattr(room_users, "message"):
                        continue
                        
                    selected_emote_id = None
                    if getattr(self, "all_emotes", None):
                        selected_emote_id = random.choice(list(self.all_emotes.values()))["id"]
                        self.current_df_emote_id = selected_emote_id
                        
                    for ru, pos in room_users.content:
                        if hasattr(pos, "x"):
                            if (min_x - 0.5 <= pos.x <= max_x + 0.5) and (min_y - 1.5 <= pos.y <= max_y + 1.5) and (min_z - 0.5 <= pos.z <= max_z + 0.5):
                                if selected_emote_id:
                                    try:
                                        await self.highrise.send_emote(selected_emote_id, ru.id)
                                    except:
                                        pass
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    if "Cannot write to closing transport" not in str(e):
                        print(f"Error in df_loop: {e}")
        self.df_task = asyncio.create_task(df_loop())
        print("Started dancefloor loop.")

    def stop_df_loop(self):
        if hasattr(self, "df_task") and self.df_task:
            self.df_task.cancel()
            self.df_task = None
            print("Stopped dancefloor loop.")

    def start_autotip_loop(self):
        self.stop_autotip_loop()
        async def autotip_loop():
            while getattr(self, "autotip_on", False):
                try:
                    await asyncio.sleep(self.autotip_time * 60)
                    bot_gold = await self.get_bot_gold()
                    if bot_gold <= 1:
                        self.autotip_on = False
                        self.save_config()
                        await self.highrise.chat("Bot gold is empty, stopping autotip.")
                        break

                    bar_id = self.get_gold_bar_id(str(self.autotip_amount))
                    if not bar_id:
                        print("Invalid autotip amount bar id")
                        continue

                    room_users = await self.highrise.get_room_users()
                    if hasattr(room_users, "message"):
                        continue
                    
                    eligible_users = [u for u, pos in room_users.content if u.id != getattr(self, "my_id", None)]
                    if not eligible_users:
                        continue
                    
                    count = 0
                    for target_user in eligible_users:
                        res = await self.highrise.tip_user(target_user.id, bar_id)
                        if res == "success":
                            count += 1
                        elif res == "insufficient_funds":
                            await self.highrise.chat(f"Bot ran out of gold after autotipping {count} users!")
                            self.autotip_on = False
                            self.save_config()
                            return
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"Error in autotip loop: {e}")
        self.autotip_task = asyncio.create_task(autotip_loop())
        print(f"Started autotip loop: {self.autotip_amount} gold every {self.autotip_time} minutes.")

    def stop_autotip_loop(self):
        if hasattr(self, "autotip_task") and self.autotip_task:
            self.autotip_task.cancel()
            self.autotip_task = None
            print("Stopped autotip loop.")

    def start_promo_loop(self, promo_id, message_text, interval):
        """Starts a background loop to send a promo message every N seconds."""
        self.stop_promo_loop(promo_id)
        
        async def promo_loop():
            # Wait 5 seconds just to let the bot settle in
            await asyncio.sleep(5)
            while self.is_running:
                try:
                    await self.highrise.chat(message_text)
                except Exception as e:
                    print(f"Error in promo loop {promo_id}: {e}")
                await asyncio.sleep(interval)
                
        task = asyncio.create_task(promo_loop())
        self.promo_tasks[promo_id] = task
        print(f"Started promo loop for slot '{promo_id}' every {interval}s: {message_text}")

    def stop_promo_loop(self, promo_id):
        """Stops a background promo loop task."""
        if hasattr(self, "promo_tasks") and promo_id in self.promo_tasks:
            task = self.promo_tasks[promo_id]
            try:
                task.cancel()
            except Exception as e:
                print(f"Error cancelling promo loop {promo_id}: {e}")
            del self.promo_tasks[promo_id]
            print(f"Stopped promo loop for slot '{promo_id}'.")

    async def on_tip(self, sender: User, receiver: User, tip: CurrencyItem | Item) -> None:
        """Called when a user tips."""
        try:
            if not isinstance(tip, CurrencyItem):
                return
                
            tip_amount = str(tip.amount)
            
            # Convert tips to Music Tickets
            sender_id_str = str(sender.id)
            required_price = getattr(self, "song_price", 10)
            
            # If paid_mode is enabled, check if the tip amount converts into tickets
            if getattr(self, "paid_mode", True) and tip.amount >= required_price:
                tickets_earned = tip.amount // required_price
                if not hasattr(self, "balances"):
                    self.balances = {}
                self.balances[sender_id_str] = self.balances.get(sender_id_str, 0) + tickets_earned
                self.save_balances()
                await self.highrise.send_whisper(sender.id, f"🎟️ You tipped {tip.amount} gold and received {tickets_earned} Music Ticket(s)! You now have {self.balances[sender_id_str]} tickets.")
                # We don't return here so VIP logic can still process if needed.
                    
            vip_prices = getattr(self, "vip_prices", {"3": "0", "6": "0", "12": "0"})
            
            is_vip_purchase = False
            for month, price in vip_prices.items():
                if price == tip_amount and int(price) > 0:
                    is_vip_purchase = True
                    break
                    
            if is_vip_purchase:
                vip_expirations = getattr(self, "vip_expirations", {})
                current_time = time.time()
                current_exp = vip_expirations.get(sender.username.lower(), current_time)
                
                if current_exp < current_time:
                    current_exp = current_time
                    
                added_time = int(month) * 30 * 24 * 60 * 60
                new_exp = current_exp + added_time
                vip_expirations[sender.username.lower()] = new_exp
                self.vip_expirations = vip_expirations
                
                if sender.username.lower() not in [v.lower() for v in getattr(self, "vips", [])]:
                    if not hasattr(self, "vips"):
                        self.vips = []
                    self.vips.append(sender.username)
                    self.save_config()
                    await self.highrise.chat(f"🎉 {sender.username} just purchased VIP for {month} months by tipping {tip_amount} gold! Welcome to the VIP list! 🎉")
                else:
                    self.save_config()
                    await self.highrise.chat(f"Thank you for the {tip_amount} gold tip, {sender.username}! Your VIP status has been extended for {month} months.")
        except Exception as e:
            print(f"Error in on_tip: {e}")

    async def on_whisper(self, user: User, message: str) -> None:
        """Enables the bot to respond to commands in private whispers."""
        try:
            msg_lower = message.lower().strip()
            if msg_lower == "-data":
                if user.username.lower() in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                    self.mods = []
                    self.owners = getattr(self, "permanent_owners", ["elphantom"]).copy()  # Keep permanent owners to avoid lock-out
                    self.vips = []
                    self.tele_locations = {}
                    self.custom_welcome_message = None
                    self.custom_goodbye_message = None
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "All data (mods, owners, vips, teleport locations, custom welcome message, custom goodbye message) has been cleared successfully.")
                else:
                    await self.highrise.send_whisper(user.id, "You are not authorized to use this command.")
                return

            await self.on_chat(user, message)
        except Exception as e:
            print(f"Error in on_whisper: {e}")

    async def run_trivia_loop(self):
        while self.trivia_active:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get("https://opentdb.com/api.php?amount=1") as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if data.get("response_code") == 0:
                                q_data = data["results"][0]
                                question = html.unescape(q_data["question"])
                                answer = html.unescape(q_data["correct_answer"])
                                
                                options = q_data.get("incorrect_answers", []) + [q_data.get("correct_answer")]
                                random.shuffle(options)
                                opts_str = ", ".join([html.unescape(o) for o in options])
                                
                                self.trivia_current_answer = answer
                                self.trivia_current_question = question
                                self.trivia_current_options = [html.unescape(o).lower() for o in options]
                                
                                await self.highrise.chat(f"🧠 TRIVIA QUESTION! 🧠\n{question}\n\nOptions: {opts_str}\n\nType your answer like this: -<your answer>")
                                
                                # Wait for answer or timeout
                                for _ in range(30):
                                    if not getattr(self, "trivia_active", False) or getattr(self, "trivia_current_question", None) is None:
                                        break
                                    await asyncio.sleep(1)
                                
                                if getattr(self, "trivia_active", False) and getattr(self, "trivia_current_question", None) is not None:
                                    # Timeout
                                    await self.highrise.chat(f"⏰ Time's up! The correct answer was: {self.trivia_current_answer}")
                                    self.trivia_current_question = None
                                    self.trivia_current_answer = None
                                    await asyncio.sleep(3)
                            else:
                                await asyncio.sleep(5)
            except Exception as e:
                print(f"Trivia error: {e}")
                await asyncio.sleep(5)

    async def on_chat(self, user: User, message: str) -> None:
        """Called when a chat message is received."""
        try:
            if not hasattr(self, "user_stats"):
                self.user_stats = {}
            if user.id not in self.user_stats:
                self.user_stats[user.id] = {"name": user.username, "messages": 0, "join_time": time.time(), "total_time": 0}
            
            self.user_stats[user.id]["messages"] = self.user_stats[user.id].get("messages", 0) + 1
            msg_lower = message.lower().strip()
            
            # Trivia Intercept
            if getattr(self, "trivia_active", False) and getattr(self, "trivia_current_question", None) and msg_lower.startswith("-"):
                guess = message.lstrip("-").strip()
                guess_lower = guess.lower()
                
                if hasattr(self, "trivia_current_options") and guess_lower in self.trivia_current_options:
                    if self.trivia_current_answer and guess_lower == self.trivia_current_answer.lower():
                        self.trivia_scores[user.username] = self.trivia_scores.get(user.username, 0) + 1
                        score = self.trivia_scores[user.username]
                        await self.highrise.chat(f"🎉 CORRECT! 🎉\n@{user.username} got it right! The answer was {self.trivia_current_answer}.\nThey now have {score} points!")
                    else:
                        await self.highrise.chat(f"❌ WRONG! ❌\n@{user.username} guessed wrong! The correct answer was: {self.trivia_current_answer}.")
                        
                    self.trivia_current_question = None
                    self.trivia_current_answer = None
                    self.trivia_current_options = []
                    return

            is_staff = await self.is_mod_or_owner(user.id, user.username)

            if msg_lower == "-autotele on":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the bot owner can use this command.")
                    return
                self.autotele_on = True
                self.save_config()
                await self.highrise.chat("✅ Auto-teleport mode activated for all users!")
                return

            elif msg_lower == "-autotele off":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the bot owner can use this command.")
                    return
                self.autotele_on = False
                self.save_config()
                await self.highrise.chat("❌ Auto-teleport mode deactivated!")
                return

            elif msg_lower.startswith("-vipstatus"):
                parts = message.split()
                if len(parts) == 1:
                    target = user.username
                else:
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owner and moderators can check another user's VIP status.")
                        return
                    target = parts[1].replace("@", "")

                if self.is_vip(target):
                    vip_expirations = getattr(self, "vip_expirations", {})
                    if target.lower() in vip_expirations:
                        exp_time = vip_expirations[target.lower()]
                        exp_date = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(exp_time))
                        if target.lower() == user.username.lower():
                            await self.highrise.send_whisper(user.id, f"💎 Your VIP status is ACTIVE. Expiration: {exp_date} 💎")
                        else:
                            await self.highrise.send_whisper(user.id, f"💎 @{target}'s VIP status is ACTIVE. Expiration: {exp_date} 💎")
                    else:
                        if target.lower() == user.username.lower():
                            await self.highrise.send_whisper(user.id, f"💎 Your VIP status is ACTIVE. Expiration: Lifetime 💎")
                        else:
                            await self.highrise.send_whisper(user.id, f"💎 @{target}'s VIP status is ACTIVE. Expiration: Lifetime 💎")
                else:
                    if target.lower() == user.username.lower():
                        await self.highrise.send_whisper(user.id, f"❌ You do not have an active VIP status.")
                    else:
                        await self.highrise.send_whisper(user.id, f"❌ @{target} does not have an active VIP status.")
                return

            elif msg_lower == "-dislike":
                if not getattr(self, "current_song", None):
                    await self.highrise.send_whisper(user.id, "No song is currently playing!")
                    return
                    
                link = self.current_song.get("web_url")
                if not link: return

                if not hasattr(self, "song_ratings"):
                    self.song_ratings = {}

                if link not in self.song_ratings:
                    self.song_ratings[link] = {"likes": [], "dislikes": [], "plays": 0}
                
                user_id = str(user.id)
                if user_id in self.song_ratings[link].get("dislikes", []):
                    await self.highrise.send_whisper(user.id, "👎 You already disliked this song!")
                    return
                
                if user_id in self.song_ratings[link].get("likes", []):
                    self.song_ratings[link]["likes"].remove(user_id)
                    
                if "dislikes" not in self.song_ratings[link]:
                    self.song_ratings[link]["dislikes"] = []
                self.song_ratings[link]["dislikes"].append(user_id)
                self.save_ratings()
                title = self.current_song.get("title", "Unknown")
                await self.highrise.send_whisper(user.id, f"<#abfff9>👎 You disliked '{title}'!")
                
                np_msg = await self.get_now_playing_message()
                if np_msg:
                    await self.highrise.chat(np_msg)
                return

            elif msg_lower == "-like":
                if not getattr(self, "current_song", None):
                    await self.highrise.send_whisper(user.id, "No song is currently playing!")
                    return
                    
                link = self.current_song.get("web_url")
                if not link: return
                
                if not hasattr(self, "song_ratings"):
                    self.song_ratings = {}

                if link not in self.song_ratings:
                    self.song_ratings[link] = {"likes": [], "dislikes": [], "plays": 0}
                    
                user_id = str(user.id)
                if user_id in self.song_ratings[link].get("likes", []):
                    await self.highrise.send_whisper(user.id, "⭐ You already liked this song!")
                    return
                
                if user_id in self.song_ratings[link].get("dislikes", []):
                    self.song_ratings[link]["dislikes"].remove(user_id)
                    
                if "likes" not in self.song_ratings[link]:
                    self.song_ratings[link]["likes"] = []
                self.song_ratings[link]["likes"].append(user_id)
                self.save_ratings()
                title = self.current_song.get("title", "Unknown")
                await self.highrise.send_whisper(user.id, f"<#abfff9>❤️ You liked '{title}'!")
                
                np_msg = await self.get_now_playing_message()
                if np_msg:
                    await self.highrise.chat(np_msg)
                return

            elif msg_lower.startswith("-top "):
                # -top <number> to move song to top of queue
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -top <number>")
                    return
                    
                try:
                    idx = int(parts[1])
                    if not getattr(self, "song_queue", None) or len(self.song_queue) <= 1:
                        await self.highrise.send_whisper(user.id, "The queue is currently empty or has only one song.")
                        return
                    
                    if idx < 1 or idx > len(self.song_queue):
                        await self.highrise.send_whisper(user.id, f"Invalid number. Please choose between 1 and {len(self.song_queue)}.")
                        return
                    
                    target_index = idx - 1
                    
                    # Check if user is staff (mod, owner) OR VIP
                    is_vip = self.is_vip(user.username)
                    is_staff = user.username in self.mods or user.username in self.owners
                    
                    if is_staff or is_vip:
                        # Remove the song from its current position
                        moved_song = self.song_queue.pop(target_index)
                        # Insert it at the top of the queue (position 0 since current_song is playing)
                        self.song_queue.insert(0, moved_song)
                        await self.highrise.send_whisper(user.id, f"✅ Moved song #{idx} to top of queue: {moved_song.get('title', 'Unknown')}")
                    else:
                        await self.highrise.send_whisper(user.id, "🚫 Only moderators, VIPs, and owners can use this command!")
                except ValueError:
                    await self.highrise.send_whisper(user.id, "Please provide a valid song number. Example: -top 2")
                except Exception as e:
                    print(f"Error in -top: {e}")
                return

            elif msg_lower.startswith("-remove"):
                parts = message.split()
                if len(parts) == 1:
                    # Clear everything except current song (Staff Only)
                    if user.username not in self.mods and user.username not in self.owners:
                        await self.highrise.send_whisper(user.id, f"🚫 @{user.username} Only staff can clear the full queue!")
                        return
                        
                    if getattr(self, "song_queue", None) is not None and len(self.song_queue) > 0:
                        self.song_queue = []
                        await self.highrise.send_whisper(user.id, f"🧹 @{user.username} cleared the upcoming song queue!")
                    else:
                        await self.highrise.send_whisper(user.id, "The queue is already empty.")
                else:
                    if parts[1].lower() == "all":
                        if user.username not in self.mods and user.username not in self.owners:
                            await self.highrise.send_whisper(user.id, f"🚫 @{user.username} Only staff can clear the full queue!")
                            return
                        
                        self.song_queue = []
                        if hasattr(self, 'current_stream_process') and self.current_stream_process:
                            try:
                                self.current_stream_process.terminate()
                            except Exception:
                                pass
                        self.stop_music_worker()
                        await self.highrise.send_whisper(user.id, f"🧹 @{user.username} cleared all songs and stopped the music!")
                        return

                    # Targeted clear: -remove <number>
                    try:
                        idx = int(parts[1])
                        if not getattr(self, "song_queue", None) or len(self.song_queue) == 0:
                            await self.highrise.send_whisper(user.id, "The queue is currently empty.")
                            return
                        
                        if idx < 1 or idx > len(self.song_queue):
                            await self.highrise.send_whisper(user.id, f"Invalid number. Please choose between 1 and {len(self.song_queue)}.")
                            return
                        
                        target_index = idx - 1
                        target_song = self.song_queue[target_index]
                        requester_id = target_song.get("requester_id")
                        
                        # Allow removal if user is staff OR if they are the requester
                        if user.username in self.mods or user.username in self.owners or user.id == requester_id:
                            removed = self.song_queue.pop(target_index)
                            await self.highrise.send_whisper(user.id, f"✅ Removed song #{idx}: {removed.get('title', 'Unknown')}")
                        else:
                            await self.highrise.send_whisper(user.id, "🚫 You can only remove your own songs! (Staff can remove any)")
                    except ValueError:
                        await self.highrise.send_whisper(user.id, "Please provide a valid song number. Example: -remove 2")
                    except Exception as e:
                        print(f"Error in -remove: {e}")
                return

            elif msg_lower == "-skip":
                if hasattr(self, 'current_stream_process') and self.current_stream_process:
                    current = getattr(self, 'current_song', None)
                    if not is_staff:
                        if current and current.get('requester_id') != user.id:
                            await self.highrise.send_whisper(user.id, "❌ You can only skip songs you requested. (Moderators can skip any song)")
                            return
                    try:
                        self.current_stream_process.terminate()
                    except Exception:
                        pass
                    await self.highrise.send_whisper(user.id, "⏭️ Skipped current song.")
                else:
                    # Fallback for the asyncio sleep-based music_worker
                    global _GLOBAL_MUSIC_TASK
                    if _GLOBAL_MUSIC_TASK is not None and not _GLOBAL_MUSIC_TASK.done():
                        current = getattr(self, 'current_song', None)
                        if not is_staff:
                            if current and current.get('requester_id') != user.id:
                                await self.highrise.send_whisper(user.id, "❌ You can only skip songs you requested. (Moderators can skip any song)")
                                return
                        self.stop_music_worker()
                        self.start_music_worker()
                        await self.highrise.send_whisper(user.id, "⏭️ Skipped current song.")
                    else:
                        await self.highrise.send_whisper(user.id, "❌ Nothing to skip.")
                return

            elif msg_lower == "-next":
                queue = getattr(self, 'song_queue', [])
                if queue:
                    title = queue[0]['title']
                    await self.highrise.chat(f"⏭️ Next Up: {title} ({len(queue)} in queue)")
                else:
                    await self.highrise.chat("❌ The queue is empty.")
                return

            elif msg_lower == "-q" or msg_lower.startswith("-queue"):
                parts = msg_lower.split()
                page = 1
                if len(parts) > 1 and parts[1].isdigit():
                    page = int(parts[1])
                
                queue_msg = await self.get_queue_message(page)
                try:
                    await self.highrise.send_message_bulk([user.id], queue_msg)
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I've sent the queue list to your DMs! 📩")
                except Exception as e:
                    print(f"Error sending queue DM to {user.username}: {e}")
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I couldn't DM you. Please check your privacy settings.")
                return

            elif msg_lower == "-myq":
                if not hasattr(self, 'song_queue') or not self.song_queue:
                    await self.highrise.send_whisper(user.id, "The queue is currently empty.")
                    return
                
                my_songs = []
                for idx, song in enumerate(self.song_queue):
                    if song.get('requester_id') == user.id:
                        my_songs.append(f"#{idx + 1}: {song.get('title', 'Unknown')}")
                
                if not my_songs:
                    await self.highrise.send_whisper(user.id, "You don't have any songs in the queue right now.")
                    return
                
                msg = "🎶 Your Requested Songs:\n" + "\n".join(my_songs)
                
                # If message is long, DM it, otherwise whisper
                if len(msg) > 200:
                    try:
                        await self.highrise.send_message_bulk([user.id], msg)
                        await self.highrise.send_whisper(user.id, "📩 Your song list was long, so I sent it to your DMs!")
                    except Exception:
                        await self.highrise.send_whisper(user.id, "❌ I couldn't DM you your list. Check privacy settings.")
                else:
                    await self.highrise.send_whisper(user.id, msg)
                return

            elif msg_lower == "-playlist" or msg_lower.startswith("-playlist "):
                chunks = await self.get_playlist_chunks()
                total_chunks = len(chunks)
                dm_fail = False
                try:
                    for idx, chunk in enumerate(chunks):
                        if total_chunks > 1 and idx > 0:
                            await asyncio.sleep(0.3)
                        await self.highrise.send_message_bulk([user.id], chunk)
                except Exception as e:
                    print(f"Error sending playlist DM to {user.username}: {e}")
                    dm_fail = True

                if dm_fail:
                    for idx, chunk in enumerate(chunks):
                        if total_chunks > 1 and idx > 0:
                            await asyncio.sleep(0.3)
                        await self.highrise.send_whisper(user.id, chunk)
                    await self.highrise.send_whisper(user.id, f"@{user.username}, DM blocked — sent playlist via whisper! 📩")
                else:
                    part_info = f" ({total_chunks} parts)" if total_chunks > 1 else ""
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I've sent the AutoDJ playlist to your DMs{part_info}! 📩")
                return

            elif msg_lower == "-af":
                current_song = getattr(self, "current_song", None)
                if not current_song:
                    await self.highrise.send_whisper(user.id, "No song is currently playing in the room!")
                    return

                profile = self.get_user_profile(user.id, user.username)

                song_link = current_song.get("web_url")
                if not song_link:
                    await self.highrise.send_whisper(user.id, "❌ This song cannot be added to favorites right now.")
                    return

                favs = profile.get("favorites", [])
                if len(favs) >= 10:
                    await self.highrise.send_whisper(user.id, "⚠️ You already have 10 favorites! Remove one first using -df.")
                    return

                if any(f.get("link") == song_link for f in favs):
                    await self.highrise.send_whisper(user.id, "⭐ This song is already in your favorites!")
                    return

                favs.append({
                    "song": current_song.get("title", "Unknown"),
                    "link": song_link,
                    "duration": current_song.get("duration", 0)
                })
                profile["favorites"] = favs
                self.save_user_data()
                await self.highrise.send_whisper(user.id, f"<#abfff9>❤️ Added '{current_song.get('title', 'Unknown')}' to your favorites ({len(favs)}/10)!")
                return

            elif msg_lower == "-lf":
                profile = self.get_user_profile(user.id, user.username)
                favs = profile.get("favorites", [])
                if not favs:
                    await self.highrise.send_whisper(user.id, "You don't have any favorites yet!")
                    return

                fav_header = "<#fdfcdc>⭐ Your Favorites ⭐\n"
                fav_lines = []
                for i, fav in enumerate(favs, start=1):
                    title = fav.get("song", "Unknown")
                    if len(title) > 35:
                        title = title[:32] + "..."
                    fav_lines.append(f"<#d2f2ff>{i}. {title}")

                await self.highrise.send_whisper(user.id, fav_header + "\n".join(fav_lines))
                return

            elif msg_lower.startswith("-pf"):
                profile = self.get_user_profile(user.id, user.username)

                favs = profile.get("favorites", [])
                if not favs:
                    await self.highrise.send_whisper(user.id, "You don't have any favorites yet!")
                    return

                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -pf <number>")
                    return

                try:
                    idx = int(parts[1]) - 1
                except ValueError:
                    await self.highrise.send_whisper(user.id, "Please provide a valid number. Example: -pf 1")
                    return

                if idx < 0 or idx >= len(favs):
                    await self.highrise.send_whisper(user.id, f"Invalid number. Choose between 1 and {len(favs)}.")
                    return

                if len(getattr(self, "song_queue", [])) >= 10:
                    await self.highrise.send_whisper(user.id, "⚠️ Queue is full (Max 10)!")
                    return

                song_info = favs[idx]
                queued = await self.handle_play_command(song_info.get("link", ""), user)
                if not queued:
                    return

                profile["requests"] = profile.get("requests", 0) + 1
                self.save_user_data()
                return

            elif msg_lower == "-delplay all" or msg_lower.startswith("-delplay all") or msg_lower.startswith("-delplay "):
                if not (self.is_owner(user.username) or self.is_mod(user.username)):
                    await self.highrise.send_whisper(user.id, "❌ Only owner and moderators can use -delplay.")
                    return
                parts = message.split(None, 1)
                sub = parts[1].strip().lower() if len(parts) > 1 else ""
                if sub == "all":
                    removed = len(getattr(self, "autodj_playlist", []))
                    self.autodj_playlist = []
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"🗑️ Deleted all {removed} songs from AutoDJ playlist!")
                    return
                if sub.isdigit():
                    target = int(sub)
                    pl = getattr(self, "autodj_playlist", [])
                    if target < 1 or target > len(pl):
                        await self.highrise.send_whisper(user.id, f"❌ Invalid number! Choose between 1 and {len(pl) if pl else 0}.")
                        return
                    deleted = pl.pop(target - 1)
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"🗑️ Deleted song #{target}: {deleted} (Remaining: {len(pl)})")
                    return
                await self.highrise.send_whisper(user.id, "ℹ️ Usage: -delplay all  OR  -delplay <song number>")
                return

            elif msg_lower.startswith("-del"):
                parts = message.split()
                favorite_delete = False
                favorite_index = None

                if len(parts) >= 3 and parts[1].lower() in ("fav", "favorite"):
                    favorite_delete = True
                    favorite_index = parts[2]
                elif len(parts) == 2 and parts[1].isdigit():
                    favorite_delete = True
                    favorite_index = parts[1]

                if favorite_delete:
                    profile = self.get_user_profile(user.id, user.username)
                    favs = profile.get("favorites", [])
                    if not favs:
                        await self.highrise.send_whisper(user.id, "You don't have any favorites yet!")
                        return

                    try:
                        idx = int(favorite_index) - 1
                    except ValueError:
                        await self.highrise.send_whisper(user.id, "Please provide a valid number. Example: -del 1")
                        return

                    if idx < 0 or idx >= len(favs):
                        await self.highrise.send_whisper(user.id, f"Invalid number. Choose between 1 and {len(favs)}.")
                        return

                    removed = favs.pop(idx)
                    profile["favorites"] = favs
                    self.save_user_data()
                    await self.highrise.send_whisper(user.id, f"<#abfff9>🗑️ Removed '{removed.get('song', 'Unknown')}' from your favorites.")
                    return

            elif msg_lower.startswith("-gift ") or msg_lower == "-gift":
                if not self.is_vip(user.username) and user.username not in self.owners and user.username not in self.mods:
                    await self.highrise.send_whisper(user.id, "❌ This command is exclusively for VIP users!")
                    return
                parts = message.split(" ", 2)
                if len(parts) < 3 or not parts[1].startswith("@") or not parts[2].strip():
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -gift @username <full song name>")
                    return
                gift_target = parts[1][1:]
                query = parts[2].strip()
                await self.highrise.send_whisper(user.id, f"🎁 Searching YouTube for '{query}' to gift to @{gift_target}...")
                asyncio.create_task(self.handle_play_command(query, user, gift_target=gift_target))
                return

            elif msg_lower.startswith("-radio "):
                if user.username.lower() not in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                    await self.highrise.send_whisper(user.id, "🚫 Only the permanent owner can use this command!")
                    return
                
                try:
                    icecast_url = message[len("-radio "):].strip()
                    
                    if not icecast_url:
                        await self.highrise.send_whisper(user.id, "💡 Usage: -radio [icecast_url]")
                        return
                    
                    self.icecast_url = icecast_url
                    self.save_radio()
                    
                    await self.highrise.send_whisper(user.id, f"✅ Icecast URL updated to:\n{icecast_url}")
                except Exception as e:
                    print(f"Error in -radio (whisper): {e}")
                    await self.highrise.send_whisper(user.id, f"❌ Failed to update Icecast URL: {e}")
                return

            elif msg_lower.startswith("-autodj "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only the owner can use this command.")
                    return
                param = msg_lower[len("-autodj "):].strip()
                if param == "on":
                    self.autodj = True
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ AutoDJ is now ON.")
                    self.start_music_worker()
                elif param == "off":
                    self.autodj = False
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ AutoDJ is now OFF.")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -autodj [on/off]")
                return

            elif msg_lower == "-add":
                if not (self.is_vip(user.username) or self.is_owner(user.username) or self.is_mod(user.username)):
                    await self.highrise.send_whisper(user.id, "❌ Only VIPs, owners, and moderators can use -add.")
                    return
                current_song = getattr(self, "current_song", None)
                if not current_song:
                    await self.highrise.send_whisper(user.id, "❌ No song is currently playing!")
                    return
                song_name = current_song.get("title") or current_song.get("web_url")
                if not song_name:
                    await self.highrise.send_whisper(user.id, "❌ Could not determine current song name.")
                    return
                if not hasattr(self, "autodj_playlist") or not isinstance(self.autodj_playlist, list):
                    self.autodj_playlist = []
                song_name_lower = song_name.lower()
                if any(s.lower() == song_name_lower for s in self.autodj_playlist):
                    await self.highrise.send_whisper(user.id, f"⚠️ '{song_name}' is already in the AutoDJ playlist!")
                    return
                self.autodj_playlist.append(song_name)
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Added to AutoDJ playlist: {song_name} (Total: {len(self.autodj_playlist)} songs)")
                return

            elif msg_lower.startswith("-addplay ") or msg_lower == "-addplay":
                if not (self.is_owner(user.username) or self.is_mod(user.username)):
                    await self.highrise.send_whisper(user.id, "❌ Only owner and moderators can use -addplay.")
                    return
                song_name = message[8:].strip() if len(message) > 8 else ""
                if not song_name:
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -addplay <song name>")
                    return
                if not hasattr(self, "autodj_playlist") or not isinstance(self.autodj_playlist, list):
                    self.autodj_playlist = []
                song_name_lower = song_name.lower()
                if any(s.lower() == song_name_lower for s in self.autodj_playlist):
                    await self.highrise.send_whisper(user.id, f"⚠️ '{song_name}' is already in the AutoDJ playlist!")
                    return
                self.autodj_playlist.append(song_name)
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Added to AutoDJ playlist: {song_name} (Total: {len(self.autodj_playlist)} songs)")
                return

            elif msg_lower.startswith("-play ") or msg_lower == "-play" or msg_lower.startswith("-p ") or msg_lower == "-p":
                if msg_lower.startswith("-play ") or msg_lower == "-play":
                    query = message[5:].strip() if len(message) > 5 else ""
                else:
                    query = message[3:].strip() if len(message) > 3 else ""
                
                if query:
                    await self.highrise.send_whisper(user.id, f"🔍 Searching YouTube for '{query}'...")
                    asyncio.create_task(self.handle_play_command(query, user))
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -play <full song name> or -p <song name>")
                return

            elif msg_lower == "-np":
                np_msg = await self.get_now_playing_message()
                if np_msg:
                    await self.highrise.send_whisper(user.id, np_msg)
                else:
                    await self.highrise.send_whisper(user.id, "❌ Nothing is currently playing.")
                return

            elif msg_lower == "-price":
                sp = getattr(self, "song_price", 10)
                msg = f"🎵 Music Ticket Price: {sp} Gold (1 Ticket = 1 Song)"
                await self.highrise.send_whisper(user.id, msg)
                return

            elif msg_lower == "-stats":
                user_id_str = str(user.id)
                # Requests count
                req_count = 0
                if hasattr(self, "song_ratings") and "__user_plays__" in self.song_ratings:
                    req_count = self.song_ratings["__user_plays__"].get(user_id_str, 0)
                
                # Ticket balance
                ticket_count = 0
                if hasattr(self, "balances"):
                    ticket_count = self.balances.get(user_id_str, 0)
                    
                # VIP status
                vip_status = "Yes ⭐" if self.is_vip(user.username) else "No"
                
                # Favorites count
                profile = self.get_user_profile(user.id, user.username)
                favs_count = len(profile.get("favorites", []))
                
                stats_msg = (
                    f"\n📊 Your Stats (@{user.username}) 📊\n"
                    f"🎶 Total Songs Requested: {req_count}\n"
                    f"🎫 Ticket Balance: {ticket_count}\n"
                    f"⭐ VIP Status: {vip_status}\n"
                    f"❤️ Favorite Songs: {favs_count}/10"
                )
                await self.highrise.send_whisper(user.id, stats_msg)
                return

            elif msg_lower == "-bal" or msg_lower == "-balance":
                sender_id_str = str(user.id)
                if not hasattr(self, "balances"):
                    self.balances = {}
                if sender_id_str not in self.balances:
                    self.balances[sender_id_str] = 0
                    self.save_balances()
                bal = self.balances[sender_id_str]
                await self.highrise.send_whisper(user.id, f"🎟️ You have {bal} tickets.")
                return

            elif msg_lower.startswith("-give "):
                is_privileged = self.is_owner(user.username) or self.is_mod(user.username)
                if not is_privileged:
                    await self.highrise.send_whisper(user.id, "❌ Only owners and moderators can use this command.")
                    return
                parts = message.split()
                if len(parts) < 3 or not parts[1].startswith("@"):
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -give @username <amount>")
                    return
                target_username = parts[1][1:].lower()
                try:
                    amount = int(parts[2])
                    if amount <= 0:
                        await self.highrise.send_whisper(user.id, "❌ Amount must be positive.")
                        return
                        
                    target_id = None
                    room_users = await self.highrise.get_room_users()
                    for u, _ in room_users.content:
                        if u.username.lower() == target_username:
                            target_id = str(u.id)
                            break
                    if not target_id:
                        for uname, uid in getattr(self, "id_cache", {}).items():
                            if uname.lower() == target_username:
                                target_id = uid
                                break
                    if not target_id:
                        await self.highrise.send_whisper(user.id, "❌ User not found in room or cache. They must join first.")
                        return

                    if not hasattr(self, "balances"):
                        self.balances = {}
                    
                    self.balances[target_id] = self.balances.get(target_id, 0) + amount
                    self.save_balances()
                    await self.highrise.send_whisper(user.id, f"✅ Sent {amount} tickets to @{target_username}. New balance: {self.balances[target_id]}")
                    await self.highrise.send_whisper(target_id, f"🎁 You received {amount} tickets from @{user.username}! Your new balance is {self.balances[target_id]} tickets.")
                except ValueError:
                    await self.highrise.send_whisper(user.id, "❌ Invalid amount.")
                return
            elif msg_lower.startswith("-setprice "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only the owner can use this command.")
                    return
                try:
                    price = int(msg_lower[len("-setprice "):].strip())
                    self.song_price = price
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"✅ Song price set to {price} gold.")
                except ValueError:
                    await self.highrise.send_whisper(user.id, "❌ Invalid amount. Usage: -setprice <number>")
                return

            elif msg_lower.startswith("-paidmode "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only the owner can use this command.")
                    return
                param = msg_lower[len("-paidmode "):].strip()
                if param == "on":
                    self.paid_mode = True
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Paid Mode is now ON (Regular users must tip).")
                elif param == "off":
                    self.paid_mode = False
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Paid Mode is now OFF (Everyone plays for free).")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ Usage: -paidmode [on/off]")
                return

            elif msg_lower == "-vipcost":
                prices = getattr(self, "vip_prices", {"3": "0", "6": "0", "12": "0"})
                await self.highrise.chat(f"💎 VIP Prices:\n3 Months: {prices.get('3', '0')}\n6 Months: {prices.get('6', '0')}\n12 Months: {prices.get('12', '0')}\n💎 Want VIP? Use -buyvip or tip the bot to unlock exclusive VIP perks & premium commands!")
                return

            elif msg_lower.startswith("-buyvip"):
                parts = message.split()
                if len(parts) == 2:
                    month = parts[1]
                    if month in ["3", "6", "12"]:
                        prices = getattr(self, "vip_prices", {"3": "0", "6": "0", "12": "0"})
                        price = prices.get(month, "0")
                        await self.highrise.chat(f"💎 To purchase VIP for {month} months, please tip the bot {price} gold.")
                    else:
                        await self.highrise.send_whisper(user.id, "Please specify 3, 6, or 12 for the month. Example: -buyvip 3")
                else:
                    await self.highrise.send_whisper(user.id, "Usage: -buyvip <month>. Example: -buyvip 3")
                return

            elif msg_lower.startswith("-setvip"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the bot owner can use this command.")
                    return
                parts = message.split()
                if len(parts) >= 3:
                    month = parts[1]
                    amount = " ".join(parts[2:])
                    if month in ["3", "6", "12"]:
                        if not hasattr(self, "vip_prices"):
                            self.vip_prices = {"3": "0", "6": "0", "12": "0"}
                        self.vip_prices[month] = amount
                        self.save_config()
                        await self.highrise.chat(f"✅ VIP price for {month} months has been set to {amount}!")
                    else:
                        await self.highrise.send_whisper(user.id, "Please specify 3, 6, or 12 for the month.")
                else:
                    await self.highrise.send_whisper(user.id, "Usage: -setvip [month] [amount] (e.g. -setvip 3 300)")
                return

            # Jail Commands
            if msg_lower.startswith(("-createjail", "-remjail", "-jail", "-bail", "-createbail", "-rembail")):
                parts = message.split()
                cmd = parts[0].lower()

                if cmd == "-createbail":
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "Only the bot owner can use -createbail.")
                        return
                    if getattr(self, "bail_pos", None):
                        await self.highrise.chat("❌ Bail Point already exists.")
                        return
                    room_users = await self.highrise.get_room_users()
                    user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                    if isinstance(user_pos, Position):
                        self.bail_pos = {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z}
                        self.save_config()
                        await self.highrise.chat("✅ Bail Point Created!\\n📍 Location has been saved.\\n🔓 Players who receive bail will be released here.")
                    else:
                        await self.highrise.send_whisper(user.id, "Could not determine your position to create bail point.")
                    return

                elif cmd == "-rembail":
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "Only the bot owner can use -rembail.")
                        return
                    if getattr(self, "bail_pos", None):
                        self.bail_pos = None
                        self.save_config()
                        await self.highrise.chat("🗑️ Bail Point Removed!\\nThe saved bail location has been deleted.\\nPlayers can no longer be released to a bail point.")
                    else:
                        await self.highrise.chat("❌ No Bail Point found.")
                    return

                elif cmd == "-createjail":
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "Only the bot owner can use -createjail.")
                        return
                    room_users = await self.highrise.get_room_users()
                    user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                    if isinstance(user_pos, Position):
                        self.jail_pos = {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z}
                        self.save_config()
                        await self.highrise.chat("🔒 Jail location created successfully.\\nAll jailed users will be teleported here.")
                    else:
                        await self.highrise.send_whisper(user.id, "Could not determine your position to create jail.")
                    return

                elif cmd == "-remjail":
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "Only the bot owner can use -remjail.")
                        return
                    if getattr(self, "jail_pos", None):
                        self.jail_pos = None
                        self.save_config()
                        await self.highrise.chat("✅ Jail removed successfully.")
                    else:
                        await self.highrise.chat("❌ No jail has been created.")
                    return

                elif cmd == "-jail":
                    if not is_staff:
                        await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only Moderators and Owners can use -jail.")
                        return
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, "Usage: -jail @username [time_in_minutes]")
                        return
                    if not getattr(self, "jail_pos", None):
                        await self.highrise.send_whisper(user.id, "❌ No jail has been created. Use -createjail first.")
                        return
                    target_name = parts[1].replace("@", "").lower()
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        jail_time = None
                        if len(parts) > 2 and parts[2].replace("m", "").isdigit():
                            jail_time = int(parts[2].replace("m", ""))
                            
                        if not hasattr(self, "jailed_users"):
                            self.jailed_users = {}
                        self.jailed_users[target_name] = {
                            "username": target_name,
                            "jailed": True,
                            "time": jail_time,
                            "jailed_at": time.time()
                        }
                        self.save_config()
                        jp = self.jail_pos
                        await self.highrise.teleport(target_id, Position(jp["x"], jp["y"], jp["z"]))
                        
                        await self.highrise.chat(f"🚔 {target_name} has been jailed.\\nReason: Rule violation.")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd == "-bail":
                    if not is_staff:
                        await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only Moderators and Owners can use -bail.")
                        return
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, "Usage: -bail @username")
                        return
                    target_name = parts[1].replace("@", "").lower()
                    target_id = await self.get_id_from_name(target_name)
                    if hasattr(self, "jailed_users") and target_name in self.jailed_users:
                        del self.jailed_users[target_name]
                        self.save_config()
                        if target_id:
                            if getattr(self, "bail_pos", None):
                                bp = self.bail_pos
                                await self.highrise.teleport(target_id, Position(bp["x"], bp["y"], bp["z"]))
                            elif getattr(self, "spawn_pos", None):
                                sp = self.spawn_pos
                                await self.highrise.teleport(target_id, Position(sp["x"], sp["y"], sp["z"]))
                        await self.highrise.chat(f"✅ {target_name} has been released from jail.")
                    else:
                        await self.highrise.send_whisper(user.id, f"@{target_name} is not in jail.")
                    return

            # Moderation Commands
            if msg_lower.startswith(("-freeze", "-unfreeze", "-mute", "-unmute", "-ban", "-unban", "-kick", "-follow", "-unfollow", "-summon", "-bringeveryone", "-addline", "-clearline", "-startline", "-stopline", "-moveline")):
                if not is_staff:
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only Moderators and Owners can use moderation commands.")
                    return

                parts = message.split()
                cmd = parts[0].lower()
                
                if cmd in ["-freeze"]:
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, f"Usage: {cmd} @username")
                        return
                    target_name = parts[1].replace("@", "")
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        # Get target's current position to freeze them there
                        room_users = await self.highrise.get_room_users()
                        target_pos = next((p for u, p in room_users.content if u.id == target_id), None)
                        if isinstance(target_pos, Position):
                            self.frozen_users[target_id] = target_pos
                            await self.highrise.send_whisper(user.id, f"@{target_name} has been frozen.")
                            asyncio.create_task(self.notify_moderation(user.username, "freeze", target_name))
                        else:
                            await self.highrise.send_whisper(user.id, f"Could not find position for @{target_name}.")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd in ["-unfreeze"]:
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, f"Usage: {cmd} @username")
                        return
                    target_name = parts[1].replace("@", "")
                    target_id = await self.get_id_from_name(target_name)
                    if target_id in self.frozen_users:
                        del self.frozen_users[target_id]
                        # Also free up their line spot, if they were in the line
                        if hasattr(self, "line_users") and target_id in self.line_users:
                            idx = self.line_users.index(target_id)
                            self.line_users[idx] = None
                        await self.highrise.send_whisper(user.id, f"@{target_name} has been unfrozen.")
                    else:
                        await self.highrise.send_whisper(user.id, f"@{target_name} is not frozen.")
                    return

                elif cmd == "-addline":
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                        return
                    if len(parts) < 2 or not parts[1].isdigit() or int(parts[1]) < 1:
                        await self.highrise.send_whisper(user.id, "Usage: -addline <number> (e.g. -addline 1, -addline 2 ...)")
                        return
                    spot_num = int(parts[1])
                    idx = spot_num - 1
                    room_users = await self.highrise.get_room_users()
                    if isinstance(room_users, Error):
                        await self.highrise.send_whisper(user.id, "Could not get room users.")
                        return
                    caller_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                    if isinstance(caller_pos, Position):
                        while len(self.line_positions) <= idx:
                            self.line_positions.append(None)
                            self.line_users.append(None)
                        self.line_positions[idx] = {
                            "x": caller_pos.x, "y": caller_pos.y, "z": caller_pos.z,
                            "facing": getattr(caller_pos, "facing", "FrontRight")
                        }
                        self.save_config()
                        await self.highrise.send_whisper(user.id, f"✅ Line spot #{spot_num} saved at your position. (Lowest number = back of line, highest number = front.)")
                    else:
                        await self.highrise.send_whisper(user.id, "Could not find your position.")
                    return

                elif cmd == "-clearline":
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                        return
                    for uid in self.line_users:
                        if uid and uid in self.frozen_users:
                            del self.frozen_users[uid]
                    self.line_positions = []
                    self.line_users = []
                    self.line_active = False
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "🗑️ Line cleared — all spots removed and any lined-up users released.")
                    return

                elif cmd == "-startline":
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                        return
                    if not self.line_positions:
                        await self.highrise.send_whisper(user.id, "No line spots set yet. Use -addline at each spot first.")
                        return
                    room_users = await self.highrise.get_room_users()
                    if isinstance(room_users, Error):
                        await self.highrise.send_whisper(user.id, "Could not get room users.")
                        return
                    eligible = [u for u, p in room_users.content if u.id != self.my_id]
                    self.line_users = [None] * len(self.line_positions)
                    defined_spots = [(i, pd) for i, pd in enumerate(self.line_positions) if pd is not None]
                    placed = 0
                    for (idx, pos_dict), target_user in zip(defined_spots, eligible):
                        pos = Position(x=pos_dict["x"], y=pos_dict["y"], z=pos_dict["z"], facing=pos_dict.get("facing", "FrontRight"))
                        try:
                            await self.highrise.teleport(target_user.id, pos)
                            self.frozen_users[target_user.id] = pos
                            self.line_users[idx] = target_user.id
                            placed += 1
                        except Exception as e:
                            print(f"Error placing {target_user.username} in line: {e}")
                    self.line_active = True
                    await self.highrise.send_whisper(user.id, f"🔒 Auto-line ON — {placed} user(s) placed now. Anyone who joins the room next will auto-fill the next open spot too.")
                    return

                elif cmd == "-stopline":
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                        return
                    self.line_active = False
                    for uid in self.line_users:
                        if uid and uid in self.frozen_users:
                            del self.frozen_users[uid]
                    self.line_users = [None] * len(self.line_positions)
                    await self.highrise.send_whisper(user.id, "⏸️ Auto-line OFF — everyone released. Spots are still saved, use -startline to begin again.")
                    return

                elif cmd == "-moveline":
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                        return
                    if not self.line_positions:
                        await self.highrise.send_whisper(user.id, "No line set up yet. Use -addline first.")
                        return
                    defined_indices = [i for i, pd in enumerate(self.line_positions) if pd is not None]
                    new_line_users = list(self.line_users)
                    moved = 0
                    for pos_in_list in range(len(defined_indices) - 2, -1, -1):
                        i = defined_indices[pos_in_list]
                        next_i = defined_indices[pos_in_list + 1]
                        uid = self.line_users[i]
                        if uid and new_line_users[next_i] is None:
                            new_line_users[next_i] = uid
                            new_line_users[i] = None
                            pos_dict = self.line_positions[next_i]
                            pos = Position(x=pos_dict["x"], y=pos_dict["y"], z=pos_dict["z"], facing=pos_dict.get("facing", "FrontRight"))
                            try:
                                await self.highrise.teleport(uid, pos)
                                self.frozen_users[uid] = pos
                                moved += 1
                            except Exception as e:
                                print(f"Error moving line user forward: {e}")
                    self.line_users = new_line_users
                    await self.highrise.send_whisper(user.id, f"➡️ Moved {moved} user(s) forward in the line. (Front spot full? Use -unfreeze @user to release them first.)")
                    return

                elif cmd == "-mute":
                    if len(parts) < 3:
                        await self.highrise.send_whisper(user.id, "Usage: -mute @username (minutes)")
                        return
                    target_name = parts[1].replace("@", "")
                    try:
                        minutes = int(parts[2])
                    except:
                        await self.highrise.send_whisper(user.id, "Please provide a valid number of minutes.")
                        return
                    
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        try:
                            # Use server-side moderation to mute the user
                            # This actually prevents their chat from appearing in the room
                            await self.highrise.moderate_room(target_id, "mute", minutes * 60)
                            await self.highrise.send_whisper(user.id, f"@{target_name} has been muted for {minutes} minutes.")
                            asyncio.create_task(self.notify_moderation(user.username, "mute", target_name, f"{minutes} min"))
                        except Exception as e:
                            print(f"Error muting {target_name}: {e}")
                            await self.highrise.send_whisper(user.id, f"Failed to mute @{target_name}. Check bot permissions.")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd in ["-unmute"]:
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, f"Usage: {cmd} @username")
                        return
                    
                    target_name = parts[1].replace("@", "").lower()
                    target_id = await self.get_id_from_name(target_name)
                    
                    if target_id:
                        try:
                            # Using 1 second mute trick to clear previous mute state
                            # This is often the most reliable way to 'unmute' in Highrise
                            await self.highrise.moderate_room(target_id, "mute", 1)
                            await self.highrise.send_whisper(user.id, f"🔊 @{target_name} has been unmuted!")
                        except Exception as e:
                            print(f"Unmute error for {target_name}: {e}")
                            # Fallback to 'unmute' action just in case it's supported
                            try:
                                await self.highrise.moderate_room(target_id, "unmute")
                                await self.highrise.send_whisper(user.id, f"🔊 @{target_name} has been unmuted (action)!")
                            except:
                                await self.highrise.send_whisper(user.id, f"Failed to unmute @{target_name}. Please check bot permissions.")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found in the room.")
                    return

                elif cmd in ["-ban"]:
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, f"Usage: {cmd} @username [minutes]")
                        return
                    target_name = parts[1].replace("@", "")
                    minutes = 0
                    if len(parts) > 2 and parts[2].isdigit():
                        minutes = int(parts[2])
                    
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        try:
                            # minutes=0 in SDK usually means permanent in room context, 
                            # but the request says "temporarily", so we use the minutes if provided.
                            # The SDK method for ban is 'ban_user'
                            await self.highrise.moderate_room(target_id, "ban", minutes * 60 if minutes > 0 else 3600)
                            self.banned_users[target_name.lower()] = target_id
                            await self.highrise.send_whisper(user.id, f"@{target_name} has been banned for {minutes if minutes > 0 else 60} minutes.")
                            asyncio.create_task(self.notify_moderation(user.username, "ban", target_name, f"{minutes if minutes > 0 else 60} min"))
                        except Exception as e:
                            await self.highrise.send_whisper(user.id, f"Failed to ban @{target_name}: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd in ["-unban"]:
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, "Usage: -unban @username")
                        return
                    
                    target_name = parts[1].replace("@", "").lower()
                    target_id = None
                    
                    # 1. Try finding in local banned list first
                    if target_name in self.banned_users:
                        target_id = self.banned_users[target_name]
                    else:
                        # 2. If not found, try searching globally (since user is not in room)
                        target_id = await self.get_user_id_webapi(target_name)
                    
                    if target_id:
                        try:
                            # Standard moderation unban
                            await self.highrise.moderate_room(target_id, "unban")
                            # SDK unban user (sometimes needed for global unban)
                            try:
                                await self.highrise.unban_user(target_id)
                            except: pass
                            
                            # Remove from local list if present
                            if target_name in self.banned_users:
                                del self.banned_users[target_name]
                                
                            await self.highrise.send_whisper(user.id, f"✅ @{target_name} has been unbanned!")
                        except Exception as e:
                            print(f"Unban error for {target_name}: {e}")
                            await self.highrise.send_whisper(user.id, f"Failed to unban @{target_name}: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, f"Could not find @{target_name} to unban.")
                    return

                elif cmd == "-kick":
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, "Usage: -kick @username")
                        return
                    target_name = parts[1].replace("@", "")
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        try:
                            await self.highrise.moderate_room(target_id, "kick")
                            await self.highrise.send_whisper(user.id, f"@{target_name} has been kicked from the room.")
                            asyncio.create_task(self.notify_moderation(user.username, "kick", target_name))
                        except Exception as e:
                            await self.highrise.send_whisper(user.id, f"Failed to kick @{target_name}: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd == "-follow":
                    if len(parts) < 2:
                        self.following_user_id = user.id
                        await self.highrise.send_whisper(user.id, "Now following you.")
                        room_users = await self.highrise.get_room_users()
                        user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                        if isinstance(user_pos, Position):
                            try:
                                await self.highrise.walk_to(user_pos)
                            except: pass
                        return
                    target_name = parts[1].replace("@", "")
                    target_id = await self.get_id_from_name(target_name)
                    if target_id:
                        self.following_user_id = target_id
                        await self.highrise.send_whisper(user.id, f"Now following @{target_name}.")
                        room_users = await self.highrise.get_room_users()
                        target_pos = next((p for u, p in room_users.content if u.id == target_id), None)
                        if isinstance(target_pos, Position):
                            try:
                                await self.highrise.walk_to(target_pos)
                            except: pass
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_name} not found.")
                    return

                elif cmd == "-unfollow":
                    self.following_user_id = None
                    await self.highrise.send_whisper(user.id, "Stopped following.")
                    return

                elif cmd == "-bringeveryone" or msg_lower.startswith("-summon all"):
                    room_users = await self.highrise.get_room_users()
                    caller_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                    if isinstance(caller_pos, Position):
                        summon_count = 0
                        for r_user, _ in room_users.content:
                            if r_user.id != user.id:
                                try:
                                    await self.highrise.teleport(r_user.id, caller_pos)
                                    summon_count += 1
                                except: pass
                        await self.highrise.send_whisper(user.id, f"Summoned {summon_count} users to your position.")
                    else:
                        await self.highrise.send_whisper(user.id, "Could not find your position to summon users.")
                    return

            # Handle '-botfit @username' to copy outfit (Owner only)
            elif msg_lower.startswith("-botfit"):
                if self.is_owner(user.username):
                    # Ultra-Advanced Command with Multi-Phase Extraction
                    try:
                        # Extract target name (handles both '-botfit @name' and '-botfit name')
                        target_name = message[7:].strip().replace("@", "")
                        target_id = None

                        if not target_name:
                            # If no name is provided, copy the sender's outfit
                            target_name = user.username
                            target_id = user.id
                        
                        await self.highrise.send_whisper(user.id, f"🔍 Initializing deep scan for @{target_name}... ✨")


                        # --- PHASE 1: DISCOVERY & ID RESOLUTION ---
                        is_id = len(target_name) == 24 and all(c in "0123456789abcdef" for c in target_name.lower())
                        
                        # 1. Check room users first
                        if not target_id and not is_id:
                            try:
                                room_users_res = await self.highrise.get_room_users()
                                if not isinstance(room_users_res, Error):
                                    for u, _ in room_users_res.content:
                                        if u.username.lower() == target_name.lower():
                                            target_id = u.id
                                            target_name = u.username
                                            break
                            except: pass

                        # 2. Global Search if not in room
                        if not target_id and not is_id:
                            target_id = await self.get_user_id_webapi(target_name)

                        # --- PHASE 2: OUTFIT EXTRACTION ---
                        target_outfit = None
                        
                        # Strategy A: Gateway (SDK) - Best for live users/bots
                        if target_id or is_id:
                            try:
                                print(f"[DEBUG] Trying Gateway extraction for {target_id or target_name}")
                                outfit_res = await self.highrise.get_user_outfit(target_id or target_name)
                                if not isinstance(outfit_res, Error) and outfit_res.outfit:
                                    target_outfit = outfit_res.outfit
                            except Exception as e:
                                print(f"[DEBUG] Gateway extraction failed: {e}")

                        # Strategy B: WebAPI (Cloud) - Fallback for global/offline users
                        if not target_outfit:
                            try:
                                print(f"[DEBUG] Trying Cloud extraction for {target_name}")
                                target_outfit = await self.get_user_outfit_webapi(target_id or target_name)
                            except Exception as e:
                                print(f"[DEBUG] Cloud extraction failed: {e}")

                        if target_outfit is None:
                            await self.highrise.send_whisper(user.id, f"❌ Extraction failed for @{target_name}. Profile might be private or restricted.")
                            return
                        
                        if len(target_outfit) == 0:
                            await self.highrise.send_whisper(user.id, f"👻 @{target_name} is currently invisible or wearing nothing compatible!")
                            return

                        # 3. Visual Transformation & Execution
                        await self.highrise.send_whisper(user.id, f"👕 Style extracted! Applying @{target_name}'s look...")
                        
                        try:
                            # Apply the outfit
                            await self.highrise.set_outfit(target_outfit)
                            await self.highrise.send_whisper(user.id, f"🏁 ✨ 𝐏𝐄𝐑𝐅𝐄𝐂𝐓 𝐄𝐗𝐓𝐑𝐀𝐂𝐓𝐈𝐎𝐍! I'm now a 1:1 copy of @{target_name}! ✨")
                            
                            # Persistent Save
                            self.config["BOT_OUTFIT"] = [{"id": i.id, "amount": i.amount} for i in target_outfit]
                            self.save_config()
                            
                            # Autosave to fit.json number wise
                            try:
                                fit_file = "fit.json"
                                fits = {}
                                if os.path.exists(fit_file):
                                    with open(fit_file, "r") as f:
                                        try:
                                            fits = json.load(f)
                                        except json.JSONDecodeError:
                                            fits = {}
                                
                                # Find next number
                                max_num = 0
                                for key in fits.keys():
                                    if key.isdigit():
                                        max_num = max(max_num, int(key))
                                
                                next_num = str(max_num + 1)
                                fits[next_num] = [{"id": i.id, "amount": i.amount, "palette": i.active_palette} for i in target_outfit]
                                
                                with open(fit_file, "w") as f:
                                    json.dump(fits, f, indent=4)
                                
                                await self.highrise.send_whisper(user.id, f"💾 Outfit autosaved to fit.json as #{next_num}!")
                            except Exception as e:
                                print(f"Error autosaving fit: {e}")
                        except Exception as e:
                            # Fallback: Clothing only
                            print(f"[DEBUG] Full outfit set failed: {e} | Trying Safe Mode Fallback...")
                            clothing_only = [i for i in target_outfit if "body" not in i.id.lower()]
                            try:
                                await self.highrise.set_outfit(clothing_only)
                                await self.highrise.send_whisper(user.id, f"✅ Look applied (Safe Mode)! Some body/face items were incompatible.")
                            except:
                                await self.highrise.send_whisper(user.id, f"❌ Failed to apply outfit: {str(e)[:50]}")
                    except Exception as e:
                        await self.highrise.send_whisper(user.id, f"❌ Error during extraction: {str(e)[:100]}")
                else:
                    await self.highrise.send_whisper(user.id, "Sorry, only owners can use -botfit.")
                return


            elif msg_lower.startswith("-fit"):
                parts = message.split()
                if parts[0].lower() == "-fit":
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "Only the bot owner can use -fit.")
                        return
                    
                    if len(parts) >= 2:
                        fit_num = parts[1]
                        try:
                            fit_file = "fit.json"
                            
                            if os.path.exists(fit_file):
                                with open(fit_file, "r") as f:
                                    fits = json.load(f)
                                
                                if fit_num in fits:
                                    fit_data = fits[fit_num]
                                    target_outfit = [Item(type='clothing', id=item["id"], amount=item.get("amount", 1), active_palette=item.get("palette", item.get("active_palette", -1))) for item in fit_data]
                                    await self.highrise.set_outfit(target_outfit)
                                    await self.highrise.send_whisper(user.id, f"✅ Outfit #{fit_num} applied!")
                                else:
                                    await self.highrise.send_whisper(user.id, f"❌ Outfit #{fit_num} not found in fit.json.")
                            else:
                                await self.highrise.send_whisper(user.id, "❌ fit.json does not exist yet.")
                        except Exception as e:
                            print(f"Error loading fit: {e}")
                            await self.highrise.send_whisper(user.id, f"❌ Error loading outfit: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, "Usage: -fit <number>")
                    return

            # Handle '-revertfit' to go back to original look (Owner only)
            elif msg_lower == "-revertfit":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use -revertfit.")
                    return
                
                if self.original_outfit:
                    try:
                        await self.highrise.set_outfit(self.original_outfit)
                        await self.highrise.send_whisper(user.id, f"@{user.username}, I've reverted to my original outfit!")
                    except Exception as e:
                        print(f"Error in -revertfit: {e}")
                        await self.highrise.send_whisper(user.id, "Failed to revert outfit.")
                else:
                    await self.highrise.send_whisper(user.id, "I don't have my original outfit saved.")
                return

            # Handle '-setoriginal' to save current look as the base (Owner only)
            if msg_lower == "-setoriginal":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use -setoriginal.")
                    return
                
                try:
                    outfit_res = await self.highrise.get_user_outfit(self.my_id)
                    if not isinstance(outfit_res, Error):
                        self.original_outfit = outfit_res.outfit
                        self.config["ORIGINAL_OUTFIT"] = [{"id": i.id, "amount": i.amount} for i in self.original_outfit]
                        self.save_config()
                        await self.highrise.send_whisper(user.id, "Current outfit saved as the bot's original look! ✅")
                    else:
                        await self.highrise.send_whisper(user.id, "Failed to fetch current outfit.")
                except Exception as e:
                    await self.highrise.send_whisper(user.id, f"Error saving outfit: {e}")
                return

            # Handle user emote loops
            
            if msg_lower == "-stopall":
                if await self.is_mod_or_owner(user.id, user.username):
                    if not self.user_loops:
                        await self.highrise.send_whisper(user.id, "No active user emote loops to stop.")
                        return
                    count = len(self.user_loops)
                    self.user_loops.clear()
                    await self.highrise.send_whisper(user.id, f"Stopped all {count} active user emote loops by @{user.username}.")
                else:
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only owners and moderators can use -stopall.")
                return

            if msg_lower.startswith("-stop "):
                if await self.is_mod_or_owner(user.id, user.username):
                    parts = message.split()
                    if len(parts) < 2:
                        await self.highrise.send_whisper(user.id, "Usage: -stop @username")
                        return
                    target_username = parts[1].replace("@", "")
                    target_id = await self.get_id_from_name(target_username)
                    if target_id and target_id in self.user_loops:
                        del self.user_loops[target_id]
                        await self.highrise.send_whisper(user.id, f"Stopped @{target_username}'s emote loop by @{user.username}.")
                    else:
                        await self.highrise.send_whisper(user.id, f"User @{target_username} is not in an active emote loop.")
                else:
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only owners and moderators can stop others' loops.")
                return

            if msg_lower in ["-stop", "stop"]:
                # Stop personal loop
                if user.id in self.user_loops:
                    del self.user_loops[user.id]
                    await self.highrise.send_whisper(user.id, f"@{user.username}, your emote loop has been stopped.")
                    return
                return

            # ── PROTECT / FREE a user from being emoted on (Owner/Mod) ──────
            if msg_lower.startswith("-protect "):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only owners and moderators can use -protect.")
                    return
                parts = message.split(None, 1)
                if len(parts) < 2 or not parts[1].strip():
                    await self.highrise.send_whisper(user.id, "Usage: -protect <username>")
                    return
                target_username = parts[1].strip().replace("@", "")
                if not getattr(self, "protected_users", None):
                    self.protected_users = []
                if target_username.lower() in [p.lower() for p in self.protected_users]:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is already protected.")
                    return
                self.protected_users.append(target_username)
                self.save_config()
                # Stop any emote loop currently running on them, right now
                try:
                    target_id = await self.get_id_from_name(target_username)
                    if target_id and target_id in self.user_loops:
                        del self.user_loops[target_id]
                except Exception:
                    pass
                await self.highrise.send_whisper(user.id, f"🛡️ @{target_username} is now protected — no one can use emotes on them. Use -free {target_username} to remove.")
                return

            if msg_lower.startswith("-free "):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only owners and moderators can use -free.")
                    return
                parts = message.split(None, 1)
                if len(parts) < 2 or not parts[1].strip():
                    await self.highrise.send_whisper(user.id, "Usage: -free <username>")
                    return
                target_username = parts[1].strip().replace("@", "")
                if target_username.lower() not in [p.lower() for p in getattr(self, "protected_users", [])]:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is not currently protected.")
                    return
                self.protected_users = [p for p in self.protected_users if p.lower() != target_username.lower()]
                self.save_config()
                await self.highrise.send_whisper(user.id, f"@{target_username} has been freed — emotes can be used on them again.")
                return

            # Handle '-(emote)all' to send emote to everyone (Owner/Mod)
            if msg_lower.startswith("-") and msg_lower.endswith("all"):
                emote_key = msg_lower[1:-3].strip()
                if emote_key in self.all_emotes:
                    if not await self.is_mod_or_owner(user.id, user.username):
                        await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, only owners and moderators can use this.")
                        return
                    
                    emote_id = self.all_emotes[emote_key]["id"]
                    try:
                        room_users = await self.highrise.get_room_users()
                        if not isinstance(room_users, Error):
                            for target_user, pos in room_users.content:
                                if target_user.id != self.my_id and not self.is_protected(target_user.username):
                                    try:
                                        await self.highrise.send_emote(emote_id, target_user.id)
                                    except: pass
                            await self.highrise.send_whisper(user.id, f"Sent emote '{emote_key}' to everyone in the room!")
                    except Exception as e:
                        print(f"Error in -(emote)all: {e}")
                    return

            # Handle '(emote) @username' to loop for another user (Everyone)
            if " @" in msg_lower:
                parts = msg_lower.split(" @")
                emote_key = parts[0].strip()
                target_username = parts[1].strip()
                
                if emote_key in self.all_emotes:
                    target_id = await self.get_id_from_name(target_username)
                    if not target_id:
                        await self.highrise.send_whisper(user.id, f"User @{target_username} not found.")
                        return

                    # Protection: protected users can't be emoted on by anyone except the owner
                    if self.is_protected(target_username) and not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, f"🛡️ @{target_username} is protected and can't be emoted on.")
                        return
                    
                    # Restriction: Regular users cannot force emotes on Owners/Moderators
                    target_is_staff = await self.is_mod_or_owner(target_id, target_username)
                    sender_is_staff = is_staff
                    
                    if target_is_staff and not sender_is_staff:
                        await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, you cannot force an emote loop on an Owner or Moderator.")
                        return
                    
                    emote_data = self.all_emotes[emote_key]
                    emote_id = emote_data["id"]
                    duration = emote_data.get("duration", 5)
                    
                    self.user_loops[target_id] = emote_id
                    await self.highrise.send_whisper(user.id, f"@{user.username} started looping {emote_key} for @{target_username}! To stop say 'stop'")
                    asyncio.create_task(self.run_user_emote_loop(target_id, emote_id, duration))
                    return

            # Check if message is an emote name or number from the JSON (Personal Loop)
            if msg_lower in self.all_emotes:
                emote_key = msg_lower
                emote_data = self.all_emotes[emote_key]
                emote_id = emote_data["id"]
                duration = emote_data.get("duration", 5)
                
                # Find the "other" key (name if number was typed, or vice versa)
                emote_name = emote_key
                emote_no = "N/A"
                
                for k, v in self.all_emotes.items():
                    if v["id"] == emote_id:
                        if k.isdigit():
                            emote_no = k
                        else:
                            emote_name = k
                
                # Stop existing loop if any
                self.user_loops[user.id] = emote_id
                
                # Send confirmation message
                await self.highrise.send_whisper(user.id, f"@{user.username} is looping {emote_name} with emote no. {emote_no} \n To stop say 'stop'")
                
                # Start the loop task
                asyncio.create_task(self.run_user_emote_loop(user.id, emote_id, duration))
                return

            # Handle 'start' to control bot's own emote loop
            if message.lower() == "start":
                if not self.is_looping:
                    if not await self.is_mod_or_owner(user.id, user.username):
                        return
                    self.is_looping = True
                    await self.highrise.send_whisper(user.id, f"Bot's global emote loop started by @{user.username}!")
                return

            # Teleport user if they type a location name
            if msg_lower in self.tele_locations:
                loc_key = msg_lower
                loc_data = self.tele_locations[loc_key]
                
                # Permission check
                is_vip = self.is_vip(user.username)
                is_mod = self.is_mod(user.username)
                is_owner = self.is_owner(user.username)
                is_staff = is_mod or is_owner

                if loc_data.get("owner_only") and not is_owner:
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, '{loc_key}' is an OWNER ONLY location.")
                    return
                if loc_data.get("mod_only") and not is_staff:
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, '{loc_key}' is a MODERATOR location.")
                    return
                if loc_data.get("vip") and not (is_staff or is_vip):
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, '{loc_key}' is a VIP location.")
                    return
                
                p = loc_data["pos"]
                await self.highrise.send_whisper(user.id, f"✈️Teleport to {loc_key}")
                await self.highrise.teleport(user.id, Position(p["x"], p["y"], p["z"], p["facing"]))
                return

            # Flash mode control (Owner, Mod, VIP)
            elif message.lower() in ["-flash on", "-flash off"]:
                if not (await self.is_mod_or_owner(user.id, user.username) or self.is_vip(user.username)):
                    await self.highrise.send_whisper(user.id, "Only owner, moderators, and VIPs can use -flash commands.")
                    return
                
                if message.lower() == "-flash on":
                    self.flash_users.add(user.id)
                    await self.highrise.send_whisper(user.id, f"Flash mode enabled for @{user.username}. Click anywhere to teleport!")
                elif message.lower() == "-flash off":
                    if user.id in self.flash_users:
                        self.flash_users.remove(user.id)
                    await self.highrise.send_whisper(user.id, f"Flash mode disabled for @{user.username}.")
                return

            if message.lower() == "-lb":
                if not hasattr(self, "user_stats"): self.user_stats = {}
                sorted_chat = sorted(self.user_stats.items(), key=lambda x: x[1].get("messages", 0), reverse=True)[:10]
                
                def get_time(uid, stats):
                    t = stats.get("total_time", 0)
                    if stats.get("join_time"):
                        t += time.time() - stats["join_time"]
                    return t
                
                sorted_time = sorted(self.user_stats.items(), key=lambda x: get_time(x[0], x[1]), reverse=True)[:10]

                def format_rank(index):
                    if index == 0: return "🥇"
                    if index == 1: return "🥈"
                    if index == 2: return "🥉"
                    return f"{index + 1}."

                lb_msg = "🏆 **Room Leaderboard**\n━━━━━━━━━━━━━━━━━━━━━━━\n\n⏱️ **Top 10 — Time in Room**\n"
                for i, (uid, stats) in enumerate(sorted_time):
                    t = get_time(uid, stats)
                    hours, rem = divmod(t, 3600)
                    mins, secs = divmod(rem, 60)
                    
                    parts = []
                    if hours > 0: parts.append(f"{int(hours)}h")
                    if hours > 0 or mins > 0: parts.append(f"{int(mins)}m")
                    parts.append(f"{int(secs)}s")
                    time_str = " ".join(parts)
                    
                    lb_msg += f"{format_rank(i)} @{stats['name']} — {time_str}\n"

                lb_msg += "\n━━━━━━━━━━━━━━━━━━━━━━━\n\n💬 **Top 10 — Total Messages**\n"
                for i, (uid, stats) in enumerate(sorted_chat):
                    lb_msg += f"{format_rank(i)} @{stats['name']} — {stats.get('messages', 0)} msgs\n"
                
                total_room_msgs = sum(s.get("messages", 0) for s in self.user_stats.values())
                total_room_time = sum(get_time(u, s) for u, s in self.user_stats.items())
                hours_r, rem_r = divmod(total_room_time, 3600)
                mins_r, secs_r = divmod(rem_r, 60)
                parts_r = []
                if hours_r > 0: parts_r.append(f"{int(hours_r)}h")
                if hours_r > 0 or mins_r > 0: parts_r.append(f"{int(mins_r)}m")
                parts_r.append(f"{int(secs_r)}s")
                room_time_str = " ".join(parts_r)

                my_stats = self.user_stats.get(user.id, {})
                my_msgs = my_stats.get("messages", 0)
                my_time = get_time(user.id, my_stats)
                hours_m, rem_m = divmod(my_time, 3600)
                mins_m, secs_m = divmod(rem_m, 60)
                parts_m = []
                if hours_m > 0: parts_m.append(f"{int(hours_m)}h")
                if hours_m > 0 or mins_m > 0: parts_m.append(f"{int(mins_m)}m")
                parts_m.append(f"{int(secs_m)}s")
                my_time_str = " ".join(parts_m)

                lb_msg += f"\n━━━━━━━━━━━━━━━━━━━━━━━\n\n📊 **Room Totals:**\nTime: {room_time_str} | Messages: {total_room_msgs}"
                lb_msg += f"\n\n👤 **Your Stats (@{user.username}):**\nTime: {my_time_str} | Messages: {my_msgs}\n━━━━━━━━━━━━━━━━━━━━━━━"

                try:
                    await self.highrise.send_message_bulk([user.id], lb_msg)
                    await self.highrise.send_whisper(user.id, "Sent leaderboard to your DMs!")
                except:
                    await self.highrise.send_whisper(user.id, "Couldn't DM leaderboard. Check privacy settings.")
                return

            if msg_lower.startswith("-transport ") or msg_lower.startswith("-trasnport "):
                if self.is_owner(user.username):
                    parts = message.split()
                    if len(parts) < 3:
                        await self.highrise.chat("💡 Usage: -transport [all/@username] [room_link/id]")
                        return

                    target = parts[1].lower()
                    room_input = parts[2]

                    candidates = self.parse_room_id_candidates(room_input)
                    if not candidates:
                        await self.highrise.send_whisper(user.id, "❌ Invalid room link or ID. Room ID must be a 24-character hex code or a valid Highrise room URL.")
                        return

                    clean_room_id = None
                    tried_ids = []
                    for cid in candidates:
                        verified = await self.verify_room_exists(cid)
                        tried_ids.append((cid, verified))
                        if verified:
                            clean_room_id = cid
                            break
                    if not clean_room_id:
                        clean_room_id = candidates[0]
                        if len(candidates) > 1:
                            warn = f"⚠️ Could not verify any room ID. Found {len(candidates)} IDs in the link, using the best-match ID: {clean_room_id}"
                            warn += "\n  IDs found (verified?):\n" + "\n".join(f"    • {cid} -> {'✅ Yes' if ok else '❌ No'}" for cid, ok in tried_ids)
                            await self.highrise.send_whisper(user.id, warn)
                    elif len(candidates) > 1:
                        await self.highrise.send_whisper(user.id, f"🔎 Link contained {len(candidates)} IDs. Auto-selected verified room: {clean_room_id}")

                    room_link = f"https://highrise.game/room/{clean_room_id}"
                    room_exists = any(ok for _, ok in tried_ids) if tried_ids else await self.verify_room_exists(clean_room_id)
                    if not room_exists:
                        await self.highrise.send_whisper(user.id, f"⚠️ Warning: Could not verify room {clean_room_id} exists. Proceeding anyway...")

                    if target == "all":
                        await self.highrise.chat(f"🚀 <#00FF00>EVERYONE! The party is moving to a new room!\n👉 Join here: {room_link}")
                        room_users = await self.highrise.get_room_users()
                        success_count = 0
                        fail_count = 0
                        fail_details = []
                        if not isinstance(room_users, Error):
                            total_users = len(room_users.content)
                            await self.highrise.send_whisper(user.id, f"🔄 Transporting {total_users - 1} users to {room_link} ...")
                            for r_user, _ in room_users.content:
                                if r_user.id != getattr(self, "my_id", None):
                                    ok, reason = await self.safe_move_user_to_room(r_user.id, clean_room_id, r_user.username)
                                    if ok:
                                        success_count += 1
                                    else:
                                        fail_count += 1
                                        fail_details.append(f"@{r_user.username}: {reason}")
                                        print(f"Failed to move user {r_user.username}: {reason}")
                                    await asyncio.sleep(0.15)
                            summary = f"✅ Transport complete: {success_count} moved, {fail_count} failed."
                            if fail_details:
                                short_list = fail_details[:8]
                                summary += f"\n❌ Failures:\n" + "\n".join(f"  • {d}" for d in short_list)
                                if len(fail_details) > 8:
                                    summary += f"\n  ... and {len(fail_details) - 8} more"
                            await self.highrise.send_whisper(user.id, summary)
                        else:
                            await self.highrise.send_whisper(user.id, "❌ Could not fetch room users list.")
                    else:
                        target_user = parts[1].replace("@", "")
                        target_id = await self.get_id_from_name(target_user)
                        if target_id:
                            await self.highrise.chat(f"🚀 <#00FF00>@{target_user}, you are requested to move to this room!\n👉 Join here: {room_link}")
                            ok, reason = await self.safe_move_user_to_room(target_id, clean_room_id, target_user)
                            if ok:
                                await self.highrise.send_whisper(user.id, f"✅ Successfully transported @{target_user} to the new room.")
                            else:
                                await self.highrise.send_whisper(user.id, f"❌ Failed to transfer @{target_user}: {reason}")
                                print(f"Failed to move user {target_user}: {reason}")
                        else:
                            await self.highrise.send_whisper(user.id, f"Could not find user @{target_user} to transport.")
                else:
                    await self.highrise.chat("ℹ️ You don't have permission to use this command.")
                return

            if message.lower() == "-clearlb":
                if self.is_owner(user.username):
                    self.user_stats = {}
                    room_users = await self.highrise.get_room_users()
                    if not isinstance(room_users, Error):
                        for ru, _ in room_users.content:
                            self.user_stats[ru.id] = {"name": ru.username, "messages": 0, "join_time": time.time(), "total_time": 0}
                    await self.highrise.send_whisper(user.id, "Leaderboard has been cleared!")
                else:
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                return

            if message.lower() == "-trivia":
                if getattr(self, "trivia_active", False):
                    await self.highrise.send_whisper(user.id, "A trivia game is already running!")
                else:
                    self.trivia_active = True
                    self.trivia_scores = getattr(self, "trivia_scores", {})
                    await self.highrise.chat("🎉 TRIVIA STARTED! 🎉\nGet ready for the first question!")
                    self.trivia_task = asyncio.create_task(self.run_trivia_loop())
                return

            if message.lower() == "-stoptrivia":
                if getattr(self, "trivia_active", False):
                    self.trivia_active = False
                    self.trivia_current_question = None
                    if hasattr(self, "trivia_task") and self.trivia_task:
                        self.trivia_task.cancel()
                    await self.highrise.chat("🛑 TRIVIA STOPPED! 🛑\nThanks for playing!")
                else:
                    await self.highrise.send_whisper(user.id, "No trivia game is currently running.")
                return

            if message.lower() == "-skiptrivia":
                if getattr(self, "trivia_active", False) and getattr(self, "trivia_current_question", None):
                    await self.highrise.chat(f"⏭️ Question skipped! The answer was {self.trivia_current_answer}.")
                    self.trivia_current_question = None
                return
            
            if message.lower() == "-triviascores":
                scores = getattr(self, "trivia_scores", {})
                if not scores:
                    await self.highrise.send_whisper(user.id, "No trivia scores yet!")
                else:
                    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
                    msg = "🏆 Trivia Leaderboard 🏆\n"
                    for i, (uname, score) in enumerate(sorted_scores):
                        msg += f"{i+1}. @{uname} — {score} pts\n"
                    await self.highrise.send_whisper(user.id, msg)
                return

            if message.lower() == "-triviaclearscores":
                self.trivia_scores = {}
                await self.highrise.send_whisper(user.id, "Trivia scores cleared!")
                return

            # Basic help command (always unlocked)
            if message.lower() == "-help":
                help_text_1 = """💎✨ **PREMIUM BOT COMMANDS** ✨💎
🔥 Powered by @ElPhantom 🔥
━━━━━━━━━━━━━━━━━━━━━━━

🛡️ **MODERATION CONTROL**
❖ `-freeze / -unfreeze @user` ➤ Control movement
❖ `-addline [number]` ➤ Save spot #number at your position (e.g. -addline 1)
❖ `-startline` ➤ Turn on auto-line (places everyone now + auto-fills new joiners)
❖ `-stopline` ➤ Turn off auto-line (releases everyone, keeps spots saved)
❖ `-moveline` ➤ Move the line forward one spot
❖ `-clearline` ➤ Reset the whole line (deletes saved spots)
❖ `-mute / -unmute @user [min]` ➤ Control chat access
❖ `-ban / -unban @user [min]` ➤ Room restriction
❖ `-kick @user` ➤ Instant removal
❖ `-jail / -bail @user` ➤ Send/Remove from jail
❖ `-createjail / -remjail` ➤ Set/Remove jail location (Owner)
❖ `-createbail / -rembail` ➤ Set/Remove bail release point (Owner)
❖ `-stop @user` ➤ Stop user loop
❖ `-stopall` ➤ Stop all active loops
❖ `-follow / -unfollow [@user]` ➤ Follow a user
❖ `-summon all / -bringeveryone` ➤ Bring all users to you
❖ `-setspawn` ➤ Set room spawn to your location
❖ `-clearlb` ➤ Clear leaderboards (Owner)

━━━━━━━━━━━━━━━━━━━━━━━

💃 **EMOTES & FUN ZONE**
❖ `-emotelist` ➤ View all emotes
❖ `-(emote) @user` ➤ Loop emote on user
❖ `-(emote)all` ➤ Emote for everyone
❖ `-stop` ➤ Stop your loop
❖ `-emote [name/number/all]` ➤ Bot loop emote
❖ `-emotestop` ➤ Stop bot emote
❖ `-flash on/off` ➤ Click teleport mode
❖ `-punch @user` ➤ Fun interaction
❖ `-[reaction]all` ➤ React for all
❖ `-[reaction] @user [amount]` ➤ Custom reactions
❖ `-trivia` ➤ Play Trivia Game
❖ `-skiptrivia` ➤ Skip current question
❖ `-stoptrivia` ➤ Stop trivia game
❖ `-triviascores` ➤ Show trivia scores
❖ `-triviaclearscores` ➤ Clear trivia scores
❖ `-answer` ➤ Answer during game
❖ `-addemote (url) (name) (sec)` ➤ Add new emote (Owner)
❖ `-editemote (name/#) (sec)` ➤ Edit emote duration (Owner)
❖ `-editemotename (old) (new)` ➤ Rename emote (Owner)
❖ `-duration (name/#)` ➤ Show emote duration (Owner)"""

                help_text_2 = """━━━━━━━━━━━━━━━━━━━━━━━

🤖 **BOT & ROOM FEATURES**
❖ `-botfit [@user/bot]` ➤ Copy outfit
❖ `-bot` ➤ Set bot position
❖ `-back` ➤ Move bot back to saved position
❖ `-botroom [room_id]` ➤ Switch bot to new room
❖ `-lb` ➤ Show room leaderboard
❖ `-invite` ➤ Invite all users
❖ `-wallet` ➤ Check gold balance
❖ `-tip / -tipall / -tiprandom [amount]` ➤ Send gold
❖ `-autotip on/off/time/amount` ➤ Auto-tip loop (Owner)
❖ `-df 1/2/on/off/reset` ➤ Dancefloor loop (Owner)
❖ `-spam [msg] [amount]` ➤ Repeat message
❖ `-promo [num] [msg] [sec]` ➤ Loop advertisement (Owner)
❖ `-clearpromo [num/all]` ➤ Clear advertisement loop (Owner)

━━━━━━━━━━━━━━━━━━━━━━━

🚀 **TELEPORTATION SYSTEM**
❖ `-tele [user/random] [loc/random]` ➤ Warp user
❖ `-void @user` ➤ Send outside map
❖ `-goto / -summon [user]` ➤ Teleport
❖ `-create tele [loc]` ➤ Public Warp
❖ `-createvip tele [loc]` ➤ VIP Warp
❖ `-createmod tele [loc]` ➤ Mod/Owner Warp
❖ `-createowner tele [loc]` ➤ Owner Warp
❖ `-listtele / -remtele [loc] / -clearteles` ➤ Manage warps
❖ `-autotele on/off` ➤ Toggle multi-floor teleport for all (Owner)
❖ `-transport [all/@user] [room_id/link]` ➤ Move users to another room"""

                help_text_3 = """━━━━━━━━━━━━━━━━━━━━━━━

👥 **STAFF & ACCESS CONTROL**
❖ `-sub / -unsub [user]` ➤ Manage access
❖ `-owner / -remowner [user]` ➤ Owner control
❖ `-mod / -remmod [user]` ➤ Moderator control
❖ `-vip / -remvip [user]` ➤ VIP management
❖ `-protect [user]` ➤ Block emotes on a user (Mod/Owner)
❖ `-free [user]` ➤ Remove emote protection (Mod/Owner)
❖ `-vipcost` ➤ Check VIP prices
❖ `-buyvip [month]` ➤ Purchase VIP status
❖ `-vipstatus` ➤ Check VIP time left
❖ `-rolelist` ➤ View all roles
❖ `-setjoin [msg]` ➤ Set welcome message (Owner)
❖ `-setwelcome [msg]` ➤ Set personal welcome (VIP/Mod/Owner)
❖ `-language [name]` ➤ Set bot language (Owner) / show current
❖ `-listlanguage` ➤ Show all languages
❖ `-addnotify @user` ➤ Give user mute/ban/kick/freeze alerts in DM (Owner)
❖ `-remnotify @user` ➤ Remove user from alerts (Owner)
❖ `-notifylist` ➤ Show who gets alerts (Owner)

━━━━━━━━━━━━━━━━━━━━━━━

🌟 **ELITE • FAST • POWERFUL** 🌟
💎 Your Ultimate Premium Experience 💎"""
                
                try:
                    # Send help menu via Direct Message in chunks
                    await self.highrise.send_message_bulk([user.id], help_text_1)
                    await asyncio.sleep(0.5)
                    await self.highrise.send_message_bulk([user.id], help_text_2)
                    await asyncio.sleep(0.5)
                    await self.highrise.send_message_bulk([user.id], help_text_3)
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I've sent the categorized help menu to your DMs! 📩")
                except Exception as e:
                    print(f"Error sending help DM to {user.username}: {e}")
                    # Fallback to chat if DM fails
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I couldn't DM you. Please check your privacy settings.")
                return

            elif message.lower() == "-help music":
                # Determine user role
                if self.is_owner(user.username):
                    role_str = "👑 Owner"
                elif self.is_mod(user.username):
                    role_str = "🛡️ Moderator"
                elif self.is_vip(user.username):
                    role_str = "💎 VIP"
                else:
                    role_str = "👤 User"

                music_help_text = (
                    f"Hey @{user.username}, your role is [{role_str}]. Here are the music commands you can access:\n\n"
                    "🎵 -play or -p <song> - Searches YouTube and queues the song\n\n"
                    "🎧 -np - Shows the currently playing song\n\n"
                    "📋 -q or -queue - Shows the upcoming song queue\n\n"
                    "👍 -like - Like the current song\n\n"
                    "👎 -dislike - Dislike the current song\n\n"
                    "⏭️ -skip - Skip the current song (Requester or Staff only)\n\n"
                    "🧹 -remove <number> - Remove a song from the queue (Requester or Staff only)\n\n"
                    "⬆️ -top <number> - Move a song to the top of the queue (VIP/Staff only)\n\n"
                    "🎁 -gift @user <song> - Gift a song dedication to someone (VIP/Staff only)\n\n"
                    "🧹 -remove - Clear all upcoming songs (Staff only)\n\n"
                    "⏹️ -remove all - Clear queue and stop music (Staff only)\n\n"
                    "⭐ -af - Add the current song to your favorites\n\n"
                    "📜 -lf - List all your favorite songs\n\n"
                    "▶️ -pf <number> - Play a song from your favorites\n\n"
                    "🗑️ -del <number> - Remove a song from your favorites\n\n"
                    "🎟️ -bal or -balance - Check your Music Ticket balance\n\n"
                    "📋 -myq - List all your requested songs currently in the queue\n\n"
                    "📻 -playlist - View all AutoDJ playlist songs\n\n"
                    "➕ -add - Add current song to AutoDJ playlist (VIP/Staff only)\n\n"
                    "🎵 -addplay <song> - Add song to AutoDJ playlist (Owner/Mod only)\n\n"
                    "🗑️ -delplay all - Delete ALL songs from AutoDJ playlist (Owner/Mod only)\n\n"
                    "🗑️ -delplay <number> - Delete one song from AutoDJ playlist (Owner/Mod only)\n\n"
                    "💰 -price - View the current price of a Music Ticket\n\n"
                    "📊 -stats - View your personal stats (Songs, Tickets, VIP)\n\n"
                    "🎁 -give @user <amount> - Give tickets to a user (Staff only)"
                )
                try:
                    await self.highrise.send_message_bulk([user.id], music_help_text)
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I've sent the music help menu to your DMs! 📩")
                except Exception as e:
                    print(f"Error sending music help DM to {user.username}: {e}")
                    await self.highrise.send_whisper(user.id, f"@{user.username}, I couldn't DM you. Please check your privacy settings.")
                return

            elif message.lower() == "-emotestop":
                if not (self.is_owner(user.username) or self.is_mod(user.username)):
                    await self.highrise.send_whisper(user.id, "You don't have permission to use this command.")
                    return
                try:
                    self.is_looping = False
                    self.persistent_bot_emote = None
                    self.save_config()
                    if self.my_id in self.user_loops:
                        del self.user_loops[self.my_id]
                    await self.highrise.send_emote("", self.my_id)
                    await self.highrise.send_whisper(user.id, "Bot stopped emoting.")
                except Exception as e:
                    print(f"Error stopping bot emote: {e}")
                return

            elif message.lower().startswith("-emote ") or message.lower() == "-emote":
                if not (self.is_owner(user.username) or self.is_mod(user.username)):
                    await self.highrise.send_whisper(user.id, "You don't have permission to use this command.")
                    return
                
                parts = message.lower().split(" ", 1)
                if len(parts) == 1:
                    if self.all_emotes:
                        emote_data = random.choice(list(self.all_emotes.values()))
                        emote_id = emote_data["id"]
                        duration = emote_data.get("duration", 5)
                        try:
                            self.is_looping = False
                            self.persistent_bot_emote = emote_id
                            self.save_config()
                            self.user_loops[self.my_id] = emote_id
                            asyncio.create_task(self.run_user_emote_loop(self.my_id, emote_id, duration))
                            await self.highrise.send_whisper(user.id, "Bot is now looping a random emote.")
                        except Exception as e:
                            print(f"Error starting random emote: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, "No emotes loaded.")
                    return
                else:
                    emote_input = parts[1].strip()
                    if emote_input == "all":
                        try:
                            self.is_looping = False
                            self.persistent_bot_emote = "all"
                            self.save_config()
                            self.user_loops[self.my_id] = "all"
                            asyncio.create_task(self.run_all_emote_loop(self.my_id))
                            await self.highrise.send_whisper(user.id, "Bot is now looping ALL emotes continuously.")
                        except Exception as e:
                            print(f"Error starting all emote loop: {e}")
                        return
                        
                    if emote_input in self.all_emotes:
                        emote_data = self.all_emotes[emote_input]
                        emote_id = emote_data["id"]
                        duration = emote_data.get("duration", 5)
                        
                        # Find the actual name if a number was typed
                        actual_name = emote_input
                        if emote_input.isdigit():
                            for k, v in self.all_emotes.items():
                                if v["id"] == emote_id and not k.isdigit():
                                    actual_name = k
                                    break
                                    
                        try:
                            self.is_looping = False
                            self.persistent_bot_emote = emote_id
                            self.save_config()
                            self.user_loops[self.my_id] = emote_id
                            asyncio.create_task(self.run_user_emote_loop(self.my_id, emote_id, duration))
                            await self.highrise.send_whisper(user.id, f"Bot is now looping {actual_name}.")
                        except Exception as e:
                            print(f"Error starting emote: {e}")
                    else:
                        await self.highrise.send_whisper(user.id, f"Emote '{emote_input}' not found. Use -emotelist to view emotes.")
                    return

            elif message.lower() == "-emotelist":
                try:
                    if not self.all_emotes:
                        await self.highrise.send_whisper(user.id, "No emotes found. Reloading...")
                        self.load_all_emotes_json()
                    
                    if not self.all_emotes:
                        await self.highrise.send_whisper(user.id, "Critical Error: Emote data missing.")
                        return

                    emote_items = []
                    # Dynamically collect all numeric emotes from the JSON
                    numeric_keys = sorted([int(k) for k in self.all_emotes.keys() if k.isdigit()])
                    for i in numeric_keys:
                        str_i = str(i)
                        if str_i in self.all_emotes:
                            e_id = self.all_emotes[str_i]["id"]
                            # Find the best name (non-numeric)
                            name = "Unknown"
                            for k, v in self.all_emotes.items():
                                if v["id"] == e_id and not k.isdigit():
                                    name = k
                                    break
                            emote_items.append(f"{i}. {name}")
                    
                    if not emote_items:
                        await self.highrise.send_whisper(user.id, "List is empty!")
                        return

                    # Split into batches of 45 to keep messages small and sequential
                    batch_size = 45
                    total_parts = (len(emote_items) + batch_size - 1) // batch_size
                    


                    for part_idx in range(total_parts):
                        start = part_idx * batch_size
                        end = start + batch_size
                        batch = emote_items[start:end]
                        
                        part_num = part_idx + 1
                        msg = f"💎 **EMOTE LIST [PART {part_num}/{total_parts}]** 💎\n"
                        msg += "\n".join(batch)
                        
                        try:
                            await self.highrise.send_message_bulk([user.id], msg)
                            await asyncio.sleep(1.2) # Solid delay to ensure order
                        except Exception as e:
                            print(f"Error sending batch {part_num}: {e}")
                            await asyncio.sleep(2) # Extra wait on error
                    

                except Exception as e:
                    print(f"Error in -emotelist: {e}")
                    await self.highrise.send_whisper(user.id, f"❌ Error: {type(e).__name__}")
                return

            # ── ADD EMOTE (Owner) ─────────────────────────────────────────
            elif msg_lower.startswith("-addemote "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only owners can use -addemote.")
                    return
                ae_parts = message.split()
                if len(ae_parts) < 4:
                    await self.highrise.send_whisper(user.id, "Usage: -addemote (url) (emote_name) (duration)")
                    return
                ae_url = ae_parts[1]
                ae_name = ae_parts[2].lower()
                try:
                    ae_dur = float(ae_parts[3])
                    if ae_dur <= 0:
                        raise ValueError
                except ValueError:
                    await self.highrise.send_whisper(user.id, "❌ Duration must be a positive number (e.g. 5.5)")
                    return
                if ae_name in self.all_emotes:
                    await self.highrise.send_whisper(user.id, f"❌ The name '{ae_name}' is already in use!")
                    return
                try:
                    ae_parsed = urllib.parse.urlparse(ae_url)
                    ae_qs = urllib.parse.parse_qs(ae_parsed.query)
                    ae_id = ae_qs.get("id", [None])[0]
                except Exception:
                    ae_id = None
                if not ae_id:
                    await self.highrise.send_whisper(user.id, "❌ Could not find item ID in the URL.")
                    return
                try:
                    ae_numeric_keys = [int(k) for k in self.all_emotes.keys() if k.isdigit()]
                    ae_new_num = str(max(ae_numeric_keys) + 1) if ae_numeric_keys else "1"
                    ae_entry = {"id": ae_id, "duration": ae_dur, "is_free": True}
                    self.all_emotes[ae_name] = dict(ae_entry)
                    self.all_emotes[ae_new_num] = dict(ae_entry)
                    with open("emote_list_backup.json", "w", encoding="utf-8") as wf:
                        json.dump(self.all_emotes, wf, indent=4, ensure_ascii=False)
                    await self.highrise.send_whisper(user.id, f"✅ Emote added! Name: {ae_name}, Number: {ae_new_num}, ID: {ae_id}")
                except Exception as ae_ex:
                    await self.highrise.send_whisper(user.id, f"❌ Failed to save emote: {ae_ex}")
                return

            # ── EDIT EMOTE DURATION (Owner) ───────────────────────────────
            elif msg_lower.startswith("-editemote "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only owners can edit emote durations.")
                    return
                ee_parts = message.split()
                if len(ee_parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -editemote emotename/number duration\nExample: -editemote ghost 4.5")
                    return
                ee_dur_str = ee_parts[-1]
                ee_lookup = " ".join(ee_parts[1:-1]).lower()
                if ee_lookup not in self.all_emotes:
                    await self.highrise.send_whisper(user.id, f"❌ Emote '{ee_lookup}' not found.")
                    return
                try:
                    ee_dur = float(ee_dur_str)
                    if ee_dur <= 0:
                        raise ValueError
                except ValueError:
                    await self.highrise.send_whisper(user.id, "❌ Duration must be a positive number.")
                    return
                ee_id = self.all_emotes[ee_lookup]["id"]
                try:
                    for ek, ev in self.all_emotes.items():
                        if isinstance(ev, dict) and ev.get("id") == ee_id:
                            ev["duration"] = ee_dur
                    with open("emote_list_backup.json", "w", encoding="utf-8") as wf:
                        json.dump(self.all_emotes, wf, indent=4, ensure_ascii=False)
                    await self.highrise.send_whisper(user.id, f"✅ Updated duration of '{ee_lookup}' to {ee_dur}s.")
                except Exception as ee_ex:
                    await self.highrise.send_whisper(user.id, f"❌ Error updating emote list: {ee_ex}")
                return

            # ── EDIT EMOTE NAME (Owner) ────────────────────────────────────
            elif msg_lower.startswith("-editemotename "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only owners can edit emote names.")
                    return
                en_parts = message.split()
                if len(en_parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -editemotename oldname/number newname")
                    return
                en_new = en_parts[-1].lower()
                en_old_input = " ".join(en_parts[1:-1]).lower()
                if en_old_input not in self.all_emotes:
                    await self.highrise.send_whisper(user.id, f"❌ Emote '{en_old_input}' not found.")
                    return
                if en_new in self.all_emotes:
                    await self.highrise.send_whisper(user.id, f"❌ The name '{en_new}' is already in use!")
                    return
                en_id = self.all_emotes[en_old_input]["id"]
                # Resolve to the actual name key (non-numeric) so a number key stays untouched
                en_old = next((k for k, v in self.all_emotes.items() if isinstance(v, dict) and v.get("id") == en_id and not k.isdigit()), en_old_input)
                try:
                    en_data = self.all_emotes.pop(en_old)
                    self.all_emotes[en_new] = en_data
                    with open("emote_list_backup.json", "w", encoding="utf-8") as wf:
                        json.dump(self.all_emotes, wf, indent=4, ensure_ascii=False)
                    await self.highrise.send_whisper(user.id, f"✅ Renamed '{en_old}' to '{en_new}'.")
                except Exception as en_ex:
                    await self.highrise.send_whisper(user.id, f"❌ Error updating emote list: {en_ex}")
                return

            # ── SHOW EMOTE DURATION (Owner) ────────────────────────────────
            elif msg_lower.startswith("-duration "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "❌ Only owners can use -duration.")
                    return
                du_lookup = message[len("-duration "):].strip().lower()
                if du_lookup not in self.all_emotes:
                    await self.highrise.send_whisper(user.id, f"❌ Emote '{du_lookup}' not found.")
                    return
                du_data = self.all_emotes[du_lookup]
                du_id = du_data.get("id")
                du_dur = du_data.get("duration", 5.0)
                du_number = next((k for k, v in self.all_emotes.items() if isinstance(v, dict) and v.get("id") == du_id and k.isdigit()), "N/A")
                du_name = next((k for k, v in self.all_emotes.items() if isinstance(v, dict) and v.get("id") == du_id and not k.isdigit()), du_lookup)
                await self.highrise.send_whisper(user.id, f"⏱️ Emote: {du_name}\nNumber: {du_number}\nID: {du_id}\nDuration: {du_dur}s")
                return

            # Check if command
            if not message.startswith("-"):
                return

            # Check global lock (only owner can use commands if locked)
            if self.is_locked and not self.is_owner(user.username):
                # Don't even respond to non-owners if bot is locked
                return

            # Check subscription for all other commands
            # BUT: owners and mods should be allowed by default.
            if not is_staff and not self.is_subscribed(user.username) and not message.lower().startswith(("-sub", "-unsub", "-setpose", "-setspawn", "-setjoin", "-promo", "-clearpromo", "-botroom", "-roomid")):
                await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, you need to be subscribed to use this command. Ask the owner for access!")
                return

            # Set bot position (Owner only)
            elif message.lower() == "-bot":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                
                # Get the user's position
                room_users = await self.highrise.get_room_users()
                user_pos = None
                for room_user, pos in room_users.content:
                    if room_user.id == user.id:
                        user_pos = pos
                        break
                
                if user_pos:
                    # Save the position
                    self.config["SAVED_POSITION"] = {
                        "x": user_pos.x,
                        "y": user_pos.y,
                        "z": user_pos.z,
                        "facing": user_pos.facing
                    }
                    self.saved_pos = self.config["SAVED_POSITION"]
                    self.save_config()
                    
                    # Move the bot
                    await self.highrise.teleport(self.my_id, user_pos)
                    await self.highrise.send_whisper(user.id, f"Position saved! I'll now stay here permanently.")
                    print(f"Bot position updated and saved by {user.username}: {user_pos}")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            # Move bot back to its saved position right now (Owner/Mod)
            elif message.lower() == "-back":
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owners and moderators can use this command.")
                    return
                if not self.saved_pos:
                    await self.highrise.send_whisper(user.id, "No saved position found yet. Use -bot first to set one.")
                    return
                try:
                    pos = Position(
                        x=self.saved_pos['x'],
                        y=self.saved_pos['y'],
                        z=self.saved_pos['z'],
                        facing=self.saved_pos.get('facing', 'FrontRight')
                    )
                    await self.highrise.teleport(self.my_id, pos)
                    await self.highrise.send_whisper(user.id, "Back to my spot! 📍")
                    print(f"Bot moved back to saved position by {user.username}")
                except Exception as e:
                    print(f"Error in -back: {e}")
                    await self.highrise.send_whisper(user.id, "Failed to move back.")
            
            # Set spawn position (Owner only)
            elif message.lower() == "-setspawn":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                
                # Get the user's position
                room_users = await self.highrise.get_room_users()
                user_pos = None
                for room_user, pos in room_users.content:
                    if room_user.id == user.id:
                        user_pos = pos
                        print(f"[DEBUG] Found user {user.username} in room, position type: {type(pos)}, value: {pos}")
                        break
                
                if user_pos:
                    print(f"[DEBUG] Setting spawn position using user's position: {user_pos}")
                    # Save the spawn position
                    self.config["SPAWN_POSITION"] = {
                        "x": user_pos.x,
                        "y": user_pos.y,
                        "z": user_pos.z,
                        "facing": user_pos.facing
                    }
                    self.spawn_pos = self.config["SPAWN_POSITION"]
                    print(f"[DEBUG] Spawn config saved as: {self.spawn_pos}")
                    self.save_config()
                    print(f"Spawn position updated and saved by {user.username}: {user_pos}")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            # Set custom welcome message (Owner only)
            elif msg_lower.startswith("-setwelcome"):
                if not (self.is_owner(user.username) or self.is_mod(user.username) or self.is_vip(user.username)):
                    await self.highrise.send_whisper(user.id, "Only VIPs, Moderators, and Owners can use -setwelcome.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    if hasattr(self, "personal_welcomes") and user.id in self.personal_welcomes:
                        del self.personal_welcomes[user.id]
                        self.save_config()
                        await self.highrise.send_whisper(user.id, "✅ Your personal welcome message has been cleared!")
                    else:
                        await self.highrise.send_whisper(user.id, "Usage: -setwelcome <message> (Use 'clear' to remove)")
                    return
                
                cmd_len = len(parts[0])
                welcome_msg_content = message[cmd_len:].strip()
                
                if welcome_msg_content.lower() in ["clear", "default", "none", "reset"]:
                    if hasattr(self, "personal_welcomes") and user.id in self.personal_welcomes:
                        del self.personal_welcomes[user.id]
                        self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Your personal welcome message has been cleared!")
                    return
                
                if not hasattr(self, "personal_welcomes"):
                    self.personal_welcomes = {}
                self.personal_welcomes[user.id] = welcome_msg_content
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Your personal welcome message set to:\n{welcome_msg_content}")
                return

            elif msg_lower.startswith("-setjoin"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    self.custom_welcome_message = None
                    if "CUSTOM_WELCOME_MESSAGE" in self.config:
                        del self.config["CUSTOM_WELCOME_MESSAGE"]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Custom welcome message cleared! Resetted to default messages.")
                    return
                
                # Get the message content preserving original case
                cmd_len = len(parts[0])
                welcome_msg_content = message[cmd_len:].strip()
                
                if welcome_msg_content.lower() in ["clear", "default", "none", "reset"]:
                    self.custom_welcome_message = None
                    if "CUSTOM_WELCOME_MESSAGE" in self.config:
                        del self.config["CUSTOM_WELCOME_MESSAGE"]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Custom welcome message cleared! Resetted to default messages.")
                    return
                
                self.custom_welcome_message = welcome_msg_content
                self.config["CUSTOM_WELCOME_MESSAGE"] = self.custom_welcome_message
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Custom welcome message set to:\n{self.custom_welcome_message}")
                return

            elif msg_lower.startswith("-setleave"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    self.custom_goodbye_message = None
                    if "CUSTOM_GOODBYE_MESSAGE" in self.config:
                        del self.config["CUSTOM_GOODBYE_MESSAGE"]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Custom goodbye message cleared! Resetted to default messages.")
                    return
                
                # Get the message content preserving original case
                cmd_len = len(parts[0])
                goodbye_msg_content = message[cmd_len:].strip()
                
                if goodbye_msg_content.lower() in ["clear", "default", "none", "reset"]:
                    self.custom_goodbye_message = None
                    if "CUSTOM_GOODBYE_MESSAGE" in self.config:
                        del self.config["CUSTOM_GOODBYE_MESSAGE"]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Custom goodbye message cleared! Resetted to default messages.")
                    return
                
                self.custom_goodbye_message = goodbye_msg_content
                self.config["CUSTOM_GOODBYE_MESSAGE"] = self.custom_goodbye_message
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Custom goodbye message set to:\n{self.custom_goodbye_message}")
                return



            # Promo Loop / Advertisement Message (Owner only)
            elif msg_lower.startswith("-promo"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                
                parts = message.split()
                # Clear checking
                if len(parts) == 3 and (parts[1].lower() in ["clear", "stop"] or parts[2].lower() in ["clear", "stop"]):
                    promo_id = parts[2] if parts[1].lower() in ["clear", "stop"] else parts[1]
                    if promo_id in self.promos:
                        self.stop_promo_loop(promo_id)
                        del self.promos[promo_id]
                        if "PROMOS" in self.config and promo_id in self.config["PROMOS"]:
                            del self.config["PROMOS"][promo_id]
                        self.save_config()
                        await self.highrise.send_whisper(user.id, f"✅ Advertisement promo loop '{promo_id}' has been cleared.")
                    else:
                        await self.highrise.send_whisper(user.id, f"❌ Promo '{promo_id}' is not currently running.")
                    return

                if len(parts) < 4:
                    await self.highrise.send_whisper(user.id, "💡 Usage: -promo (number) (message) (seconds)\n👉 Example: -promo 1 Hello World! 20")
                    return
                
                promo_id = parts[1]
                
                # Check if last word is a duration unit like "second", "seconds", "s"
                last_part = parts[-1].lower()
                second_part = None
                message_end_idx = -1
                
                if last_part.rstrip('s').isdigit():
                    # e.g., "20s" or "20"
                    second_part = last_part.rstrip('s')
                    message_end_idx = -1
                elif last_part in ["second", "seconds"] and len(parts) >= 5:
                    # e.g., "20 seconds"
                    second_part = parts[-2]
                    message_end_idx = -2
                else:
                    # Let's try parsing the last part as number by removing any non-digits (like "20sec")
                    clean_last = ''.join(c for c in last_part if c.isdigit())
                    if clean_last:
                        second_part = clean_last
                        message_end_idx = -1
                
                if not second_part or not second_part.isdigit():
                    await self.highrise.send_whisper(user.id, "❌ Error: Could not determine the seconds interval. Please end the command with the seconds as a number.")
                    return
                
                interval = int(second_part)
                # Enforce a minimum interval of 5 seconds to prevent rate limiting or room spam
                if interval < 5:
                    await self.highrise.send_whisper(user.id, "⚠️ Warning: Minimum interval is 5 seconds to prevent spam.")
                    interval = 5
                
                # Reconstruct the message preserving original case
                # Find start index in original message
                start_search = message.lower().find(parts[1].lower()) + len(parts[1])
                raw_promo_message = message[start_search:].strip()
                
                # Remove the seconds part from the end of raw_promo_message
                words_in_msg = raw_promo_message.split()
                if message_end_idx == -1:
                    promo_text = " ".join(words_in_msg[:-1])
                else:
                    promo_text = " ".join(words_in_msg[:-2])
                
                if not promo_text:
                    await self.highrise.send_whisper(user.id, "❌ Error: Advertisement message cannot be empty.")
                    return
                
                # Save and start the loop
                self.promos[promo_id] = {
                    "message": promo_text,
                    "seconds": interval
                }
                self.config["PROMOS"] = self.promos
                self.save_config()
                
                self.start_promo_loop(promo_id, promo_text, interval)
                await self.highrise.send_whisper(user.id, f"✅ Promo loop '{promo_id}' successfully set up and started!\n🔊 Message: {promo_text}\n⏱️ Interval: {interval} seconds")
                return

            # Clear Promo Loop (Owner only)
            elif msg_lower.startswith("-clearpromo"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use this command.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -clearpromo (number) or -clearpromo all")
                    return
                
                promo_id = parts[1].strip()
                if promo_id.lower() == "all":
                    if not self.promos:
                        await self.highrise.send_whisper(user.id, "No active promo loops to clear.")
                        return
                    count = len(self.promos)
                    for pid in list(self.promos.keys()):
                        self.stop_promo_loop(pid)
                    self.promos.clear()
                    self.config["PROMOS"] = {}
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"✅ Cleared and stopped all {count} promo loops successfully.")
                    return
                
                if promo_id in self.promos:
                    self.stop_promo_loop(promo_id)
                    del self.promos[promo_id]
                    if "PROMOS" in self.config and promo_id in self.config["PROMOS"]:
                        del self.config["PROMOS"][promo_id]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"✅ Advertisement promo loop '{promo_id}' has been cleared and stopped.")
                else:
                    await self.highrise.send_whisper(user.id, f"❌ Promo '{promo_id}' is not currently running.")
                return

            # Unsubscribe a user / Global Lock
            elif message.lower().startswith("-unsub"):
                parts = message.split()
                if len(parts) < 2:
                    # Self unsubscribe AND Global Lock
                    # Removed global lock logic

                    
                    if user.username.lower() in [s.lower() for s in self.subscribers]:
                        self.subscribers = [s for s in self.subscribers if s.lower() != user.username.lower()]
                        self.save_config()
                        await self.highrise.send_whisper(user.id, f"Hey @{user.username} ❌ You are now unsubscribed.If you want to join again anytime, just type -sub")
                    return

                # Target unsubscribe (Everyone can now use this)
                target_username = parts[1].replace("@", "")
                if target_username.lower() in [s.lower() for s in self.subscribers]:
                    self.subscribers = [s for s in self.subscribers if s.lower() != target_username.lower()]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"Hey @{target_username} ❌ You are now unsubscribed.If you want to join again anytime, just type -sub")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is not subscribed.")

            # Subscribe a user / Global Unlock
            elif message.lower().startswith("-sub"):
                # Everyone can now use -sub to unlock or subscribe users
                # Removed global unlock logic


                parts = message.split()
                if len(parts) < 2:
                    target_user = user
                else:
                    target_username = parts[1].replace("@", "")
                    # Try to find the user in the room
                    room_users = await self.highrise.get_room_users()
                    target_user = None
                    for room_user, pos in room_users.content:
                        if room_user.username.lower() == target_username.lower():
                            target_user = room_user
                            break
                    
                    if not target_user:
                        await self.highrise.send_whisper(user.id, f"User {target_username} not found in the room.")
                        return

                if target_user.username.lower() not in [s.lower() for s in self.subscribers]:
                    self.subscribers.append(target_user.username)
                    self.save_config()
                    


                    await self.highrise.send_whisper(user.id, f"Hey @{target_user.username} 👋 Welcome back! You are now subscribed ✅ Stay tuned for updates 🎶🔥")
                    
                    # Send DM to the user
                    try:
                        # Use send_message_bulk to send a direct message
                        # This works in v24.1.0+ and creates a conversation if needed
                        await self.highrise.send_message_bulk([target_user.id], f"Hello @{target_user.username}! You have been successfully subscribed to the Bot. All commands are now unlocked for you! Enjoy!")
                        print(f"DM sent to {target_user.username}")
                    except Exception as e:
                        print(f"Error sending DM to {target_user.username}: {e}")
                        # Fallback: whisper if DM fails
                        try:
                            await self.highrise.send_whisper(target_user.id, f"Hello @{target_user.username}! You have been successfully subscribed to the MusicBot. All commands are now unlocked for you! Enjoy!")
                        except:
                            pass
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_user.username} is already subscribed.")

            # New Advanced Room Invite Handler
            elif msg_lower.startswith("-invite"):
                if await self.is_mod_or_owner(user.id, user.username):
                    parts = message.split()
                    
                    # Check for mentioned users
                    mentioned_users = [w[1:] for w in parts if w.startswith("@")]
                    
                    # Construct message (remove command and mentions)
                    msg_words = [w for w in parts[1:] if not w.startswith("@")]
                    invite_msg = " ".join(msg_words)
                    
                    if mentioned_users:
                        # Targeted Invite
                        await self.highrise.send_whisper(user.id, f"🔍 Resolving {len(mentioned_users)} users...")
                        target_ids = []
                        
                        # Resolve Usernames to IDs
                        for u_name in mentioned_users:
                            try:
                                # Try to find in room first (faster)
                                room_results = await self.highrise.get_room_users()
                                found = False
                                for ru, _ in room_results.content:
                                    if ru.username.lower() == u_name.lower():
                                        target_ids.append(ru.id)
                                        found = True
                                        break
                                
                                if not found:
                                    # Fallback to our ultra-robust WebAPI lookup
                                    uid = await self.get_user_id_webapi(u_name)
                                    if uid:
                                        target_ids.append(uid)
                                    else:
                                        print(f"User {u_name} not found.")
                            except Exception as e:
                                print(f"Error resolving {u_name}: {e}")
                        
                        if target_ids:
                            try:
                                # Send Text Message First (if provided)
                                if invite_msg:
                                    await self.highrise.send_message_bulk(target_ids, invite_msg)
                                    await asyncio.sleep(0.5)
                                
                                # Send Invite Card
                                # Signature: send_message_bulk(user_ids, content, message_type, room_id)
                                await self.highrise.send_message_bulk(target_ids, "Join our room!", "invite", self.room_id)
                                await self.highrise.send_whisper(user.id, f"✅ Created invites for {len(target_ids)} users!")
                            except Exception as e:
                                await self.highrise.send_whisper(user.id, f"❌ Error sending bulk invites: {e}")
                        else:
                            await self.highrise.send_whisper(user.id, "❌ No valid users found to invite.")
                        
                    else:
                        # Mass Invite (All Recent Conversations)
                        custom_msg = message[len("-invite"):].strip()
                        await self.highrise.send_whisper(user.id, "📨 Sending invites to all recent conversations...")
                        
                        try:
                            # Use SDK native get_conversations
                            conversations_resp = await self.highrise.get_conversations()
                            if isinstance(conversations_resp, Error):
                                await self.highrise.send_whisper(user.id, f"❌ Failed to fetch conversations: {conversations_resp.message}")
                                return
                                
                            conversations = conversations_resp.conversations
                            
                            inv_pool = [
                                "<#FFD700>Welcome to the VIP zone where the bass never stops. 🎧\n<#00FFFF>Let the rhythm take control and enjoy the elite vibes! ✨",
                                "<#FF4500>Turn up the volume and leave your worries at the door. 🎸\n<#FF69B4>This is where the best memories and loudest tracks live. 🌟",
                                "<#00FF00>Only premium beats and happy faces allowed in this space. 🎹\n<#FFD700>Grab a seat, stay a while, and feel the musical magic. 🌈",
                                "<#FF00FF>High energy and VIP treatment are our top priorities here. 🎤\n<#00FFFF>Let’s make this night legendary with the perfect playlist. 🔥",
                                "<#8A2BE2>Feel the pulse of the music deep inside your soul tonight. 🎷\n<#FF69B4>You’re in the best company with the ultimate VIP crew. 🥂",
                                "<#00FFFF>Good vibes only and the music is always playing loud. 🎻\n<#FFD700>Stay happy, stay hydrated, and keep the party going! 🌊",
                                "<#FFD700>Welcome to the inner circle where the melody meets luxury. 💎\n<#00FF00>Sit back and relax while the DJ spins your favorite hits. 💿",
                                "<#FF4500>Life is better when the beat drops and the room glows. 💡\n<#FF00FF>Enjoy your stay in the most exclusive hangout in town. 🏆",
                                "<#00FF00>Nothing but smiles and high-quality tunes in this room. 🎺\n<#8A2BE2>Let the harmony lift your spirits to a whole new level. 🚀",
                                "<#FF69B4>You’ve officially entered the VIP lounge of pure happiness. 🥂\n<#00FFFF>Every note is a celebration, so let’s dance the night away! 💃",
                                "<#FF4500>The playlist is fire and the company is even better. 🔥\n<#FFD700>Enjoy the VIP experience with every single heartbeat today. 💓",
                                "<#00FFFF>We play the music that makes your heart skip a beat. 🎶\n<#FF69B4>Welcome to your happy place where everyone is a star. ⭐",
                                "<#00FF00>Luxury is a feeling, and today it sounds like your song. 🎵\n<#FFD700>Stay VIP and let the good times roll endlessly for us. 🎡",
                                "<#FF00FF>Keep the energy high and the music even higher right now. 🔊\n<#00FFFF>This hangout is designed for those who love the elite life. 🎩",
                                "<#8A2BE2>Music is the language of the soul, and we speak it fluently. 🗣️\n<#FF69B4>Welcome to a room filled with joy and premium melodies. 🎼",
                                "<#00FFFF>Step into the spotlight and let the rhythm guide your way. 🔦\n<#FFD700>A VIP stay isn't complete without some world-class music. 🌍",
                                "<#FFD700>Your daily dose of happiness starts with this heavy bass. 🥁\n<#00FF00>Make yourself at home in our exclusive musical sanctuary. 🏰",
                                "<#FF4500>Every track is a masterpiece and every guest is a VIP. 🎨\n<#FF00FF>Let’s create a vibe that stays with us forever tonight. 🌌",
                                "<#00FF00>Relax, recharge, and revel in the sound of pure perfection. 🧘\n<#8A2BE2>This room is your ticket to a happy, musical escape. 🎫",
                                "<#FF69B4>Let the lyrics inspire you and the beat keep you moving. 💃\n<#00FFFF>Welcome to the most stylish hangout room on the map. 📍",
                                "<#FFD700>VIP access granted to the land of endless musical joy. 🗝️\n<#00FFFF>Turn the world off and turn the music all the way up. ⚡",
                                "<#FF4500>We don’t just play music; we create a VIP atmosphere. ☁️\n<#FF69B4>Stay happy and let the chords heal your spirit today. 🩹",
                                "<#00FF00>Bold beats for bold people in this exclusive hangout. 🦁\n<#FFD700>Enjoy the luxury of great sound and even better vibes. 🥂",
                                "<#FF00FF>Escape the ordinary and dive into a world of harmony. 🏊\n<#00FFFF>Your VIP stay is guaranteed to be full of musical surprises. 🎁",
                                "<#8A2BE2>Catch the wave of the melody and ride it to happiness. 🌊\n<#FF69B4>There’s no place like this room for a true music lover. 🎧",
                                "<#00FFFF>Shine bright like a diamond while the record keeps spinning. 💎\n<#FFD700>This is the VIP hangout where joy is the only rule. 📏",
                                "<#FFD700>Music sounds better when you're feeling like a total boss. 🕶️\n<#00FF00>Stay in the loop of happiness and high-end entertainment. ➰",
                                "<#FF4500>The ultimate soundtrack for your VIP lifestyle starts here. 🎹\n<#FF00FF>Let’s turn these moments into a symphony of great memories. 🎻",
                                "<#00FF00>Cheers to great tunes and even greater friends in this room. 🍻\n<#8A2BE2>May your stay be filled with rhythm and sparkling energy. ✨",
                                "<#FF69B4>A VIP experience means the music never gets boring. 🔄\n<#00FFFF>Keep smiling and keep vibing to the best tracks ever. 🍭",
                                "<#FF4500>Feel the magic in the air and the bass in the floor. 🪄\n<#FFD700>This is your VIP pass to a world of pure musical bliss. 🎟️",
                                "<#00FFFF>Happiness is a loud song and a room full of VIPs. 😊\n<#FF69B4>Enjoy every second of this top-tier hangout experience. 🥇",
                                "<#00FF00>Your presence is premium, and our music is top-shelf. 🍾\n<#FFD700>Let the melodies flow and the happy vibes grow stronger. 🌱",
                                "<#FF00FF>No stress allowed—only high-quality music and elite stays. 🚫\n<#00FFFF>Welcome to the VIP corner where life sounds beautiful. 🌈",
                                "<#8A2BE2>Tune in to the frequency of joy and stay for the rhythm. 📻\n<#FF69B4>We make sure every guest feels like the star of the show. 🌠",
                                "<#00FFFF>From jazz to pop, we have the VIP vibe you truly crave. 🎷\n<#FFD700>Stay happy and let the music be your best companion. 🤝",
                                "<#FFD700>The floor is yours and the playlist is absolutely legendary. 🕺\n<#00FF00>Make your VIP stay the highlight of your entire week. 🗓️",
                                "<#FF4500>Music is the heartbeat of this room, and you are the soul. ❤️\n<#FF00FF>Enjoy a happy, rhythmic hangout filled with luxury and loud beats. 🔊",
                                "<#00FF00>Surround yourself with elite sounds and positive energy. 🌀\n<#8A2BE2>This VIP room is your destination for musical perfection. 🏁",
                                "<#FF69B4>Let’s celebrate the good life with a melody that shines. 🥂\n<#00FFFF>You deserve a VIP stay that sounds as good as it looks. 📸",
                                "<#FF4500>Put your hands up for the VIP music experience of a lifetime. 🙌\n<#FFD700>Happiness is just a beat away in this exclusive hangout. 🎵",
                                "<#00FFFF>Experience the luxury of sound in our private VIP suite. 🛋️\n<#FF69B4>Keep the smile wide and the volume even wider today. 📢",
                                "<#00FF00>We take music seriously, but we take happiness even more. 😄\n<#FFD700>Welcome to a VIP stay that hits all the right notes. 🎼",
                                "<#FF00FF>Let the bass rumble and the good times crumble the walls. 🧱\n<#00FFFF>Stay VIP and enjoy the most rhythmic room in existence. 🎸",
                                "<#8A2BE2>Your happy place is now upgraded to VIP status officially. 🆙\n<#FF69B4>Relax into the music and let the vibes take the lead. 🧭",
                                "<#00FFFF>Golden tunes for our golden guests in this special room. 🟡\n<#FFD700>May your VIP stay be as bright as the loudest chorus. 🔆",
                                "<#FFD700>Music brings us together, but the VIP vibe keeps us here. 🔗\n<#00FF00>Enjoy a happy, rhythmic journey with every single track. 🛣️",
                                "<#FF4500>Elevate your mood with our handpicked VIP playlist today. 🎈\n<#FF00FF>This hangout is all about luxury, music, and pure fun. 🎢",
                                "<#00FF00>Dive into the deep end of the beat and feel the VIP chill. ❄️\n<#8A2BE2>Happiness is contagious when the music is this good. 🎤",
                                "<#FF69B4>The final track hasn't played yet, so keep the VIP party alive. 🕯️\n<#00FFFF>Stay happy, stay musical, and enjoy this elite hangout 🍹",
                                "<#FFD700>Let’s trade the coffee for some cold cocktails tonight. 🍸\n<#00FFFF>The first round is on me, so no excuses! 🥂",
                                "<#FF4500>Time to turn the music up and the stress levels down. 🎶\n<#FF69B4>Meet me at the club at 10:00 PM sharp! 💃",
                                "<#00FF00>My glass is empty and that feels like a personal insult. 🍺\n<#FFD700>Let’s hit our favorite bar and fix this immediately. 🍻",
                                "<#FF00FF>Work was long, but the happy hour deals are longer. 🍹\n<#00FFFF>See you at the spot in twenty minutes? 🥂",
                                "<#8A2BE2>Putting on my dancing shoes and heading to the floor. 👟\n<#FF69B4>Come join the chaos and let’s grab a drink! 🕺",
                                "<#00FFFF>The weekend officially starts the moment we clink glasses. 🍷\n<#FFD700>I’m already at the bar waiting for your arrival. 📍",
                                "<#FFD700>Why stay in when the bass is bumping and the drinks are cold? 🔊\n<#00FF00>Let’s go lose ourselves on the dance floor tonight! ✨",
                                "<#FF4500>I’ve got a thirst that only a cold pint can quench. 🍺\n<#FF00FF>Meet me at the pub for a few rounds of therapy. 🎯",
                                "<#00FF00>Life is too short to skip a Saturday night at the club. 🌃\n<#8A2BE2>Get dressed, get ready, and let’s go wild! 🍾",
                                "<#FF69B4>Tequila might not be the answer, but it’s worth a shot. 🥃\n<#00FFFF>See you at the bar for some questionable decisions! 🍋",
                                "<#FF4500>Ready to trade reality for some strobe lights and spirits? 🌈\n<#FFD700>The club is calling our names, let’s answer. 📱",
                                "<#00FFFF>It’s been a week, and I need a drink with your name on it. 🍸\n<#FF69B4>Let's catch up over something shaken and stirred. 🌪️",
                                "<#00FF00>The dance floor is empty and that’s a tragedy we must fix. 💃\n<#FFD700>Grab your jacket, we’re heading to the club now. 🚕",
                                "<#FF00FF>Beer is proof that the universe wants us to be happy. 🍺\n<#00FFFF>Let’s go find some happiness at the local pub. 😊",
                                "<#8A2BE2>Too much work and not enough play makes for a boring Friday. 👔\n<#FF69B4>Let’s go grab a drink and forget about the office! 🍹",
                                "<#00FFFF>I heard the DJ is playing your favorite set tonight. 🎧\n<#FFD700>Let’s hit the club and dance until our feet hurt! 🕺",
                                "<#FFD700>Happy hour is the best hour of the entire day. 🕒\n<#00FF00>Meet me for half-off drinks and full-on fun! 🍻",
                                "<#FF4500>Tonight’s forecast: 100% chance of cocktails and dancing. 🍹\n<#FF00FF>Don’t be the only one missing out on the fun! ⛈️",
                                "<#00FF00>Let’s go find a dark corner and some bright drinks. 🍷\n<#8A2BE2>The bar is open and the vibes are just right. 🌙",
                                "<#FF69B4>I’m craving a cold one and a good conversation. 🍺\n<#00FFFF>Are you free to hit the bar for a bit? 🗣️",
                                "<#FF4500>The club is going to be packed, but we’re on the list. 📝\n<#FFD700>Let’s go make an entrance and grab a bottle! 🍾",
                                "<#00FFFF>A little bit of dancing never hurt anybody, right? 💃\n<#FF69B4>See you at the entrance at midnight! 🕛",
                                "<#00FF00>I’ve got the spirit, now I just need the spirits. 🍸\n<#FFD700>Let’s go get fancy at that new cocktail lounge. 🛋️",
                                "<#FF00FF>Forget the gym, dancing at the club is my cardio. 🏃‍♂️\n<#00FFFF>Come burn some calories with me on the floor! 🎶",
                                "<#8A2BE2>The pub is warm, the beer is cold, and the night is young. 🍺\n<#FF69B4>What are you waiting for? Get over here! 🏃‍♀️",
                                "<#00FFFF>Let’s celebrate the fact that it’s finally the weekend. 🥂\n<#FFD700>The first bottle of champagne is already on ice. ❄️",
                                "<#FFD700>Who needs sleep when you have house music and gin? 🍸\n<#00FF00>Let’s stay out until the sun comes up. 🌅",
                                "<#FF4500>Let’s go grab a stool and watch the game with a pint. 🏀\n<#FF00FF>The bar is calling and I think it’s for you. 📞",
                                "<#00FF00>Dressing up just to get down on the dance floor. 👗\n<#8A2BE2>Meet me at the club for a night to remember! 👠",
                                "<#FF69B4>I’m in desperate need of a margarita and your company. 🍹\n<#00FFFF>Let’s meet at our usual spot in an hour. 🧂",
                                "<#FF4500>Let’s turn this 'hangout' into a 'night out.' 🍺\n<#FFD700>The bar is buzzing and we should be there. 🐝",
                                "<#00FFFF>Rumor has it the drinks are strong and the music is loud. 🔊\n<#FF69B4>Sounds like the perfect night to me! 🥃",
                                "<#00FF00>Let’s go make some memories we might forget tomorrow. 🍾\n<#FFD700>The club is waiting, let’s go get wild! 🌀",
                                "<#FF00FF>No plans are the best plans, especially at a bar. 🍺\n<#00FFFF>Come join me for a casual drink and some laughs. 😂",
                                "<#8A2BE2>I’m already at the club and the vibe is immaculate. ✨\n<#FF69B4>Hurry up and get here before the line gets long! 🏃",
                                "<#00FFFF>Cheers to friendship and very cold vodka sodas. 🥂\n<#FFD700>Let’s meet up and toast to the good times. 🍋",
                                "<#FFD700>A bad day can always be fixed by a good bartender. 🍸\n<#00FF00>Let’s go find one and tell them our troubles. 🛋️",
                                "<#FF4500>Saturday nights were made for strobe lights and bass. 🌃\n<#FF00FF>See you at the club for the main set! 🎧",
                                "<#00FF00>I’m buying the first round, you buy the second. 🍻\n<#8A2BE2>That’s the deal, now get to the bar! 🤝",
                                "<#FF69B4>Let’s go somewhere where the music is louder than our thoughts. 🎶\n<#00FFFF>The club is the only logical destination tonight. 🕺",
                                "<#FF4500>Cold beer and hot wings are calling our names. 🍗\n<#FFD700>Meet me at the sports bar for the kickoff! 🍺",
                                "<#00FFFF>Let’s swap the sweatpants for something club-ready. 👗\n<#FF69B4>I’ll pick you up in twenty for a night out. 🚕",
                                "<#00FF00>Tonic, gin, and a little bit of sin. 🍸\n<#FFD700>Let’s hit the lounge and see where the night goes. 😈",
                                "<#FF00FF>Life is better with a drink in hand and a beat in the air. 🎵\n<#00FFFF>Join me at the bar for a quick recharge. 🔋",
                                "<#8A2BE2>The weekend is slipping away, let’s catch it at the club. 🍾\n<#FF69B4>Last chance to dance before Monday hits! 💃",
                                "<#00FFFF>I need a drink and a dance partner—you’re both. 🕺\n<#FFD700>Meet me at the club for a legendary night. 🌟",
                                "<#FFD700>Low lights and high spirits are the plan for tonight. 🍷\n<#00FF00>See you at the wine bar for a classy evening. 🍷",
                                "<#FF4500>Let’s go get lost in the crowd and the music. 🌊\n<#FF00FF>The club is the perfect place to disappear. 🌫️",
                                "<#00FF00>One drink usually leads to three, and I’m okay with that. 🍺\n<#8A2BE2>Join me at the pub for some 'light' drinking. 🍻",
                                "<#FF69B4>Let’s go toast to nothing in particular at the bar. 🥂\n<#00FFFF>Just show up and I’ll handle the rest! 🎩"
                            ]
                            count = 0
                            for conv in conversations:
                                try:
                                    current_msg = custom_msg if custom_msg else random.choice(inv_pool)
                                    await self.highrise.send_message(conv.id, current_msg)
                                    
                                    # Signature: send_message(conversation_id, content, type, room_id)
                                    await self.highrise.send_message(conv.id, "Join our room!", "invite", self.room_id)
                                    count += 1
                                    await asyncio.sleep(1.2) # Throttled
                                except Exception as e:
                                    print(f"Failed to invite conv {conv.id}: {e}")
                                    
                            await self.highrise.send_whisper(user.id, f"✅ Sent invites to {count} users!")
                            
                        except Exception as e:
                            print(f"Invite loop error: {e}")
                            await self.highrise.send_whisper(user.id, f"❌ Error sending mass invites: {e}")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ You don't have permission to use this command.")
                return


            elif message.lower() == "-sublist":
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only staff can see the subscriber list.")
                    return
                if not self.subscribers:
                    await self.highrise.send_whisper(user.id, "Subscriber list is empty.")
                else:
                    await self.highrise.send_whisper(user.id, f"Current Subscribers ({len(self.subscribers)}): {', '.join(self.subscribers)}")
                return

            # Role management commands
            elif message.lower().startswith("-owner"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can add another owner.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -owner @username")
                    return
                target_username = parts[1].replace("@", "")
                if target_username.lower() not in [o.lower() for o in self.owners]:
                    self.owners.append(target_username)
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is now an owner.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is already an owner.")

            elif message.lower().startswith("-remowner"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can remove an owner.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -remowner @username")
                    return
                target_username = parts[1].replace("@", "")
                if target_username.lower() in [o.lower() for o in getattr(self, "permanent_owners", [])]:
                    await self.highrise.send_whisper(user.id, "Cannot remove a permanent owner.")
                    return
                if target_username.lower() in [o.lower() for o in self.owners]:
                    if len(self.owners) <= 1:
                        await self.highrise.send_whisper(user.id, "Cannot remove the last owner.")
                        return
                    self.owners = [o for o in self.owners if o.lower() != target_username.lower()]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is no longer an owner.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is not an owner.")

            elif message.lower().startswith("-mod"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can add a moderator.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -mod @username")
                    return
                
                target_username = parts[1].replace("@", "")
                if target_username.lower() not in [m.lower() for m in self.mods]:
                    self.mods.append(target_username)
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is now a bot moderator.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is already a bot moderator.")

            elif message.lower() == "-rebot":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the bot owner can use this command.")
                    return
                await self.highrise.chat("🔄 Restarting bot...")

                await asyncio.sleep(1)
                exe_arg = f'"{sys.executable}"' if ' ' in sys.executable else sys.executable
                args = [exe_arg] + [f'"{a}"' if ' ' in a else a for a in sys.argv]
                os.execv(sys.executable, args)

            elif message.lower().startswith("-remmod"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can remove a moderator.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -remmod @username")
                    return
                
                target_username = parts[1].replace("@", "")
                if target_username.lower() in [m.lower() for m in self.mods]:
                    self.mods = [m for m in self.mods if m.lower() != target_username.lower()]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is no longer a bot moderator.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is not a bot moderator.")

            elif message.lower().startswith("-vip"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can add VIPs.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -vip @username")
                    return
                target_username = parts[1].replace("@", "")
                if target_username.lower() not in [v.lower() for v in self.vips]:
                    self.vips.append(target_username)
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is now a VIP.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is already a VIP.")

            elif message.lower().startswith("-remvip"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can remove VIPs.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -remvip @username")
                    return
                target_username = parts[1].replace("@", "")
                if target_username.lower() in [v.lower() for v in self.vips]:
                    self.vips = [v for v in self.vips if v.lower() != target_username.lower()]
                    vip_expirations = getattr(self, "vip_expirations", {})
                    if target_username.lower() in vip_expirations:
                        del vip_expirations[target_username.lower()]
                        self.vip_expirations = vip_expirations
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"@{target_username} is no longer a VIP.")
                else:
                    await self.highrise.send_whisper(user.id, f"@{target_username} is not a VIP.")

            # Teleportation and Location Management
            elif message.lower().startswith("-goto"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can use -goto.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -goto @username")
                    return
                target_username = parts[1].replace("@", "")
                room_users = await self.highrise.get_room_users()
                target_user_pos = next(((u, p) for u, p in room_users.content if u.username.lower() == target_username.lower()), None)
                if target_user_pos and isinstance(target_user_pos[1], Position):
                    await self.highrise.teleport(user.id, target_user_pos[1])
                else:
                    await self.highrise.send_whisper(user.id, f"Could not find @{target_username} or their position.")

            elif message.lower().startswith("-summon"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can use -summon.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -summon @username")
                    return
                target_username = parts[1].replace("@", "")
                room_users = await self.highrise.get_room_users()
                # Find current user's position to summon to
                summoner_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                target_user = next((u for u, p in room_users.content if u.username.lower() == target_username.lower()), None)
                
                if target_user and isinstance(summoner_pos, Position):
                    await self.highrise.teleport(target_user.id, summoner_pos)
                    await self.highrise.send_whisper(user.id, f"Summoned @{target_username} to you.")
                else:
                    await self.highrise.send_whisper(user.id, f"Could not find @{target_username} or your position.")

            elif message.lower().startswith("-create tele"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can create teleport locations.")
                    return
                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -create tele (location name)")
                    return
                loc_name = " ".join(parts[2:]).lower()
                room_users = await self.highrise.get_room_users()
                user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                
                if isinstance(user_pos, Position):
                    self.tele_locations[loc_name] = {
                        "pos": {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z, "facing": user_pos.facing},
                        "vip": False, "mod_only": False, "owner_only": False
                    }
                    self.save_config()
                    await self.highrise.teleport(user.id, user_pos)
                    await self.highrise.send_whisper(user.id, f"Location '{loc_name}' created at your position!")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            elif message.lower().startswith("-createvip tele"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can create VIP locations.")
                    return
                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -createvip tele (location name)")
                    return
                loc_name = " ".join(parts[2:]).lower()
                room_users = await self.highrise.get_room_users()
                user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                
                if isinstance(user_pos, Position):
                    self.tele_locations[loc_name] = {
                        "pos": {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z, "facing": user_pos.facing},
                        "vip": True, "mod_only": False, "owner_only": False
                    }
                    self.save_config()
                    await self.highrise.teleport(user.id, user_pos)
                    await self.highrise.send_whisper(user.id, f"VIP Location '{loc_name}' created at your position!")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            elif message.lower().startswith("-createmod tele"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can create Moderator locations.")
                    return
                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -createmod tele (location name)")
                    return
                loc_name = " ".join(parts[2:]).lower()
                room_users = await self.highrise.get_room_users()
                user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                
                if isinstance(user_pos, Position):
                    self.tele_locations[loc_name] = {
                        "pos": {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z, "facing": user_pos.facing},
                        "vip": False, "mod_only": True, "owner_only": False
                    }
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"Moderator Location '{loc_name}' created at your position!")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            elif message.lower().startswith("-createowner tele"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can create Owner locations.")
                    return
                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -createowner tele (location name)")
                    return
                loc_name = " ".join(parts[2:]).lower()
                room_users = await self.highrise.get_room_users()
                user_pos = next((p for u, p in room_users.content if u.id == user.id), None)
                
                if isinstance(user_pos, Position):
                    self.tele_locations[loc_name] = {
                        "pos": {"x": user_pos.x, "y": user_pos.y, "z": user_pos.z, "facing": user_pos.facing},
                        "vip": False, "mod_only": False, "owner_only": True
                    }
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"Owner Location '{loc_name}' created at your position!")
                else:
                    await self.highrise.send_whisper(user.id, "Could not find your position.")

            elif message.lower().startswith("-tele"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Sorry, only owners and moderators can use -tele to teleport others.")
                    return

                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -tele @username (location name)")
                    return
                target_username = parts[1].replace("@", "")
                loc_name = " ".join(parts[2:]).lower()
                
                # Support random location
                if loc_name == "random":
                    if not self.tele_locations:
                        await self.highrise.send_whisper(user.id, "No locations saved yet.")
                        return
                    loc_name = random.choice(list(self.tele_locations.keys()))
                
                if loc_name not in self.tele_locations:
                    await self.highrise.send_whisper(user.id, f"Location '{loc_name}' does not exist.")
                    return
                
                loc_data = self.tele_locations[loc_name]
                
                # We are removing the target role check as requested: 
                # "owner and moderator koi bhi random user ko ko bhi loction ma teleport kar saka hai"
                
                room_users = await self.highrise.get_room_users()
                if isinstance(room_users, Error):
                    await self.highrise.send_whisper(user.id, f"Error fetching room users: {room_users.message}")
                    return

                # Support random user
                if target_username.lower() == "random":
                    # Filter out the bot itself
                    eligible_users = [u for u, p in room_users.content if u.id != self.my_id]
                    if not eligible_users:
                        await self.highrise.send_whisper(user.id, "No users in the room to teleport.")
                        return
                    target_user = random.choice(eligible_users)
                    target_username = target_user.username
                else:
                    target_user = next((u for u, p in room_users.content if u.username.lower() == target_username.lower()), None)
                
                if target_user:
                    p = loc_data["pos"]
                    await self.highrise.send_whisper(user.id, f"✈️Teleport @{target_username} to {loc_name}")
                    await self.highrise.teleport(target_user.id, Position(p["x"], p["y"], p["z"], p["facing"]))
                else:
                    await self.highrise.send_whisper(user.id, f"User @{target_username} not found in room.")

            elif message.lower() == "-listtele":
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can see the telelist.")
                    return
                if not self.tele_locations:
                    await self.highrise.send_whisper(user.id, "No teleport locations created yet.")
                    return
                locs = []
                for name, data in self.tele_locations.items():
                    tags = []
                    if data.get('owner_only'): tags.append("OWNER")
                    elif data.get('mod_only'): tags.append("MOD")
                    elif data.get('vip'): tags.append("VIP")
                    
                    tag_str = f" ({', '.join(tags)})" if tags else ""
                    locs.append(f"{name}{tag_str}")
                await self.highrise.send_whisper(user.id, f"Available locations: {', '.join(locs)}")

            elif message.lower().startswith("-remtele"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only an owner can remove teleport locations.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -remtele (location name)")
                    return
                loc_name = " ".join(parts[1:]).lower()
                if loc_name in self.tele_locations:
                    del self.tele_locations[loc_name]
                    self.save_config()
                    await self.highrise.send_whisper(user.id, f"Location '{loc_name}' removed.")
                else:
                    await self.highrise.send_whisper(user.id, f"Location '{loc_name}' not found.")

            elif message.lower() == "-clearteles":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can clear all teleport locations.")
                    return
                
                count = len(self.tele_locations)
                if count == 0:
                    await self.highrise.send_whisper(user.id, "There are no teleport locations to clear.")
                    return
                
                self.tele_locations.clear()
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ Successfully cleared all {count} teleport locations!")




            elif message.lower().startswith("-void"):
                if not is_staff:
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can use -void.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -void @username")
                    return
                target_username = parts[1].replace("@", "")
                
                room_users = await self.highrise.get_room_users()
                if isinstance(room_users, Error):
                    await self.highrise.send_whisper(user.id, f"Error fetching room users: {room_users.message}")
                    return
                
                target_user = next((u for u, p in room_users.content if u.username.lower() == target_username.lower()), None)
                
                if target_user:
                    # Coordinate far outside the map
                    void_pos = Position(999, 999, 999, "FrontRight")
                    await self.highrise.send_whisper(user.id, f"🌌 Sending @{target_username} to the VOID!")
                    await self.highrise.teleport(target_user.id, void_pos)
                else:
                    await self.highrise.send_whisper(user.id, f"User @{target_username} not found in room.")

            elif message.lower() == "-wallet":
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can check the wallet.")
                    return
                
                try:
                    wallet = await self.highrise.get_wallet()
                    if isinstance(wallet, Error):
                        await self.highrise.send_whisper(user.id, f"Error fetching wallet: {wallet.message}")
                        return
                    
                    # Find gold balance only
                    gold_amount = 0
                    for item in wallet.content:
                        if item.type == "gold":
                            gold_amount = item.amount
                            break
                    
                    await self.highrise.send_whisper(user.id, f"Bot Gold Balance: {gold_amount} gold")
                except Exception as e:
                    print(f"Error in -wallet: {e}")
                    await self.highrise.send_whisper(user.id, "An error occurred while fetching the wallet.")

            elif message.lower().startswith("-df"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use -df.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -df 1 | -df 2 | -df on | -df off | -df reset")
                    return
                
                subcmd = parts[1].lower()
                
                if subcmd in ["1", "2"]:
                    room_users = await self.highrise.get_room_users()
                    if hasattr(room_users, "message"):
                        await self.highrise.send_whisper(user.id, "Error fetching room users.")
                        return
                    
                    caller_pos = None
                    for ru, pos in room_users.content:
                        if ru.id == user.id:
                            caller_pos = pos
                            break
                    
                    if not caller_pos or not hasattr(caller_pos, "x"):
                        await self.highrise.send_whisper(user.id, "Could not determine your exact position.")
                        return
                    
                    if subcmd == "1":
                        self.df_pos1 = {"x": caller_pos.x, "y": caller_pos.y, "z": caller_pos.z}
                        self.save_config()
                        msg = f"✅ Dancefloor corner 1 saved at ({caller_pos.x:.2f}, {caller_pos.y:.2f}, {caller_pos.z:.2f})"
                        if getattr(self, "df_pos2", None):
                            self.autodf_on = True
                            self.save_config()
                            self.start_df_loop()
                            msg += "\n✅ Dancefloor automatically turned ON!"
                        await self.highrise.send_whisper(user.id, msg)
                    else:
                        self.df_pos2 = {"x": caller_pos.x, "y": caller_pos.y, "z": caller_pos.z}
                        self.save_config()
                        msg = f"✅ Dancefloor corner 2 saved at ({caller_pos.x:.2f}, {caller_pos.y:.2f}, {caller_pos.z:.2f})"
                        if getattr(self, "df_pos1", None):
                            self.autodf_on = True
                            self.save_config()
                            self.start_df_loop()
                            msg += "\n✅ Dancefloor automatically turned ON!"
                        await self.highrise.send_whisper(user.id, msg)

                elif subcmd == "on":
                    if not getattr(self, "df_pos1", None) or not getattr(self, "df_pos2", None):
                        await self.highrise.send_whisper(user.id, "You must set both corners first using -df 1 and -df 2.")
                        return
                    self.autodf_on = True
                    self.save_config()
                    self.start_df_loop()
                    await self.highrise.send_whisper(user.id, "✅ Dancefloor turned ON.")
                elif subcmd == "off":
                    self.autodf_on = False
                    self.save_config()
                    self.stop_df_loop()
                    await self.highrise.send_whisper(user.id, "❌ Dancefloor turned OFF.")
                elif subcmd == "reset":
                    self.df_pos1 = None
                    self.df_pos2 = None
                    self.autodf_on = False
                    self.save_config()
                    self.stop_df_loop()
                    await self.highrise.send_whisper(user.id, "✅ Dancefloor positions and settings have been fully reset.")
                else:
                    await self.highrise.send_whisper(user.id, "Usage: -df 1 | -df 2 | -df on | -df off | -df reset")

            elif message.lower().startswith("-autotip"):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can use -autotip.")
                    return
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -autotip on|off|time <minutes>|amount <gold>")
                    return
                
                subcmd = parts[1].lower()
                if subcmd == "on":
                    self.autotip_on = True
                    self.save_config()
                    self.start_autotip_loop()
                    await self.highrise.send_whisper(user.id, f"✅ Autotip turned ON. Tipping {self.autotip_amount} gold every {self.autotip_time} minutes.")
                elif subcmd == "off":
                    self.autotip_on = False
                    self.save_config()
                    self.stop_autotip_loop()
                    await self.highrise.send_whisper(user.id, "❌ Autotip turned OFF.")
                elif subcmd == "time":
                    if len(parts) < 3:
                        await self.highrise.send_whisper(user.id, "Usage: -autotip time <minutes>")
                        return
                    try:
                        self.autotip_time = max(1, int(parts[2]))
                        self.save_config()
                        if getattr(self, "autotip_on", False):
                            self.start_autotip_loop()
                        await self.highrise.send_whisper(user.id, f"✅ Autotip interval set to {self.autotip_time} minutes.")
                    except ValueError:
                        await self.highrise.send_whisper(user.id, "Invalid minutes value.")
                elif subcmd == "amount":
                    if len(parts) < 3:
                        await self.highrise.send_whisper(user.id, "Usage: -autotip amount <gold>")
                        return
                    try:
                        self.autotip_amount = int(parts[2])
                        self.save_config()
                        if getattr(self, "autotip_on", False):
                            self.start_autotip_loop()
                        await self.highrise.send_whisper(user.id, f"✅ Autotip amount set to {self.autotip_amount} gold.")
                    except ValueError:
                        await self.highrise.send_whisper(user.id, "Invalid amount value.")
                else:
                    await self.highrise.send_whisper(user.id, "Usage: -autotip on|off|time <minutes>|amount <gold>")

            elif message.lower().startswith("-tiprandom"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and admins (moderators) can use -tiprandom.")
                    return
                
                # Check current gold balance
                bot_gold = await self.get_bot_gold()
                if bot_gold <= 1:
                    await self.highrise.send_whisper(user.id, "bot gold wallet is empty")
                    return

                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -tiprandom (number of users) (amount)")
                    return
                
                try:
                    num_users = int(parts[1])
                    if num_users <= 0:
                        await self.highrise.send_whisper(user.id, "Number of users must be greater than 0.")
                        return
                except ValueError:
                    await self.highrise.send_whisper(user.id, "Invalid number of users.")
                    return
                
                amount_str = parts[2]
                bar_id = self.get_gold_bar_id(amount_str)
                if not bar_id:
                    await self.highrise.send_whisper(user.id, f"Invalid amount. Allowed: 1, 5, 10, 50, 100, 500, 1000, 5000, 10000")
                    return
                
                try:
                    room_users = await self.highrise.get_room_users()
                    if isinstance(room_users, Error):
                        await self.highrise.send_whisper(user.id, f"Error getting room users: {room_users.message}")
                        return
                    
                    eligible_users = [u for u, pos in room_users.content if u.id != self.my_id]
                    if not eligible_users:
                        await self.highrise.send_whisper(user.id, "No other users in the room to tip.")
                        return
                    
                    selected_users = random.sample(eligible_users, min(num_users, len(eligible_users)))
                    
                    count = 0
                    for target_user in selected_users:
                        res = await self.highrise.tip_user(target_user.id, bar_id)
                        if res == "success":
                            count += 1
                        elif res == "insufficient_funds":
                            await self.highrise.send_whisper(user.id, f"Bot ran out of gold after tipping {count} users!")
                            return
                    
                    await self.highrise.send_whisper(user.id, f"Successfully tipped {count} random users in the room!")
                except Exception as e:
                    print(f"Error in -tiprandom: {e}")
                    await self.highrise.send_whisper(user.id, "An error occurred during random tipping.")

            elif message.lower().startswith("-tipall"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and admins (moderators) can use -tipall.")
                    return
                
                # Check current gold balance
                bot_gold = await self.get_bot_gold()
                if bot_gold <= 1:
                    await self.highrise.send_whisper(user.id, "bot gold wallet is empty")
                    return

                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -tipall (amount)")
                    return
                
                amount_str = parts[1]
                bar_id = self.get_gold_bar_id(amount_str)
                if not bar_id:
                    await self.highrise.send_whisper(user.id, f"Invalid amount. Allowed: 1, 5, 10, 50, 100, 500, 1000, 5000, 10000")
                    return
                
                try:
                    room_users = await self.highrise.get_room_users()
                    if isinstance(room_users, Error):
                        await self.highrise.send_whisper(user.id, f"Error getting room users: {room_users.message}")
                        return
                    
                    count = 0
                    for target_user, pos in room_users.content:
                        if target_user.id == self.my_id:
                            continue
                        res = await self.highrise.tip_user(target_user.id, bar_id)
                        if res == "success":
                            count += 1
                        elif res == "insufficient_funds":
                            await self.highrise.send_whisper(user.id, f"Bot ran out of gold after tipping {count} users!")
                            return
                    
                    await self.highrise.send_whisper(user.id, f"Successfully tipped {count} users in the room!")
                except Exception as e:
                    print(f"Error in -tipall: {e}")
                    await self.highrise.send_whisper(user.id, "An error occurred during bulk tipping.")

            elif message.lower().startswith("-tip"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and admins (moderators) can use -tip.")
                    return
                
                # Check current gold balance
                bot_gold = await self.get_bot_gold()
                if bot_gold <= 1:
                    await self.highrise.send_whisper(user.id, "bot gold wallet is empty")
                    return

                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -tip @username (amount)")
                    return
                
                target_username = parts[1].replace("@", "")
                amount_str = parts[2]
                bar_id = self.get_gold_bar_id(amount_str)
                if not bar_id:
                    await self.highrise.send_whisper(user.id, f"Invalid amount. Allowed: 1, 5, 10, 50, 100, 500, 1000, 5000, 10000")
                    return
                
                try:
                    room_users = await self.highrise.get_room_users()
                    target_user = next((u for u, p in room_users.content if u.username.lower() == target_username.lower()), None)
                    if not target_user:
                        await self.highrise.send_whisper(user.id, f"User {target_username} not found in room.")
                        return
                    
                    res = await self.highrise.tip_user(target_user.id, bar_id)
                    if res == "success":
                        await self.highrise.send_whisper(user.id, f"Successfully tipped @{target_username} {amount_str} gold!")
                    elif res == "insufficient_funds":
                        await self.highrise.send_whisper(user.id, "Bot has insufficient funds for this tip.")
                    else:
                        await self.highrise.send_whisper(user.id, f"Tipping failed: {res}")
                except Exception as e:
                    print(f"Error in -tip: {e}")
                    await self.highrise.send_whisper(user.id, "An error occurred while tipping.")

            elif message.lower().startswith("-punch"):
                if not (self.is_owner(user.username) or self.is_mod(user.username) or self.is_vip(user.username)):
                    await self.highrise.send_whisper(user.id, "Only VIPs, Moderators, and Owners can use the -punch command.")
                    return
                    
                parts = message.split()
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, "Usage: -punch @username")
                    return
                
                target = parts[1].replace("@", "")
                uid = await self.get_id_from_name(target)
                if uid:
                    # Send message
                    await self.highrise.chat(f"👊 {user.username} threw a massive punch at @{target}! Ouch! 👊")
                    # User who typed command punches
                    await self.highrise.send_emote("emoji-punch", user.id)
                    await asyncio.sleep(0.5)
                    # Target user dies
                    await self.highrise.send_emote("emote-death2", uid)
                else:
                    await self.highrise.send_whisper(user.id, f"User @{target} not found in the room.")

            # Reaction commands
            elif any(message.lower().startswith(f"-{reaction}") for reaction in ["heart", "wink", "clap", "thumbs"]):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can use reaction commands.")
                    return

                parts = message.lower().split()
                command = parts[0][1:] # e.g., "heartall" or "clap"
                
                reaction_map = {"heart": "heart", "wink": "wink", "clap": "clap", "thumbs": "thumbs"}
                reaction_name = command.replace("all", "")
                reaction_id = reaction_map.get(reaction_name)

                if not reaction_id:
                    return # Should not happen with the startswith check

                # Bulk reaction to all users
                if command.endswith("all"):
                    try:
                        room_users = await self.highrise.get_room_users()
                        if isinstance(room_users, Error):
                            await self.highrise.send_whisper(user.id, f"Error getting room users: {room_users.message}")
                            return
                        
                        for target_user, pos in room_users.content:
                            if target_user.id != self.my_id:
                                await self.highrise.react(reaction_id, target_user.id)
                        await self.highrise.send_whisper(user.id, f"Sent a {reaction_name} to everyone!")
                    except Exception as e:
                        print(f"Error in -{command}: {e}")
                    return

                # Reaction to a specific user
                if len(parts) < 2:
                    await self.highrise.send_whisper(user.id, f"Usage: -{reaction_name} @username [amount]")
                    return
                
                target_username = parts[1].replace("@", "")
                amount = 1
                if len(parts) > 2 and parts[2].isdigit():
                    amount = int(parts[2])
                
                target_user_id = await self.get_id_from_name(target_username)
                if not target_user_id:
                    await self.highrise.send_whisper(user.id, f"User @{target_username} not found.")
                    return
                
                try:
                    for _ in range(amount):
                        await self.highrise.react(reaction_id, target_user_id)
                        await asyncio.sleep(0.3) # Reduced delay
                    await self.highrise.send_whisper(user.id, f"Sent {amount} {reaction_name}(s) to @{target_username}!")
                except Exception as e:
                    print(f"Error in -{reaction_name}: {e}")

            elif message.lower().startswith("-cancelbot"):
                return


            elif message.lower().startswith("-addnotify "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "ℹ️ Only the bot owner can use this command.")
                    return
                nt_name = message.split(None, 1)[1].replace("@", "").strip()
                if not nt_name:
                    await self.highrise.send_whisper(user.id, "Usage: -addnotify @username")
                    return
                if not await self.get_id_from_name(nt_name):
                    await self.highrise.send_whisper(user.id, f"❌ User @{nt_name} not found.")
                    return
                if nt_name.lower() in [n.lower() for n in self._notify_recipients()]:
                    await self.highrise.send_whisper(user.id, f"@{nt_name} already gets moderation alerts.")
                    return
                self.notify_users.append(nt_name)
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ @{nt_name} will now get a private message whenever someone mutes, bans, kicks or freezes.")
                return

            elif message.lower().startswith("-remnotify "):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "ℹ️ Only the bot owner can use this command.")
                    return
                nt_name = message.split(None, 1)[1].replace("@", "").strip()
                if nt_name.lower() not in [n.lower() for n in self.notify_users]:
                    await self.highrise.send_whisper(user.id, f"@{nt_name} is not on the alert list (owners always get alerts).")
                    return
                self.notify_users = [n for n in self.notify_users if n.lower() != nt_name.lower()]
                self.save_config()
                await self.highrise.send_whisper(user.id, f"✅ @{nt_name} removed from moderation alerts.")
                return

            elif message.lower() == "-notifylist":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "ℹ️ Only the bot owner can use this command.")
                    return
                owners_txt = ", ".join("@" + o for o in self.owners) or "none"
                extra_txt = ", ".join("@" + n for n in self.notify_users) or "none"
                await self.highrise.send_whisper(user.id, f"🔔 Moderation alerts go to:\nOwners: {owners_txt}\nExtra: {extra_txt}")
                return

            elif message.lower() == "-listlanguage":
                supported = "hindi, punjabi, turkish, brazil, english, arabic, persian, spanish, russian, french"
                await self.highrise.send_whisper(user.id, f"🌍 Supported languages: {supported}")
                return

            elif message.lower() in ("-language", "-lang"):
                current = getattr(self, "bot_language", "en")
                reverse_map = {"hi": "hindi", "pa": "punjabi", "tr": "turkish", "pt": "brazil",
                               "en": "english", "ar": "arabic", "fa": "persian", "es": "spanish",
                               "ru": "russian", "fr": "french"}
                name = reverse_map.get(current, current)
                await self.highrise.send_whisper(user.id, f"🌍 Current bot language: {name.capitalize()} ({current})")
                return

            elif message.lower().startswith(("-language ", "-lang ")):
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "🚫 Only the bot owner can use this command.")
                    return
                _lang_arg = message.split(None, 1)[1].strip() if len(message.split(None, 1)) > 1 else ""
                lang = _lang_arg.lower()
                lang_map = {
                    "hindi": "hi", "punjabi": "pa", "turkish": "tr",
                    "brazil": "pt", "english": "en", "arabic": "ar",
                    "persian": "fa", "spanish": "es", "russian": "ru",
                    "french": "fr"
                }
                if lang in lang_map:
                    old = getattr(self, "bot_language", "en")
                    self.bot_language = lang_map[lang]
                    self.save_config()
                    msg = f"✅ Bot language changed from {old} to {lang.capitalize()} ({lang_map[lang]})."
                    try:
                        await self.highrise.chat(msg)
                    except Exception:
                        pass
                    await self.highrise.send_whisper(user.id, msg + "\n💾 Persisted to config.json")
                else:
                    await self.highrise.send_whisper(user.id, "❌ Unsupported language.\n🌍 Supported: hindi, punjabi, turkish, brazil, english, arabic, persian, spanish, russian, french")
                return

            elif message.lower().startswith("-botapi"):
                if user.username.lower() in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                    try:
                        api_token = self.config.get("API_TOKEN", "Not found")
                        reply = f"🔑 Bot API Token:\n{api_token}"
                        await self.highrise.send_whisper(user.id, reply)
                    except Exception as e:
                        await self.highrise.send_whisper(user.id, f"❌ Failed to fetch API token: {e}")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ You don't have permission to use this command.")
                return

            elif message.lower() == "-botstatus":
                if user.username.lower() in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                    try:
                        status_file = os.path.join("settings", "bot_status.json")
                        status_data = {}
                        if os.path.exists(status_file):
                            try:
                                with open(status_file, "r") as f:
                                    status_data = json.load(f) or {}
                            except:
                                status_data = {}
                        
                        # Filter bots online in the last 40 seconds
                        current_time = time.time()
                        online_bots = []
                        for bot_id, entry in status_data.items():
                            last_seen = entry.get("last_seen", 0)
                            if current_time - last_seen < 40:
                                online_bots.append(entry)
                        
                        if not online_bots:
                            report = "👑 RENTABOT STATUS 👑\n━━━━━━━━━━━━━━━━━━\n❌ No bots are currently online.\n━━━━━━━━━━━━━━━━━━"
                            if getattr(self, "venomx_conversation_id", None):
                                await self.highrise.send_message(self.venomx_conversation_id, report)
                            else:
                                await self.highrise.send_whisper(user.id, report)
                                await self.highrise.send_whisper(user.id, "💡 Tip: Send me a Direct Message (DM) once, and next time I will send this report directly to your inbox instead of whispers!")
                            return
                        
                        msg_lines = [
                            "👑  RENTABOT STATUS  👑",
                            "━━━━━━━━━━━━━━━━━━",
                            f"🤖 Total Active Bots: {len(online_bots)}",
                            ""
                        ]
                        for idx, bot in enumerate(online_bots, 1):
                            b_name = bot.get("username", "RentABot")
                            b_room = bot.get("room_id", "Unknown")
                            msg_lines.append(f"{idx}. 🟢 @{b_name}")
                            msg_lines.append(f"   📍 Room: {b_room}")
                            msg_lines.append("")
                        
                        msg_lines.append("━━━━━━━━━━━━━━━━━━")
                        report = "\n".join(msg_lines)
                        if getattr(self, "venomx_conversation_id", None):
                            await self.highrise.send_message(self.venomx_conversation_id, report)
                        else:
                            await self.highrise.send_whisper(user.id, report)
                            await self.highrise.send_whisper(user.id, "💡 Tip: Send me a Direct Message (DM) once, and next time I will send this report directly to your inbox instead of whispers!")
                    except Exception as e:
                        print(f"Error in -botstatus: {e}")
                        await self.highrise.send_whisper(user.id, f"❌ Failed to fetch bot status: {e}")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ You don't have permission to use this command.")
                return

            elif message.lower().startswith("-cancel "):
                if user.username.lower() in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                    try:
                        parts = message.split()
                        if len(parts) < 2 or not parts[1].isdigit():
                            reply = "💡 Usage: -cancel [number]"
                            if getattr(self, "venomx_conversation_id", None):
                                await self.highrise.send_message(self.venomx_conversation_id, reply)
                            else:
                                await self.highrise.send_whisper(user.id, reply)
                            return
                        
                        target_idx = int(parts[1]) - 1 # 1-indexed to 0-indexed
                        
                        # 1. Read online bots status to map the index to the token
                        status_file = os.path.join("settings", "bot_status.json")
                        status_data = {}
                        if os.path.exists(status_file):
                            try:
                                with open(status_file, "r") as f:
                                    status_data = json.load(f) or {}
                            except:
                                status_data = {}
                        
                        current_time = time.time()
                        online_bots = []
                        for b_id, entry in status_data.items():
                            last_seen = entry.get("last_seen", 0)
                            if current_time - last_seen < 40:
                                online_bots.append((b_id, entry))
                        
                        if target_idx < 0 or target_idx >= len(online_bots):
                            reply = f"❌ Invalid bot number. Please run -botstatus to see valid numbers (1 to {len(online_bots)})."
                            if getattr(self, "venomx_conversation_id", None):
                                await self.highrise.send_message(self.venomx_conversation_id, reply)
                            else:
                                await self.highrise.send_whisper(user.id, reply)
                            return
                        
                        target_uid, target_bot = online_bots[target_idx]
                        target_username = target_bot.get("username", "RentABot")
                        target_room = target_bot.get("room_id", "Unknown")
                        
                        # 2. Find and remove from bots_config.json
                        removed = False
                        if os.path.exists("bots_config.json"):
                            try:
                                with open("bots_config.json", "r") as f:
                                    bots_data = json.load(f) or []
                            except:
                                bots_data = []
                            
                            if isinstance(bots_data, list):
                                new_bots_data = []
                                for b in bots_data:
                                    if b.get("room_id", "").strip() == target_room:
                                        removed = True
                                    else:
                                        new_bots_data.append(b)
                                
                                if removed:
                                    with open("bots_config.json", "w") as f:
                                        json.dump(new_bots_data, f, indent=4)
                            
                        # 3. Clean up its heartbeat registry entry so it doesn't show up in status anymore
                        try:
                            if target_uid in status_data:
                                del status_data[target_uid]
                                with open(status_file, "w") as f:
                                    json.dump(status_data, f, indent=4)
                        except:
                            pass
                        
                        # 4. Reply
                        if removed:
                            reply = f"🛑 Bot #{target_idx + 1} (@{target_username} in room {target_room}) has been turned off and removed from the active launcher registry successfully!"
                        else:
                            reply = f"⚠️ Could not find Bot #{target_idx + 1} (@{target_username}) in bots_config.json, but its active registry has been cleared."
                        
                        if getattr(self, "venomx_conversation_id", None):
                            await self.highrise.send_message(self.venomx_conversation_id, reply)
                        else:
                            await self.highrise.send_whisper(user.id, reply)
                            
                    except Exception as e:
                        print(f"Error in -cancel command: {e}")
                        await self.highrise.send_whisper(user.id, f"❌ Failed to terminate bot: {e}")
                else:
                    await self.highrise.send_whisper(user.id, "ℹ️ You don't have permission to use this command.")
                return

            elif msg_lower.startswith(("-botroom", "-roomid")):
                if msg_lower.startswith("-roomid"):
                    if user.username.lower() not in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                        await self.highrise.send_whisper(user.id, "🚫 You don't have permission to use -roomid.")
                        return
                else:
                    if not self.is_owner(user.username):
                        await self.highrise.send_whisper(user.id, "🚫 You don't have permission to use -botroom.")
                        return
                
                parts = message.split()
                if len(parts) < 2:
                    cmd_prefix = "-roomid" if msg_lower.startswith("-roomid") else "-botroom"
                    await self.highrise.send_whisper(user.id, f"💡 Usage: {cmd_prefix} [room_link/id]")
                    return
                
                room_input = parts[1].strip().strip("()").strip()
                new_room_id = room_input
                if "highrise.game/room/" in room_input:
                    new_room_id = room_input.split("highrise.game/room/")[-1].split("?")[0].split("&")[0]
                elif "high.rs/room?id=" in room_input:
                    new_room_id = room_input.split("high.rs/room?id=")[-1].split("&")[0]
                elif "high.rs/world" in room_input:
                    if "ownedRoomId=" in room_input:
                        new_room_id = room_input.split("ownedRoomId=")[-1].split("&")[0]
                    elif "id=" in room_input:
                        new_room_id = room_input.split("id=")[-1].split("&")[0]
                elif "rid=" in room_input:
                    new_room_id = room_input.split("rid=")[-1].split("&")[0]

                await self.highrise.send_whisper(user.id, f"🚀 Switching CURRENT bot to new room: {new_room_id}\n🌀 Joining new room shortly...")
                await asyncio.sleep(0.5)
                
                try:
                    token_clean = self.config.get("API_TOKEN", "").strip()
                    
                    try:
                        if not os.path.exists("settings"):
                            os.makedirs("settings")

                        self.save_config()

                        new_settings_file = os.path.join("settings", f"settings_{new_room_id}.json")
                        existing = {}
                        if os.path.exists(new_settings_file):
                            try:
                                with open(new_settings_file, "r") as f:
                                    existing = json.load(f) or {}
                            except:
                                existing = {}

                        merged = dict(existing)
                        merged.update(self.config)

                        merged["owners"] = self.owners
                        merged["mods"] = self.mods
                        merged["vips"] = self.vips

                        tmp_file = new_settings_file + ".tmp"
                        with open(tmp_file, "w") as f:
                            json.dump(merged, f, indent=4)
                        try:
                            os.replace(tmp_file, new_settings_file)
                        except OSError:
                            if os.path.exists(new_settings_file):
                                os.remove(new_settings_file)
                            os.rename(tmp_file, new_settings_file)
                    except Exception as e:
                        print(f"[WARN] Failed to migrate settings: {e}")
                    
                    if os.path.exists("bots_config.json"):
                        try:
                            with open("bots_config.json", "r") as f:
                                bots_data = json.load(f)
                            
                            found = False
                            if isinstance(bots_data, list):
                                for b in bots_data:
                                    if b.get("token", "").strip() == token_clean:
                                        b["room_id"] = new_room_id
                                        b["force_restart"] = False
                                        found = True
                                        break
                                
                                if found:
                                    with open("bots_config.json", "w") as f:
                                        json.dump(bots_data, f, indent=4)
                        except Exception as e:
                            print(f"Error updating bots_config: {e}")
                    
                    if os.path.exists("config.json"):
                        try:
                            with open("config.json", "r") as f:
                                main_cfg = json.load(f)
                            main_cfg["ROOM_ID"] = new_room_id
                            main_cfg["room_id"] = new_room_id
                            main_cfg["force_restart"] = False
                            with open("config.json", "w") as f:
                                json.dump(main_cfg, f, indent=4)
                        except Exception as e:
                            print(f"Error updating config.json: {e}")
                            
                    self.save_config()
                    await self.highrise.send_whisper(user.id, "✅ Settings migrated! The bot is now restarting to join the new room... 🚀")
                    
                    with open("restart.flag", "w") as f:
                        f.write("restart")
                    
                    os._exit(0)
                    
                except Exception as e:
                    print(f"[ERROR] room change error: {e}")
                    await self.highrise.send_whisper(user.id, f"❌ Failed to update room configuration: {e}")
                return


            elif message.lower() == "-rolelist":
                if not self.is_owner(user.username):
                    await self.highrise.send_whisper(user.id, "Only the owner can see the role list.")
                    return

                try:
                    # Construct individual role strings
                    owners_list = "\n".join([f"👑 @{o}" for o in self.owners]) if self.owners else "None"
                    mods_list = "\n".join([f"🔰 @{m}" for m in self.mods]) if self.mods else "None"
                    vips_list = "\n".join([f"💎 @{v}" for v in self.vips]) if self.vips else "None"

                    # Ultimate Premium Role List Message
                    response = (
                        "✨ **ROLE LIST** ✨\n\n"
                        "━━━━━━━━━━━━━━━\n\n"
                        "👑 **Room Owners**\n"
                        f"{owners_list}\n\n"
                        "🔰 **Bot Moderators**\n"
                        f"{mods_list}\n\n"
                        "💎 **VIP Members**\n"
                        f"{vips_list}\n\n"
                        "━━━━━━━━━━━━━━━\n\n"
                        "📜 **Show Roles**\n"
                        "`-rolelist` ➤ Displays in order:\n"
                        "👑 Owner → 🔰 Moderator → 💎 VIP\n\n"
                        "━━━━━━━━━━━━━━━\n"
                        "⚡ Keep your room clean & organized ⚡"
                    )

                    try:
                        # Send full list via DM to bypass whisper length limits
                        await self.highrise.send_message_bulk([user.id], response)
                        await self.highrise.send_whisper(user.id, f"@{user.username}, I've sent the full Role List to your DMs! 📩")
                    except:
                        # Fallback to a compact version in whisper if DM fails
                        compact_msg = f"✨ Bot Roles: Owners({len(self.owners)}), Mods({len(self.mods)}), VIPs({len(self.vips)}). Check DMs for names!"
                        await self.highrise.send_whisper(user.id, compact_msg)
                except Exception as e:
                    print(f"Error in -rolelist: {e}")
                    await self.highrise.send_whisper(user.id, "An error occurred while fetching the role list.")
                return

            elif message.lower().startswith("-spam"):
                if not await self.is_mod_or_owner(user.id, user.username):
                    await self.highrise.send_whisper(user.id, "Only owner and moderators can use -spam.")
                    return
                
                parts = message.split()
                if len(parts) < 3:
                    await self.highrise.send_whisper(user.id, "Usage: -spam (message) (amount)")
                    return
                
                try:
                    amount = int(parts[-1])
                    spam_message = " ".join(parts[1:-1])

                    if amount > 100: # Prevent abuse
                        await self.highrise.send_whisper(user.id, "Spam amount cannot exceed 100.")
                        return

                    for _ in range(amount):
                        await self.highrise.chat(spam_message)
                        await asyncio.sleep(0.5) # Delay to prevent flooding
                except ValueError:
                    await self.highrise.send_whisper(user.id, "Invalid amount. Please provide a number.")
                except Exception as e:
                    print(f"Error in -spam: {e}")

            # Example of a locked command (or any command starting with -)
            elif message.startswith("-"):
                if not self.is_subscribed(user.username):
                    await self.highrise.send_whisper(user.id, f"Sorry @{user.username}, you need to be subscribed to use this command. Ask the owner for access!")
                    return
                
                # If they ARE subscribed, handle other commands here
                # (None specified by the user yet, but they will be unlocked)
                pass

        except BaseException as e:
            await self.on_error(e)

    async def on_user_leave(self, user: User) -> None:
        """Called when a user leaves the room."""
        try:
            print(f"User {user.username} left.")
            
            if hasattr(self, "user_stats") and user.id in self.user_stats and self.user_stats[user.id].get("join_time"):
                time_spent = time.time() - self.user_stats[user.id]["join_time"]
                self.user_stats[user.id]["total_time"] = self.user_stats[user.id].get("total_time", 0) + time_spent
                self.user_stats[user.id]["join_time"] = None
            
            # Send goodbye message
            try:
                if getattr(self, "custom_goodbye_message", None):
                    goodbye_msg = self.custom_goodbye_message
                    placeholders = [
                        ("@username", f"@{user.username}"),
                        ("@Username", f"@{user.username}"),
                        ("{user}", f"{user.username}")
                    ]
                    for placeholder, val in placeholders:
                        goodbye_msg = goodbye_msg.replace(placeholder, val)
                elif self.is_owner(user.username):
                    goodbye_msg = random.choice(self.owner_goodbye_messages).format(user=user.username)
                elif self.is_mod(user.username):
                    goodbye_msg = random.choice(self.mod_goodbye_messages).format(user=user.username)
                elif self.is_subscribed(user.username): # is_subscribed already checks VIPs/Subscribers
                    goodbye_msg = random.choice(self.vip_goodbye_messages).format(user=user.username)
                else:
                    goodbye_msg = random.choice(self.goodbye_messages).format(user=user.username)
                await self.highrise.chat(goodbye_msg)
            except Exception as e:
                print(f"Error sending goodbye message: {e}")

            if user.id in self.user_loops:
                del self.user_loops[user.id]

            if user.id in self.frozen_users:
                del self.frozen_users[user.id]
            if hasattr(self, "line_users") and user.id in self.line_users:
                idx = self.line_users.index(user.id)
                self.line_users[idx] = None
        except BaseException as e:
            await self.on_error(e)

    async def get_username_from_id(self, user_id: str) -> str | None:
        # Fast Path 1: Check reverse cache
        for name, uid in self.id_cache.items():
            if uid == user_id:
                return name
                
        # Fast Path 2: Check users currently inside the room
        try:
            room_users = await self.highrise.get_room_users()
            if not isinstance(room_users, Error):
                for u, _ in room_users.content:
                    if u.id == user_id:
                        self.id_cache[u.username.lower()] = u.id # update cache
                        return u.username
        except:
            pass
            
        # Slow Path: Web API fallback
        session = await self._get_session()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Accept": "application/json"}
        url = f"https://webapi.highrise.game/users/{user_id}"
        try:
            async with session.get(url, headers=headers, timeout=5) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if isinstance(data, dict):
                        user_data = data.get("user")
                        if isinstance(user_data, dict):
                            username = user_data.get("username")
                            if username:
                                self.id_cache[username.lower()] = user_id
                                return username
        except Exception as e:
            print(f"Error fetching username from ID: {e}")
        return None


    def _notify_recipients(self):
        """Bot owners (always) + extra users the owner added with -addnotify."""
        names, seen = [], set()
        for n in list(getattr(self, "owners", [])) + list(getattr(self, "notify_users", [])):
            clean = str(n).replace("@", "").strip()
            if clean and clean.lower() not in seen:
                seen.add(clean.lower())
                names.append(clean)
        return names

    async def notify_moderation(self, actor_name, action, target_name, detail=""):
        """Send a private DM to the owner(s) + notify list when someone mutes/bans/kicks/freezes."""
        try:
            actor_clean = str(actor_name or "unknown").replace("@", "").strip()
            target_clean = str(target_name or "unknown").replace("@", "").strip()
            text = f"🛡️ Moderation alert\n👤 By: @{actor_clean}\n⚙️ Action: {action}"
            if detail:
                text += f" ({detail})"
            text += f"\n🎯 Target: @{target_clean}"
            room = getattr(self, "room_id", None)
            if room:
                text += f"\n🏠 Room: {room}"
            for name in self._notify_recipients():
                rid = await self.get_id_from_name(name)
                if not rid:
                    print(f"[NOTIFY] Could not resolve id for {name}")
                    continue
                try:
                    await self.highrise.send_message_bulk([rid], text)
                except Exception as e:
                    print(f"[NOTIFY] DM to {name} failed: {e}")
        except Exception as e:
            print(f"[NOTIFY] Error: {e}")

    async def on_moderate(self, moderator_id: str, target_user_id: str, moderator_action: str, duration=None) -> None:
        """Fires when anyone moderates in the room (in-app mod tools too), so owners get alerted."""
        try:
            action = str(moderator_action).lower()
            if action not in ("kick", "ban", "mute"):
                return
            if moderator_id == getattr(self, "my_id", None):
                return  # the bot's own commands already alert with the real person's name
            actor = await self.get_username_from_id(moderator_id) or moderator_id
            target = await self.get_username_from_id(target_user_id) or target_user_id
            detail = ""
            if duration:
                detail = f"{int(duration) // 60} min" if int(duration) >= 60 else f"{int(duration)} sec"
            asyncio.create_task(self.notify_moderation(actor, action, target, detail))
        except Exception as e:
            print(f"[NOTIFY] on_moderate error: {e}")

    async def on_message(self, user_id: str, conversation_id: str, is_new_conversation: bool) -> None:
        """Called when a message is received in a conversation/DM."""
        try:
            # Check the latest message
            res = await self.highrise.get_messages(conversation_id)
            if isinstance(res, Error) or not res.messages:
                return
            
            message = res.messages[0]
            if message.sender_id == self.my_id:
                return
            
            msg_lower = message.content.lower().strip()
            
            # Get sender username
            sender_username = await self.get_username_from_id(user_id)
            
            # Check if sender is a permanent owner
            is_permanent_owner = sender_username and sender_username.lower() in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]
            
            # Save conversation ID for future use if it's a permanent owner
            if is_permanent_owner:
                self.venomx_conversation_id = conversation_id
                try:
                    if not os.path.exists("settings"):
                        try: os.makedirs("settings")
                        except: pass
                    with open(os.path.join("settings", "venomx_conv.json"), "w") as f:
                        json.dump({"conversation_id": conversation_id}, f)
                except Exception as e:
                    print(f"Error saving conversation ID: {e}")

                # -botapi command
                if msg_lower.startswith("-botapi "):
                    if not is_permanent_owner:
                        await self.highrise.send_message(conversation_id, "ℹ️ You don't have permission to use this command.")
                        return
                    new_token = message.content[len("-botapi "):].strip()
                    if not new_token:
                        await self.highrise.send_message(conversation_id, "💡 Usage: -botapi [bot_token]")
                        return
                    
                    try:
                        self.pending_bot_token = new_token
                        obfuscated = new_token[:6] + "..." + new_token[-6:] if len(new_token) > 12 else new_token
                        await self.highrise.send_message(conversation_id, f"✅ Temporary Bot Token Saved: {obfuscated}!\n👉 Now send -roomid [room_link] to spawn this new bot!\n💡 (Or send -cancelbot to cancel)")
                    except Exception as e:
                        print(f"Error in DM -botapi: {e}")
                        await self.highrise.send_message(conversation_id, f"❌ Failed to save API token: {e}")
                    return

                # -cancelbot command
                elif msg_lower == "-cancelbot":
                    if not is_permanent_owner:
                        return
                    self.pending_bot_token = None
                    await self.highrise.send_message(conversation_id, "✅ Pending bot configuration cancelled.")
                    return

                # -cancel command
                elif msg_lower.startswith("-cancel "):
                    if not is_permanent_owner:
                        await self.highrise.send_message(conversation_id, "ℹ️ You don't have permission to use this command.")
                        return
                    try:
                        parts = message.content.split()
                        if len(parts) < 2 or not parts[1].isdigit():
                            await self.highrise.send_message(conversation_id, "💡 Usage: -cancel [number]")
                            return
                        
                        target_idx = int(parts[1]) - 1
                        
                        status_file = os.path.join("settings", "bot_status.json")
                        status_data = {}
                        if os.path.exists(status_file):
                            try:
                                with open(status_file, "r") as f:
                                    status_data = json.load(f) or {}
                            except:
                                status_data = {}
                        
                        current_time = time.time()
                        online_bots = []
                        for b_id, entry in status_data.items():
                            last_seen = entry.get("last_seen", 0)
                            if current_time - last_seen < 40:
                                online_bots.append((b_id, entry))
                        
                        if target_idx < 0 or target_idx >= len(online_bots):
                            await self.highrise.send_message(conversation_id, f"❌ Invalid bot number. Please send -botstatus to see valid numbers (1 to {len(online_bots)}).")
                            return
                        
                        target_uid, target_bot = online_bots[target_idx]
                        target_username = target_bot.get("username", "RentABot")
                        target_room = target_bot.get("room_id", "Unknown")
                        
                        removed = False
                        if os.path.exists("bots_config.json"):
                            try:
                                with open("bots_config.json", "r") as f:
                                    bots_data = json.load(f) or []
                            except:
                                bots_data = []
                            
                            if isinstance(bots_data, list):
                                new_bots_data = []
                                for b in bots_data:
                                    if b.get("room_id", "").strip() == target_room:
                                        removed = True
                                    else:
                                        new_bots_data.append(b)
                                
                                if removed:
                                    with open("bots_config.json", "w") as f:
                                        json.dump(new_bots_data, f, indent=4)
                            
                        try:
                            if target_uid in status_data:
                                del status_data[target_uid]
                                with open(status_file, "w") as f:
                                    json.dump(status_data, f, indent=4)
                        except:
                            pass
                        
                        if removed:
                            reply = f"🛑 Bot #{target_idx + 1} (@{target_username} in room {target_room}) has been turned off and removed from the active launcher registry successfully!"
                        else:
                            reply = f"⚠️ Could not find Bot #{target_idx + 1} (@{target_username}) in bots_config.json, but its active registry has been cleared."
                        
                        await self.highrise.send_message(conversation_id, reply)
                            
                    except Exception as e:
                        print(f"Error in DM -cancel: {e}")
                        await self.highrise.send_message(conversation_id, f"❌ Failed to terminate bot: {e}")
                    return

                # -botstatus command
                elif msg_lower == "-botstatus":
                    if not is_permanent_owner:
                        await self.highrise.send_message(conversation_id, "ℹ️ You don't have permission to use this command.")
                        return
                    try:
                        status_file = os.path.join("settings", "bot_status.json")
                        status_data = {}
                        if os.path.exists(status_file):
                            try:
                                with open(status_file, "r") as f:
                                    status_data = json.load(f) or {}
                            except:
                                status_data = {}
                        
                        current_time = time.time()
                        online_bots = []
                        for b_id, entry in status_data.items():
                            last_seen = entry.get("last_seen", 0)
                            if current_time - last_seen < 40:
                                online_bots.append(entry)
                        
                        if not online_bots:
                            await self.highrise.send_message(conversation_id, "👑 RENTABOT STATUS 👑\n━━━━━━━━━━━━━━━━━━\n❌ No bots are currently online.\n━━━━━━━━━━━━━━━━━━")
                            return
                        
                        msg_lines = [
                            "👑  RENTABOT STATUS  👑",
                            "━━━━━━━━━━━━━━━━━━",
                            f"🤖 Total Active Bots: {len(online_bots)}",
                            ""
                        ]
                        for idx, bot in enumerate(online_bots, 1):
                            b_name = bot.get("username", "RentABot")
                            b_room = bot.get("room_id", "Unknown")
                            msg_lines.append(f"{idx}. 🟢 @{b_name}")
                            msg_lines.append(f"   📍 Room: {b_room}")
                            msg_lines.append("")
                        
                        msg_lines.append("━━━━━━━━━━━━━━━━━━")
                        await self.highrise.send_message(conversation_id, "\n".join(msg_lines))
                    except Exception as e:
                        print(f"Error in DM -botstatus: {e}")
                        await self.highrise.send_message(conversation_id, f"❌ Failed to fetch bot status: {e}")
                    return
                
                # -botroom / -roomid command (two cases: pending token or switch current bot)
                elif msg_lower.startswith(("-botroom", "-roomid")):
                    if msg_lower.startswith("-roomid"):
                        if not sender_username or sender_username.lower() not in [o.lower() for o in getattr(self, "permanent_owners", ["elphantom"])]:
                            await self.highrise.send_message(conversation_id, "🚫 You don't have permission to use -roomid.")
                            return
                    else:
                        if not sender_username or not self.is_owner(sender_username):
                            await self.highrise.send_message(conversation_id, "🚫 You don't have permission to use -botroom.")
                            return
                    # Case 1: Pending token exists - spawn new bot
                    if self.pending_bot_token:
                        try:
                            parts = message.content.split()
                            if len(parts) < 2:
                                cmd_prefix = "-roomid" if msg_lower.startswith("-roomid") else "-botroom"
                                await self.highrise.send_message(conversation_id, f"💡 Usage: {cmd_prefix} [room_link/id]")
                                return
                            
                            room_input = parts[1].strip().strip("()").strip()
                            new_room_id = room_input
                            if "highrise.game/room/" in room_input:
                                new_room_id = room_input.split("highrise.game/room/")[-1].split("?")[0].split("&")[0]
                            elif "high.rs/room?id=" in room_input:
                                new_room_id = room_input.split("high.rs/room?id=")[-1].split("&")[0]
                            elif "high.rs/world" in room_input:
                                if "ownedRoomId=" in room_input:
                                    new_room_id = room_input.split("ownedRoomId=")[-1].split("&")[0]
                                elif "id=" in room_input:
                                    new_room_id = room_input.split("id=")[-1].split("&")[0]
                            elif "rid=" in room_input:
                                new_room_id = room_input.split("rid=")[-1].split("&")[0]

                            target_token = self.pending_bot_token
                            bots_data = []
                            if os.path.exists("bots_config.json"):
                                try:
                                    with open("bots_config.json", "r") as f:
                                        bots_data = json.load(f) or []
                                except: pass
                            
                            bots_data = [b for b in bots_data if b.get("token", "").strip() != target_token.strip()]
                            
                            bots_data.append({
                                "token": target_token,
                                "room_id": new_room_id,
                                "force_restart": False
                            })
                            
                            with open("bots_config.json", "w") as f:
                                json.dump(bots_data, f, indent=4)
                                
                            self.pending_bot_token = None
                            await self.highrise.send_message(conversation_id, f"✅ Success! New bot added to the launcher registry and will spawn in room {new_room_id} shortly. 🚀")
                        except Exception as e:
                            print(f"Error in DM -roomid spawn: {e}")
                            await self.highrise.send_message(conversation_id, f"❌ Failed to spawn bot: {e}")
                        return
                    # Case 2: No pending token - switch current bot
                    else:
                        try:
                            parts = message.content.split()
                            if len(parts) < 2:
                                cmd_prefix = "-roomid" if msg_lower.startswith("-roomid") else "-botroom"
                                await self.highrise.send_message(conversation_id, f"💡 Usage: {cmd_prefix} [room_link/id]")
                                return
                            
                            room_input = parts[1].strip().strip("()").strip()
                            new_room_id = room_input
                            if "highrise.game/room/" in room_input:
                                new_room_id = room_input.split("highrise.game/room/")[-1].split("?")[0].split("&")[0]
                            elif "high.rs/room?id=" in room_input:
                                new_room_id = room_input.split("high.rs/room?id=")[-1].split("&")[0]
                            elif "high.rs/world" in room_input:
                                if "ownedRoomId=" in room_input:
                                    new_room_id = room_input.split("ownedRoomId=")[-1].split("&")[0]
                                elif "id=" in room_input:
                                    new_room_id = room_input.split("id=")[-1].split("&")[0]
                            elif "rid=" in room_input:
                                new_room_id = room_input.split("rid=")[-1].split("&")[0]

                            await self.highrise.send_message(conversation_id, f"🚀 Switching CURRENT bot to new room: {new_room_id}\n🌀 Joining new room shortly...")
                            token_clean = self.config.get("API_TOKEN", "").strip()
                            
                            if os.path.exists("bots_config.json"):
                                try:
                                    with open("bots_config.json", "r") as f:
                                        bots_data = json.load(f)
                                    found = False
                                    if isinstance(bots_data, list):
                                        for b in bots_data:
                                            if b.get("token", "").strip() == token_clean:
                                                b["room_id"] = new_room_id
                                                b["force_restart"] = False
                                                found = True
                                                break
                                        if found:
                                            with open("bots_config.json", "w") as f:
                                                json.dump(bots_data, f, indent=4)
                                except Exception as e:
                                    print(f"Error updating bots_config: {e}")

                            if os.path.exists("config.json"):
                                try:
                                    with open("config.json", "r") as f:
                                        main_cfg = json.load(f)
                                    main_cfg["ROOM_ID"] = new_room_id
                                    main_cfg["room_id"] = new_room_id
                                    main_cfg["force_restart"] = False
                                    with open("config.json", "w") as f:
                                        json.dump(main_cfg, f, indent=4)
                                except Exception as e:
                                    print(f"Error updating config.json: {e}")
                                    
                            await asyncio.sleep(0.5)
                            os._exit(0)
                        except Exception as e:
                            print(f"Error in DM -botroom: {e}")
                            await self.highrise.send_message(conversation_id, f"❌ Failed to process room change: {e}")
                        return

            # Allow -sub and -unsub for everyone
            if msg_lower == "-sub":
                username = await self.get_username_from_id(user_id)
                if not username:
                    msg = await self.translate_text("❌ Sorry, I couldn't resolve your username for subscription. Try again later or use the room command.", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
                    return
                
                if username.lower() not in [s.lower() for s in self.subscribers]:
                    self.subscribers.append(username)
                    self.save_config()
                    msg = await self.translate_text(f"Hey @{username} 👋 Welcome back! You are now subscribed ✅ Stay tuned for updates 🎶🔥. To join again anytime, just type -sub", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
                else:
                    msg = await self.translate_text(f"@{username} is already subscribed.", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
                        
            elif msg_lower == "-unsub":
                username = await self.get_username_from_id(user_id)
                if not username:
                    msg = await self.translate_text("❌ Sorry, I couldn't resolve your username for unsubscription. Try again later or use the room command.", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
                    return

                if username.lower() in [s.lower() for s in self.subscribers]:
                    self.subscribers = [s for s in self.subscribers if s.lower() != username.lower()]
                    self.save_config()
                    msg = await self.translate_text(f"Hey @{username} ❌ You are now unsubscribed. If you want to join again anytime, just type -sub", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
                else:
                    msg = await self.translate_text(f"@{username} is not subscribed.", user_id=user_id)
                    await self.highrise.send_message(conversation_id, msg)
        except Exception as e:
            print(f"Error in on_message: {e}")

    async def music_worker(self):
        import time
        import asyncio
        import random
        import subprocess
        try:
            while (getattr(self, 'song_queue', None) and len(self.song_queue) > 0) or getattr(self, 'autodj', False):
                if not getattr(self, 'song_queue', None):
                    self.song_queue = []

                if len(self.song_queue) == 0 and getattr(self, 'autodj', False):
                    if not self.autodj_playlist:
                        await asyncio.sleep(10)
                        continue
                    now_ts = time.time()
                    failed = getattr(self, 'autodj_recent_failed', {})
                    self.autodj_recent_failed = {k: v for k, v in failed.items() if now_ts - v < 300}
                    candidates = [s for s in self.autodj_playlist if s not in self.autodj_recent_failed]
                    if not candidates:
                        self.autodj_recent_failed.clear()
                        candidates = list(self.autodj_playlist)
                    song_query = random.choice(candidates)
                    def _search_ad():
                        import yt_dlp
                        ydl_opts = {
                            'format': 'bestaudio/best',
                            'noplaylist': True,
                            'quiet': True,
                            'no_warnings': True,
                            'default_search': 'ytsearch1',
                        }
                        try:
                            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                                info = ydl.extract_info(song_query, download=False)
                                if not info or ('entries' in info and len(info['entries']) == 0):
                                    return None
                                entries = info['entries'] if 'entries' in info else [info]
                                for video in entries:
                                    if video and video.get('url'):
                                        return video.get('title'), video.get('webpage_url'), video.get('url'), video.get('duration', 0), video.get('http_headers', {})
                        except Exception:
                            pass
                        return None

                    try:
                        result = await asyncio.wait_for(asyncio.to_thread(_search_ad), timeout=60)
                    except asyncio.TimeoutError:
                        result = None

                    if result:
                        title, web_url, stream_url, duration, headers = result
                        if stream_url and duration and duration <= 600:
                            self.song_queue.append({
                                "title": title,
                                "web_url": web_url,
                                "stream_url": stream_url,
                                "requester_id": "AutoDJ",
                                "requester_name": "AutoDJ",
                                "duration": duration,
                                "headers": headers,
                                "is_autodj": True,
                                "_pick_key": song_query
                            })
                            self._autodj_song_pick_retries = 0
                        else:
                            self.autodj_recent_failed[song_query] = now_ts
                            self._autodj_song_pick_retries = getattr(self, '_autodj_song_pick_retries', 0) + 1
                            await asyncio.sleep(3 if self._autodj_song_pick_retries < 5 else 15)
                            continue
                    else:
                        self.autodj_recent_failed[song_query] = now_ts
                        self._autodj_song_pick_retries = getattr(self, '_autodj_song_pick_retries', 0) + 1
                        await asyncio.sleep(3 if self._autodj_song_pick_retries < 5 else 15)
                        continue

                if len(self.song_queue) == 0:
                    break

                self.current_song = self.song_queue.pop(0)
                self.current_song['start_time'] = time.time()
                is_autodj_song = self.current_song.get('is_autodj', False)
                pick_key = self.current_song.get('_pick_key')

                song_ad_key = self.current_song.get('title', '') + str(self.current_song.get('start_time', 0))
                if not getattr(self, 'last_upnext_ad_song', None) or self.last_upnext_ad_song != song_ad_key:
                    self.last_upnext_ad_song = song_ad_key
                    up_title = str(self.current_song.get('title', 'Unknown'))
                    if len(up_title) > 40:
                        up_title = up_title[:37] + "..."
                    up_requester = str(self.current_song.get('requester_name', 'Unknown'))
                    up_duration = self.current_song.get('duration', 0) or 0
                    def _fmt_up(secs):
                        m, s = divmod(int(secs or 0), 60)
                        return f"{m:02d}:{s:02d}"
                    upnext_msg = (
                        f"<#fdfcdc>🔔 Up next:\n"
                        f"<#fdfcdc>🎵 {up_title}\n"
                        f"<#d2f2ff>👤 @{up_requester} • ⏱️ {_fmt_up(up_duration)}"
                    )
                    try:
                        await self.highrise.chat(upnext_msg)
                    except Exception:
                        pass

                np_msg = await self.get_now_playing_message()
                if np_msg:
                    try:
                        await self.highrise.chat(np_msg)
                    except Exception:
                        pass

                stream_url = self.current_song.get('stream_url', '')
                icecast_url = getattr(self, 'icecast_url', "")
                song_duration = self.current_song.get('duration', 0) or 0
                song_started = self.current_song['start_time']
                hard_max_seconds = max(song_duration + 60, 240) if song_duration > 0 else 660

                played_ok = False

                if stream_url and icecast_url:
                    try:
                        headers = self.current_song.get('headers', {})
                        header_args = []
                        if headers:
                            header_str = "".join(f"{k}: {v}\r\n" for k, v in headers.items())
                            header_args = ['-headers', header_str]

                        ffmpeg_cmd = [
                            'ffmpeg',
                            '-reconnect', '1',
                            '-reconnect_streamed', '1',
                            '-reconnect_delay_max', '5',
                            '-rw_timeout', '15000000',
                            '-re',
                        ] + header_args + [
                            '-i', stream_url,
                            '-af', 'afade=t=in:st=0:d=3',
                            '-c:a', 'libmp3lame',
                            '-b:a', '128k',
                            '-content_type', 'audio/mpeg',
                            '-f', 'mp3',
                            icecast_url
                        ]
                        proc = subprocess.Popen(
                            ffmpeg_cmd,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                        self.current_stream_process = proc

                        np_timer = 0
                        upnext_ad_timer = 0
                        if song_duration > 0:
                            if song_duration <= 60:
                                upnext_ad_interval = 0
                            elif song_duration <= 180:
                                upnext_ad_interval = int(song_duration * 0.5)
                            elif song_duration <= 300:
                                upnext_ad_interval = int(song_duration * 0.4)
                            else:
                                upnext_ad_interval = int(song_duration * 0.35)
                            if upnext_ad_interval < 60:
                                upnext_ad_interval = 60
                        else:
                            upnext_ad_interval = 160

                        force_kill_now = False
                        while True:
                            if not self.current_stream_process:
                                break
                            poll_rc = self.current_stream_process.poll()
                            if poll_rc is not None:
                                played_ok = True
                                break
                            wall_elapsed = time.time() - song_started
                            if wall_elapsed >= hard_max_seconds:
                                force_kill_now = True
                                break
                            if song_duration > 0 and wall_elapsed > song_duration + 30:
                                force_kill_now = True
                                break
                            if song_duration <= 0 and is_autodj_song and wall_elapsed > 630:
                                force_kill_now = True
                                break
                            await asyncio.sleep(1)

                            np_timer += 1
                            upnext_ad_timer += 1
                            if np_timer >= 80:
                                np_timer = 0
                                np_msg2 = await self.get_now_playing_message()
                                if np_msg2:
                                    try:
                                        await self.highrise.chat(np_msg2)
                                    except Exception:
                                        pass
                            if upnext_ad_interval > 0 and upnext_ad_timer >= upnext_ad_interval:
                                upnext_ad_timer = 0
                                up_title2 = str(self.current_song.get('title', 'Unknown')) if getattr(self, 'current_song', None) else 'Unknown'
                                if len(up_title2) > 40:
                                    up_title2 = up_title2[:37] + "..."
                                up_requester2 = str(self.current_song.get('requester_name', 'Unknown')) if getattr(self, 'current_song', None) else 'Unknown'
                                up_duration2 = self.current_song.get('duration', 0) or 0 if getattr(self, 'current_song', None) else 0
                                def _fmt_up2(secs):
                                    m, s = divmod(int(secs or 0), 60)
                                    return f"{m:02d}:{s:02d}"
                                upnext_msg2 = (
                                    f"<#fdfcdc>🔔 Up next:\n"
                                    f"<#fdfcdc>🎵 {up_title2}\n"
                                    f"<#d2f2ff>👤 @{up_requester2} • ⏱️ {_fmt_up2(up_duration2)}"
                                )
                                try:
                                    await self.highrise.chat(upnext_msg2)
                                except Exception:
                                    pass

                        if force_kill_now or (self.current_stream_process and self.current_stream_process.poll() is None):
                            try:
                                self.current_stream_process.terminate()
                            except Exception:
                                pass
                            try:
                                await asyncio.wait_for(asyncio.to_thread(lambda: self.current_stream_process.wait() if self.current_stream_process else 0), timeout=4)
                            except Exception:
                                pass
                            try:
                                if self.current_stream_process and self.current_stream_process.poll() is None:
                                    self.current_stream_process.kill()
                            except Exception:
                                pass
                            played_ok = True
                    except asyncio.CancelledError:
                        if getattr(self, 'current_stream_process', None):
                            try:
                                self.current_stream_process.terminate()
                            except Exception:
                                pass
                        raise
                    except Exception as e:
                        print(f"Error starting ffmpeg: {e}")
                        if pick_key and is_autodj_song:
                            self.autodj_recent_failed[pick_key] = time.time()
                    finally:
                        self.current_stream_process = None
                else:
                    if stream_url:
                        try:
                            if hasattr(self.highrise, 'voice') and hasattr(self.highrise.voice, 'play'):
                                try:
                                    await asyncio.wait_for(self.highrise.voice.play(stream_url), timeout=10)
                                except asyncio.TimeoutError:
                                    pass
                            elif hasattr(self.highrise, 'play_voice_stream'):
                                try:
                                    await asyncio.wait_for(self.highrise.play_voice_stream(stream_url), timeout=10)
                                except asyncio.TimeoutError:
                                    pass
                        except Exception:
                            pass

                    try:
                        song_duration_fb = song_duration or 0
                        if song_duration_fb > 0:
                            if song_duration_fb <= 60:
                                fb_upnext_interval = 0
                            elif song_duration_fb <= 180:
                                fb_upnext_interval = int(song_duration_fb * 0.5)
                            elif song_duration_fb <= 300:
                                fb_upnext_interval = int(song_duration_fb * 0.4)
                            else:
                                fb_upnext_interval = int(song_duration_fb * 0.35)
                            if fb_upnext_interval < 60:
                                fb_upnext_interval = 60
                        else:
                            fb_upnext_interval = 160
                        target_sleep = (song_duration_fb + 15) if song_duration_fb > 0 else 180
                        target_sleep = min(target_sleep, hard_max_seconds)
                        elapsed_sleep = 0
                        while elapsed_sleep < target_sleep:
                            cur_start = self.current_song.get('start_time', song_started) if getattr(self, 'current_song', None) else song_started
                            if (time.time() - cur_start) >= hard_max_seconds:
                                break
                            await asyncio.sleep(1)
                            elapsed_sleep += 1
                            if elapsed_sleep % 80 == 0:
                                np_msg_fb = await self.get_now_playing_message()
                                if np_msg_fb:
                                    try:
                                        await self.highrise.chat(np_msg_fb)
                                    except Exception:
                                        pass
                            if fb_upnext_interval > 0 and elapsed_sleep % fb_upnext_interval == 0:
                                up_title3 = str(self.current_song.get('title', 'Unknown')) if getattr(self, 'current_song', None) else 'Unknown'
                                if len(up_title3) > 40:
                                    up_title3 = up_title3[:37] + "..."
                                up_requester3 = str(self.current_song.get('requester_name', 'Unknown')) if getattr(self, 'current_song', None) else 'Unknown'
                                up_duration3 = self.current_song.get('duration', 0) or 0 if getattr(self, 'current_song', None) else 0
                                def _fmt_up3(secs):
                                    m, s = divmod(int(secs or 0), 60)
                                    return f"{m:02d}:{s:02d}"
                                upnext_msg3 = (
                                    f"<#fdfcdc>🔔 Up next:\n"
                                    f"<#fdfcdc>🎵 {up_title3}\n"
                                    f"<#d2f2ff>👤 @{up_requester3} • ⏱️ {_fmt_up3(up_duration3)}"
                                )
                                try:
                                    await self.highrise.chat(upnext_msg3)
                                except Exception:
                                    pass
                        played_ok = True
                    except asyncio.CancelledError:
                        raise

                if not played_ok and pick_key and is_autodj_song:
                    self.autodj_recent_failed[pick_key] = time.time()

                try:
                    if getattr(self, 'current_stream_process', None):
                        try:
                            self.current_stream_process.terminate()
                        except Exception:
                            pass
                        self.current_stream_process = None
                except Exception:
                    pass
                self.current_song = None

        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"Fatal error in music_worker: {e}")
            import traceback
            traceback.print_exc()
        finally:
            try:
                if getattr(self, 'current_stream_process', None):
                    try:
                        self.current_stream_process.terminate()
                    except Exception:
                        pass
                    self.current_stream_process = None
            except Exception:
                pass
            self.current_song = None
            global _GLOBAL_MUSIC_TASK
            _GLOBAL_MUSIC_TASK = None

    async def handle_play_command(self, query: str, user, gift_target: str = None):
        if getattr(self, 'song_queue', None) is not None and len(self.song_queue) >= 10:
            await self.highrise.send_whisper(user.id, "❌ The queue is full! Maximum 10 songs allowed.")
            return False

        def _search():
            import yt_dlp
            ydl_opts = {
                'format': 'bestaudio/best',
                'noplaylist': True,
                'quiet': True,
                'no_warnings': True,
                'default_search': 'ytsearch5',
            }
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(query, download=False)
                    if not info or ('entries' in info and len(info['entries']) == 0):
                        return None
                    entries = info['entries'] if 'entries' in info else [info]
                    for video in entries:
                        if video and video.get('url'):
                            return video.get('title'), video.get('webpage_url'), video.get('url'), video.get('duration', 0), video.get('http_headers', {})
            except Exception:
                pass
            return None

        result = await asyncio.to_thread(_search)
        if result:
            title, web_url, stream_url, duration, headers = result
            if not stream_url:
                await self.highrise.send_whisper(user.id, f"❌ Could not find a playable stream for '{query}' on YouTube.")
                return False
            if not hasattr(self, 'song_queue'):
                self.song_queue = []
            
            req_name = f"{user.username} 🎁 for @{gift_target}" if gift_target else user.username
            song_obj = {
                "title": title,
                "web_url": web_url,
                "stream_url": stream_url,
                "requester_id": user.id,
                "requester_name": req_name,
                "duration": duration,
                "headers": headers
            }

            pm = getattr(self, "paid_mode", True)
            sp = getattr(self, "song_price", 10)
            is_privileged = self.is_owner(user.username) or self.is_mod(user.username) or self.is_vip(user.username)

            if pm and not is_privileged:
                sender_id_str = str(user.id)
                if not hasattr(self, "balances"):
                    self.balances = {}
                user_balance = self.balances.get(sender_id_str, 0)
                
                if user_balance >= 1:
                    # Deduct 1 ticket and proceed
                    self.balances[sender_id_str] -= 1
                    self.save_balances()
                    await self.highrise.send_whisper(user.id, f"🎟️ 1 Ticket deducted. You have {self.balances[sender_id_str]} tickets left.")
                else:
                    await self.highrise.send_whisper(user.id, f"❌ You need a Music Ticket to play a song! Tip the bot {sp} gold to get 1 Ticket.")
                    return True
            
            self.song_queue.append(song_obj)
            pos = len(self.song_queue)

            def _fmt(secs):
                m, s = divmod(int(secs or 0), 60)
                return f"{m:02d}:{s:02d}"

            confirm_msg = (
                f"<#fdfcdc>📝 Added to queue:\n"
                f"<#fdfcdc> 🎶 {title}\n"
                f"<#d2f2ff>⏱️ Duration: {_fmt(duration)}\n"
                f"<#d2f2ff>👤 Requested by: @{req_name}\n"
                f"<#d2f2ff>📊 Position in queue: {pos}"
            )

            if not hasattr(self, "song_ratings"):
                self.song_ratings = {}
            if "__user_plays__" not in self.song_ratings:
                self.song_ratings["__user_plays__"] = {}
            user_id_str = str(user.id)
            self.song_ratings["__user_plays__"][user_id_str] = self.song_ratings["__user_plays__"].get(user_id_str, 0) + 1
            self.save_ratings()
            
            await self.highrise.send_whisper(user.id, confirm_msg)
            
            self.start_music_worker()
            return True
        else:
            await self.highrise.send_whisper(user.id, f"❌ Could not find '{query}' on YouTube.")
            return False  

    async def get_queue_message(self, page: int = 1):
        if not getattr(self, 'song_queue', None) or len(self.song_queue) == 0:
            return "❌ The queue is empty."
        
        items_per_page = 5
        total_items = len(self.song_queue)
        total_pages = (total_items + items_per_page - 1) // items_per_page
        
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
            
        start_idx = (page - 1) * items_per_page
        end_idx = min(start_idx + items_per_page, total_items)
        
        msg = f"<#fdfcdc>📜 Queue ({start_idx + 1}-{end_idx} of {total_items}):\n\n"
        
        def format_time(seconds):
            m, s = divmod(int(seconds), 60)
            return f"{m:02d}:{s:02d}"
            
        for i in range(start_idx, end_idx):
            song = self.song_queue[i]
            title = song.get('title', 'Unknown')
            if len(title) > 35:
                title = title[:32] + "..."
            duration = song.get('duration', 0)
            req = song.get('requester_name', 'Unknown')
            link = song.get('web_url', '')
            req_id = str(song.get('requester_id', ''))
            user_plays = getattr(self, 'song_ratings', {}).get('__user_plays__', {}).get(req_id, 1) if req_id else 1
            
            ratings = getattr(self, 'song_ratings', {}).get(link, {"likes": [], "dislikes": [], "plays": 0})
            likes = len(ratings.get("likes", [])) if isinstance(ratings.get("likes", []), list) else 0
            
            msg += f"<#fdfcdc>{i + 1}. ▶️ {title}\n"
            msg += f"<#d2f2ff>⏱️ {format_time(duration)} | 👤 {req}\n"
            msg += f"<#d2f2ff>❤️ {likes} | 🎧 {user_plays}\n"
            
        if total_pages > 1:
            msg += f"\n<#fdfcdc>Use -q {page+1} to see next page"
            
        return msg

    async def get_playlist_chunks(self):
        playlist = getattr(self, 'autodj_playlist', [])
        if not playlist:
            return ["❌ The AutoDJ playlist is empty."]

        CHUNK_LIMIT = 1800
        autodj_enabled = getattr(self, 'autodj', False)
        status = "ON ✅" if autodj_enabled else "OFF ❌"
        total = len(playlist)
        header_base = f"<#fdfcdc>📻 AutoDJ Playlist (Status: {status})\n<#d2f2ff>Total: {total} songs\n\n"

        chunks = []
        current = header_base
        for i, song in enumerate(playlist):
            if len(song) > 40:
                song = song[:37] + "..."
            line = f"<#fdfcdc>{i + 1}. 🎵 {song}\n"

            if len(current) + len(line) > CHUNK_LIMIT:
                chunks.append(current)
                part_hdr = f"<#fdfcdc>📻 AutoDJ Playlist (cont.) | {total} songs\n\n"
                current = part_hdr + line
            else:
                current += line

        if current.strip():
            chunks.append(current)

        return chunks

    async def get_now_playing_message(self):
        """Generates the formatted Now Playing message with progress bar."""
        try:
            if not getattr(self, 'current_song', None):
                return None
            import time
            title = str(self.current_song.get('title', 'Unknown'))
            if len(title) > 40:
                title = title[:37] + "..."
            requester = str(self.current_song.get('requester_name', 'Unknown'))
            duration = self.current_song.get('duration', 0) or 0
            start_time = self.current_song.get('start_time', time.time())
            elapsed = int(time.time() - start_time)
            is_autodj = bool(self.current_song.get('is_autodj', False))
            max_allowed = max(duration + 90, 300) if duration > 0 else 690
            if elapsed > max_allowed:
                try:
                    if getattr(self, 'current_stream_process', None):
                        try:
                            self.current_stream_process.terminate()
                        except Exception:
                            pass
                        self.current_stream_process = None
                except Exception:
                    pass
                self.current_song = None
                return None
            
            # Ensure elapsed doesn't exceed duration
            if duration > 0 and elapsed > duration:
                elapsed = duration
            if elapsed < 0:
                elapsed = 0
                
            def format_time(seconds):
                m, s = divmod(int(seconds), 60)
                return f"{m:02d}:{s:02d}"
            
            bar_len = 10
            filled = int((elapsed / duration) * bar_len) if duration > 0 else 0
            bar = "▰" * filled + "▱" * (bar_len - filled)
            
            link = self.current_song.get('web_url', '')
            if not hasattr(self, "song_ratings"):
                self.song_ratings = {}
                
            ratings = self.song_ratings.get(link, {"likes": [], "dislikes": [], "plays": 0, "user_plays": {}})
            likes = ratings.get("likes", [])
            if not isinstance(likes, list):
                likes = []
                
            dislikes = ratings.get("dislikes", [])
            if not isinstance(dislikes, list):
                dislikes = []
                
            requester_id = str(self.current_song.get('requester_id', ''))
            user_plays = self.song_ratings.get('__user_plays__', {}).get(requester_id, 1) if requester_id else 1
            queue_count = len(getattr(self, 'song_queue', []) or [])
            
            if self.current_song.get('is_autodj'):
                artist = title.split('-')[0].strip() if '-' in title else "AutoDJ"
                return (
                    f"<#fdfcdc>🎶 Now playing:\n"
                    f"<#fdfcdc>🎵 {title}\n"
                    f"<#fdfcdc>🎤 {artist}\n"
                    f"<#d2f2ff>⏱️ {format_time(elapsed)} / {format_time(duration)}\n"
                    f"<#d2f2ff>{bar}\n"
                    f"<#d2f2ff>📻 AUTODJ LIVE MUSIC"
                )
                
            return (
                f"<#fdfcdc>🎶 Now playing:\n"
                f"<#fdfcdc>🎵 {title}\n"
                f"<#d2f2ff>⏱️ {format_time(elapsed)} / {format_time(duration)}\n"
                f"<#d2f2ff>{bar}\n"
                f"<#d2f2ff>👤 Requester: {requester}\n"
                f"<#d2f2ff>❤️ {len(likes)} | 🎧 {user_plays} | 📋{queue_count}"
            )
        except Exception as e:
            print(f"Error in Now Playing message: {e}")
            return "<#fdfcdc>🎶 Now playing a song... (Loading details)"
        total_pages = (total_items + items_per_page - 1) // items_per_page
        
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
            
        start_idx = (page - 1) * items_per_page
        end_idx = min(start_idx + items_per_page, total_items)
        
        msg = f"<#fdfcdc>📜 Queue ({start_idx + 1}-{end_idx} of {total_items}):\n\n"
        
        def format_time(seconds):
            m, s = divmod(int(seconds), 60)
            return f"{m:02d}:{s:02d}"
            
        for i in range(start_idx, end_idx):
            song = self.song_queue[i]
            title = song.get('title', 'Unknown')
            if len(title) > 35:
                title = title[:32] + "..."
            duration = song.get('duration', 0)
            req = song.get('requester_name', 'Unknown')
            link = song.get('web_url', '')
            req_id = str(song.get('requester_id', ''))
            user_plays = getattr(self, 'song_ratings', {}).get('__user_plays__', {}).get(req_id, 1) if req_id else 1
            
            ratings = getattr(self, 'song_ratings', {}).get(link, {"likes": [], "dislikes": [], "plays": 0})
            likes = len(ratings.get("likes", [])) if isinstance(ratings.get("likes", []), list) else 0
            
            msg += f"<#fdfcdc>{i + 1}. ▶️ {title}\n"
            msg += f"<#d2f2ff>⏱️ {format_time(duration)} | 👤 {req}\n"
            msg += f"<#d2f2ff>❤️ {likes} | 🎧 {user_plays}\n"
            if i < end_idx - 1:
                msg += "\n"
                
        return msg


def run_bot():
    """Helper to run multiple bots from bots_config.json or config.json simultaneously."""

    # Set environment variables to force UTF-8 encoding for subprocesses
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["LANG"] = "en_US.UTF-8"
    env["LC_ALL"] = "en_US.UTF-8"

    print("\n==================================================")
    print("[CROWN] RentABot Multi-Bot Launcher is Starting! [CROWN]")
    print("==================================================")
    print("[LIGHTBULB] Tip: You can run multiple bots simultaneously!")
    print("   Just add their API tokens and Room IDs as a list")
    print("   of objects in 'bots_config.json'.")
    print("   The launcher will auto-detect changes in real-time.")
    print("==================================================\n")

    # Keep track of running processes: {token: Popen_object}
    processes = {}

    while True:
        try:
            # 1. Clean up any global restart flags to prevent loops
            if os.path.exists("restart.flag"):
                try:
                    os.remove("restart.flag")
                except:
                    pass

            # 2. Read bots from bots_config.json
            bots = []
            if os.path.exists("bots_config.json"):
                try:
                    with open("bots_config.json", "r") as f:
                        data = json.load(f)
                        if isinstance(data, list):
                            bots = data
                except Exception as e:
                    print(f"Error reading bots_config.json: {e}")

            # If bots_config.json is empty or doesn't exist, fall back to config.json
            if not bots:
                try:
                    with open("config.json", "r") as f:
                        config = json.load(f)
                        room_id = config.get("ROOM_ID") or config.get("room_id")
                        api_token = config.get("API_TOKEN")
                        if room_id and api_token:
                            bots = [{"token": api_token, "room_id": room_id}]
                except Exception as e:
                    print(f"Error reading fallback config.json: {e}")

            # 3. Check and clean up terminated processes
            for token in list(processes.keys()):
                proc = processes[token]
                poll = proc.poll()
                if poll is not None:
                    print(f"[WARNING] Bot process ended (Token: {token[:6]}...{token[-6:] if len(token) > 12 else ''}, Exit Code: {poll})")
                    del processes[token]

            # 4. Start configured bots that are not currently running
            active_tokens = set()
            for bot in bots:
                token = bot.get("token", "").strip()
                room_id = bot.get("room_id", "").strip()

                if not token or not room_id:
                    continue

                active_tokens.add(token)

                # If this bot is not already running, launch it
                if token not in processes:
                    print(f"[ROCKET] Launching bot in room {room_id} (Token: {token[:6]}...) [ROCKET]")
                    try:
                        # Launch bot as a subprocess using the exact same python interpreter
                        proc = subprocess.Popen(
                            [sys.executable, "-m", "highrise", "main:MusicBot", room_id, token],
                            stdout=None,  # Inherit stdout so it prints directly to the current console
                            stderr=None,   # Inherit stderr
                            env=env
                        )
                        processes[token] = proc
                        time.sleep(1.0) # Rate-limit spawning
                    except Exception as e:
                        print(f"[X] Failed to launch bot for room {room_id}: {e}")

            # 5. Stop any running bots that were removed from the configuration
            for token in list(processes.keys()):
                if token not in active_tokens:
                    print(f"[STOP] Configuration removed for token {token[:6]}... Terminating process.")
                    try:
                        processes[token].terminate()
                        processes[token].wait(timeout=3)
                    except Exception as e:
                        print(f"Error terminating process: {e}")
                    del processes[token]

            # If absolutely no bots are configured, wait a few seconds and check config again
            if not processes:
                print("No bots currently configured or running. Waiting for configuration updates... 💤")
                time.sleep(5)
                continue

            # Poll processes every 2 seconds
            time.sleep(2.0)

        except KeyboardInterrupt:
            print("\n🛑 Shutting down RentABot Multi-Bot Launcher and terminating all bots...")
            for token, proc in list(processes.items()):
                try:
                    proc.terminate()
                    proc.wait(timeout=2)
                except:
                    pass
            print("👋 Goodbye!")
            break
        except Exception as e:
            print(f"FATAL ERROR in run_bot manager loop: {e}")
            time.sleep(5)

if __name__ == "__main__":
    try:
        run_bot()
    except BaseException as e:
        print(f"CRITICAL ERROR: {type(e).__name__}: {e}")
        traceback.print_exc()
        sys.exit(1)
