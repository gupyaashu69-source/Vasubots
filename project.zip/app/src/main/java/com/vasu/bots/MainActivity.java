package com.vasu.bots;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.io.*;
public class MainActivity extends Activity {
  SharedPreferences sp; EditText room, token, owner; Button go; TextView pill, log; Handler h = new Handler(Looper.getMainLooper());
  EditText field(String hint, String key, LinearLayout p) {
    EditText e = new EditText(this); e.setHint(hint); e.setText(sp.getString(key, ""));
    e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); e.setSingleLine(true); p.addView(e); return e;
  }
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    sp = getSharedPreferences("vb", MODE_PRIVATE);
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    ScrollView sv = new ScrollView(this); sv.setBackgroundColor(Color.parseColor("#0b0f1a"));
    LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(48, 110, 48, 60); sv.addView(p);
    TextView t = new TextView(this); t.setText("VASU BOTS TENTEL"); t.setTextSize(26); t.setTypeface(null, Typeface.BOLD);
    t.setTextColor(Color.parseColor("#4c9aff")); t.setGravity(Gravity.CENTER); p.addView(t);
    pill = new TextView(this); pill.setTextSize(18); pill.setGravity(Gravity.CENTER); pill.setPadding(0, 40, 0, 40); p.addView(pill);
    room = field("Room ID", "room", p);
    token = field("Bot API token", "token", p); token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    owner = field("Owner username", "owner", p);
    go = new Button(this); go.setTextSize(20); go.setOnClickListener(v -> toggle()); p.addView(go);
    log = new TextView(this); log.setTextSize(11); log.setTextColor(Color.parseColor("#b8c2da")); log.setPadding(0, 40, 0, 0); p.addView(log);
    setContentView(sv); tick.run();
  }
  boolean running() { return new File(getFilesDir(), "running.flag").exists(); }
  void toggle() {
    Intent i = new Intent(this, BotService.class);
    if (running()) { new File(getFilesDir(), "running.flag").delete(); stopService(i); }
    else {
      String r = room.getText().toString().trim(), k = token.getText().toString().trim(), o = owner.getText().toString().trim();
      if (r.length() != 24 || k.length() != 64 || o.isEmpty()) { Toast.makeText(this, "Room ID = 24 chars, token = 64 chars, owner required", Toast.LENGTH_LONG).show(); return; }
      sp.edit().putString("room", r).putString("token", k).putString("owner", o).apply();
      new File(BotService.dir(this), "bot.log").delete();
      startForegroundService(i);
    }
    h.postDelayed(tick, 800);
  }
  Runnable tick = new Runnable() { public void run() {
    String txt = "";
    try (BufferedReader br = new BufferedReader(new FileReader(new File(BotService.dir(MainActivity.this), "bot.log")))) {
      StringBuilder sb = new StringBuilder(); String l; while ((l = br.readLine()) != null) { sb.append(l).append('\n'); if (sb.length() > 6000) sb.delete(0, sb.length() - 4000); } txt = sb.toString();
    } catch (Exception e) {}
    boolean on = running(), online = on && (txt.contains("successfully started") || txt.contains("connected to the room"));
    pill.setText(online ? "● Online & connected" : on ? "● Starting..." : "● Offline");
    pill.setTextColor(Color.parseColor(online ? "#3ecf8e" : on ? "#e8ecf5" : "#e5535f"));
    go.setText(on ? "■  Stop bot" : "▶  Start bot"); log.setText(txt);
    for (EditText e : new EditText[]{room, token, owner}) e.setEnabled(!on);
    h.postDelayed(this, 2000);
  } };
}
