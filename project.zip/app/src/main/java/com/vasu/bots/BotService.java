package com.vasu.bots;
import android.app.*;
import android.content.*;
import android.content.res.AssetManager;
import android.os.IBinder;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.*;
public class BotService extends Service {
  static File dir(Context c) { return new File(c.getFilesDir(), "bot"); }
  @Override public IBinder onBind(Intent i) { return null; }
  @Override public int onStartCommand(Intent in, int flags, int id) {
    SharedPreferences sp = getSharedPreferences("vb", MODE_PRIVATE);
    final String room = sp.getString("room", ""), token = sp.getString("token", ""), owner = sp.getString("owner", "");
    NotificationChannel ch = new NotificationChannel("bot", "Bot status", NotificationManager.IMPORTANCE_LOW);
    getSystemService(NotificationManager.class).createNotificationChannel(ch);
    Notification n = new Notification.Builder(this, "bot").setContentTitle("VASU BOTS TENTEL").setContentText("Bot is running")
      .setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).build();
    startForeground(1, n);
    new File(getFilesDir(), "running.flag").mkdirs();
    new Thread(() -> {
      try {
        File d = dir(this);
        if (!d.exists()) copy(getAssets(), "botdata", d);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        Python.getInstance().getModule("runner").callAttr("run", d.getAbsolutePath(), room, token, owner);
      } catch (Throwable t) {
        try (FileWriter w = new FileWriter(new File(dir(this), "bot.log"), true)) { w.write("APP ERROR: " + t + "\n"); } catch (Exception e) {}
      }
    }).start();
    return START_STICKY;
  }
  static void copy(AssetManager am, String from, File to) throws IOException {
    String[] kids = am.list(from);
    if (kids != null && kids.length > 0) {
      to.mkdirs();
      for (String k : kids) copy(am, from + "/" + k, new File(to, k));
    } else {
      to.getParentFile().mkdirs();
      try (InputStream is = am.open(from); OutputStream os = new FileOutputStream(to)) {
        byte[] b = new byte[8192]; int r; while ((r = is.read(b)) > 0) os.write(b, 0, r);
      }
    }
  }
  @Override public void onDestroy() {
    new File(getFilesDir(), "running.flag").delete();
    System.exit(0); // ends the :bot process, which stops the bot
  }
}
